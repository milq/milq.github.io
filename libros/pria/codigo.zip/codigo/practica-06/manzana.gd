extends RigidBody2D  # Rebota y se recoge

func _ready() -> void:
    $Recoger.body_entered.connect(
            _on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("jugador"):
        Marcador.sumar(1)  # El autoload
        queue_free()       # Desaparece
