extends RigidBody2D  # La manzana: rebota y se recoge

func _ready() -> void:
    $Recoger.body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("jugador"):
        Marcador.sumar(1)  # El autoload, por su nombre
        queue_free()       # La manzana desaparece
