extends Node2D  # MainScene: los puntos y el final

const TOTAL: int = 5  # Manzanas de la escena
const FIN := "res://fin.tscn"

func _ready() -> void:
    Marcador.cambiado.connect(_on_cambiado)

func _on_cambiado(puntos: int) -> void:
    $Puntos.text = "Puntos: %d" % puntos
    if puntos == TOTAL:  # Ya no queda ninguna
        await get_tree().create_timer(0.5).timeout
        get_tree().change_scene_to_file(FIN)
