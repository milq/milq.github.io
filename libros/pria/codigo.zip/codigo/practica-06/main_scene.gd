extends Node2D  # Los puntos y el final

const TOTAL: int = 5  # Manzanas de la escena
const FIN := "res://fin.tscn"

func _ready() -> void:
    Marcador.cambiado.connect(_on_cambiado)

func _on_cambiado(puntos: int) -> void:
    $Puntos.text = "Puntos: %d" % puntos
    if puntos == TOTAL:  # Ya no queda ninguna
        var arbol := get_tree()
        await arbol.create_timer(0.5).timeout
        arbol.change_scene_to_file(FIN)
