extends Node  # Los puntos de toda la partida

signal cambiado(puntos: int)  # Avisa al cambiar

var puntos: int = 0

func sumar(cantidad: int) -> void:
    puntos += cantidad
    cambiado.emit(puntos)
