extends CharacterBody2D  # Niblo: camina, cae y salta

@export var rapidez := 300.0       # px/s
@export var altura_salto := 160.0  # Píxeles

func _ready() -> void:
    add_to_group("jugador")  # Así lo reconocen

func _physics_process(delta: float) -> void:
    if is_on_floor():
        if Input.is_action_just_pressed("ui_accept"):
            var g := get_gravity().y
            velocity.y = -sqrt(2.0 * g * altura_salto)
    else:  # En el aire, la gravedad
        velocity += get_gravity() * delta
    var eje := Input.get_axis("ui_left", "ui_right")
    velocity.x = eje * rapidez
    move_and_slide()
