extends Control  # Fin: los puntos e Intro para jugar

const JUEGO := "res://main_scene.tscn"

func _ready() -> void:
    var datos := { "puntos": Marcador.puntos }
    $Texto.text = $Texto.text.format(datos)  # {puntos}

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_accept"):  # Intro
        Marcador.reiniciar()
        get_tree().change_scene_to_file(JUEGO)
