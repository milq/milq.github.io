extends Control  # Los puntos e Intro para jugar

const JUEGO := "res://main_scene.tscn"

func _ready() -> void:
    var datos := { "puntos": Marcador.puntos }
    $Texto.text = $Texto.text.format(datos)

func _unhandled_input(
        event: InputEvent) -> void:
    if event.is_action_pressed("ui_accept"):
        Marcador.puntos = 0  # Otra partida
        get_tree().change_scene_to_file(JUEGO)
