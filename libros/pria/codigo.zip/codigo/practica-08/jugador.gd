extends Vehiculo  # Llega al ratón y se para

func _physics_process(delta: float) -> void:
    var raton := get_global_mouse_position()
    mover(llegar(raton, 150.0), delta)
