class_name Vehiculo
extends CharacterBody2D  # Se mueve con fuerzas

@export var rapidez_maxima := 250.0  # px/s
@export var fuerza_maxima := 600.0
@export var masa := 1.0   # Más masa, menos agilidad
@export var gira := true  # Si mira hacia donde va

func mover(fuerza: Vector2, delta: float) -> void:
    var paso := fuerza_maxima / masa * delta
    velocity += fuerza.limit_length(paso)
    velocity = velocity.limit_length(rapidez_maxima)
    move_and_slide()
    if gira and velocity.length() > 10.0:
        rotation = Vector2.UP.angle_to(velocity)

func buscar(punto: Vector2) -> Vector2:
    var hacia := position.direction_to(punto)
    return hacia * rapidez_maxima - velocity

func huir(punto: Vector2, panico: float) -> Vector2:
    if position.distance_to(punto) > panico:
        return -velocity  # A salvo: frena
    var lejos := punto.direction_to(position)
    return lejos * rapidez_maxima - velocity

func llegar(punto: Vector2, frenado: float) -> Vector2:
    var distancia := position.distance_to(punto)
    var factor := minf(distancia / frenado, 1.0)
    var hacia := position.direction_to(punto)
    return hacia * rapidez_maxima * factor - velocity

func separar(vecinos: Array[Node]) -> Vector2:
    var lejos := Vector2.ZERO
    for otro in vecinos:
        var desde: Vector2 = position - otro.position
        var d := desde.length()
        if otro != self and d < 60.0:
            lejos += desde.normalized() * (60.0 - d)
    if lejos == Vector2.ZERO:
        return Vector2.ZERO
    return buscar(position + lejos)
# Perseguir: buscar donde estará el otro
func perseguir(otro: CharacterBody2D) -> Vector2:
    var d := position.distance_to(otro.position)
    var t := d / rapidez_maxima  # Segundos
    return buscar(otro.position + otro.velocity * t)
