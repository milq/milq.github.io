extends Vehiculo  # Busca a Niblo o huye de él

@export var objetivo: CharacterBody2D  # Niblo
@export var huye := false  # En vez de buscar

func _ready() -> void:
    add_to_group("asteroides")  # Para separarse

func _physics_process(delta: float) -> void:
    var fuerza := perseguir(objetivo)
    if huye:
        fuerza = huir(objetivo.position, 250.0)
    var grupo := get_tree().get_nodes_in_group(
            "asteroides")
    fuerza += separar(grupo) * 1.5
    mover(fuerza, delta)
    var ventana := get_viewport_rect().size
    position = position.clamp(
            Vector2.ZERO, ventana)
