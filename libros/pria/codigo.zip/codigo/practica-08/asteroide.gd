extends Vehiculo  # Busca a Niblo o huye de él

@export var objetivo: CharacterBody2D  # Niblo
@export var huye := false  # Si huye en vez de buscar

func _ready() -> void:
    add_to_group("asteroides")  # Así se encuentran

func _physics_process(delta: float) -> void:
    var fuerza := perseguir(objetivo)
    if huye:
        fuerza = huir(objetivo.position, 250.0)
    var vecinos := get_tree().get_nodes_in_group(
            "asteroides")
    fuerza += separar(vecinos) * 1.5  # Sin amontonarse
    mover(fuerza, delta)
    var ventana := get_viewport_rect().size
    position = position.clamp(Vector2.ZERO, ventana)
