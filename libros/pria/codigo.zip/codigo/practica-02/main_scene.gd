extends Node2D  # MainScene: la persecución

const RAPIDEZ := 100.0  # Más lento que Niblo

var tiempo := 0.0  # Desde el último mensaje

@onready var niblo: Sprite2D = $Niblo
@onready var mubbit: Sprite2D = $Mubbit

func _process(delta: float) -> void:
    # De Mubbit a Niblo: extremo menos origen
    var hacia_niblo := (niblo.position
            - mubbit.position)
    var rumbo := hacia_niblo.normalized()
    mubbit.position += rumbo * RAPIDEZ * delta
    # Cada segundo, distancia y punto medio
    tiempo += delta
    if tiempo >= 1.0:
        tiempo = 0.0
        var d := niblo.position.distance_to(
                mubbit.position)
        var medio := (niblo.position
                + mubbit.position) / 2.0
        print("Distancia: %d px, medio: %s"
                % [d, medio.round()])
