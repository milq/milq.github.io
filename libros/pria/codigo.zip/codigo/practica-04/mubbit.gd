extends Sprite2D  # Mubbit: vigila como un faro

@export var manzana: Node2D
@export var niblo: Node2D
@export var radio := 160.0
@export var vueltas_por_segundo := 0.2
@export var campo_de_vision := 60.0  # Grados
@export var alcance := 300.0         # Píxeles
var angulo := 0.0  # Dónde está y adónde mira
@onready var centro := manzana.position
@onready var vista: Polygon2D = $Vista

func _ready() -> void:
    var puntos := PackedVector2Array(
            [Vector2.ZERO])
    for i in 9:
        var a := deg_to_rad(campo_de_vision
                * (i / 8.0 - 0.5))
        puntos.append(
                Vector2.from_angle(a) * alcance)
    vista.polygon = puntos
    vista.color = Color(1, 1, 1, 0.3)

func _process(delta: float) -> void:
    angulo += TAU * vueltas_por_segundo * delta
    var direccion := Vector2.from_angle(angulo)
    position = centro + direccion * radio
    vista.rotation = angulo  # Mira hacia fuera

func ve_a_niblo() -> bool:
    var hacia := niblo.position - position
    if hacia.length() > alcance:
        return false
    var mirada := Vector2.from_angle(angulo)
    var diferencia := absf(
            rad_to_deg(mirada.angle_to(hacia)))
    return diferencia <= campo_de_vision / 2.0
