extends Sprite2D  # La manzana: flota y sigue

var tiempo := 0.0
@export var niblo: Node2D
@export var suavidad := 5.0  # Mayor: más pegada
var cogida := false
@onready var origen := position  # Para volver

func _process(delta: float) -> void:
    tiempo += delta
    offset.y = 8.0 * sin(TAU * 0.5 * tiempo)
    var meta := origen
    if cogida:
        meta = niblo.position + Vector2(0, -48)
    elif position.distance_to(
            niblo.position) < 48.0:
        cogida = true  # Niblo la ha alcanzado
    var peso := 1.0 - exp(-suavidad * delta)
    position = position.lerp(meta, peso)
