extends Node2D  # MainScene: las reglas

@onready var niblo: Sprite2D = $Niblo
@onready var mubbit: Sprite2D = $Mubbit
@onready var manzana: Sprite2D = $Manzana
@onready var casa: TextureRect = $Casa

func _process(_delta: float) -> void:
    var en_casa := casa.get_rect().has_point(
            niblo.position)
    if mubbit.ve_a_niblo():
        atrapado()
    elif manzana.cogida and en_casa:
        ganar()

func atrapado() -> void:
    manzana.cogida = false  # Vuelve a su sitio
    var medio := casa.get_rect().get_center()
    niblo.position = medio
    niblo.scale = Vector2.ZERO  # Reaparece
    var tw := create_tween()
    tw.set_trans(Tween.TRANS_BACK)  # Un muelle
    tw.tween_property(niblo, "scale",
            Vector2.ONE, 0.4)

func ganar() -> void:
    set_process(false)  # Se acabaron las reglas
    manzana.set_process(false)  # Ya no lo sigue
    var tw := create_tween()
    tw.set_trans(Tween.TRANS_BACK)
    tw.tween_property(manzana, "scale",
            Vector2(2, 2), 0.4)
    tw.tween_property(manzana, "modulate:a",
            0.0, 0.3)
    var arbol := get_tree()
    var reiniciar := arbol.reload_current_scene
    tw.tween_callback(reiniciar)  # Otra partida
