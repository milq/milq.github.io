extends Node2D  # MainScene: las reglas

@onready var niblo: Sprite2D = $Niblo
@onready var mubbit: Sprite2D = $Mubbit
@onready var manzana: Sprite2D = $Manzana
@onready var casa: Rect2 = $Casa.get_rect()

func _process(_delta: float) -> void:
    var dentro := casa.has_point(niblo.position)
    if mubbit.ve_a_niblo():
        atrapado()
    elif manzana.cogida and dentro:
        ganar()

func atrapado() -> void:
    manzana.cogida = false  # Vuelve a su sitio
    niblo.position = casa.get_center()
    niblo.scale = Vector2.ZERO  # Reaparece
    var tw := create_tween()
    tw.set_trans(Tween.TRANS_BACK)  # Un muelle
    tw.tween_property(niblo, "scale",
            Vector2.ONE, 0.4)

func ganar() -> void:
    set_process(false)  # Se acabaron las reglas
    manzana.set_process(false)  # Ya no lo sigue
    var tw := create_tween()
    tw.set_trans(Tween.TRANS_BACK)
    tw.tween_property(manzana, "scale",
            Vector2(2, 2), 0.4)
    tw.tween_property(manzana, "modulate:a",
            0.0, 0.3)
    tw.tween_callback(  # Otra partida
            get_tree().reload_current_scene)
