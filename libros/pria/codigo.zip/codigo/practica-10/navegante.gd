class_name Navegante
extends CharacterBody3D  # Lo mueve su agente

@export var rapidez := 4.0  # Metros por segundo
@onready var agente: NavigationAgent3D = $Agente

func _ready() -> void:
    agente.velocity_computed.connect(
            _al_esquivar)

func _physics_process(_delta: float) -> void:
    if agente.is_navigation_finished():
        agente.velocity = Vector3.ZERO  # Quieto
        return
    var hacia := global_position.direction_to(
            agente.get_next_path_position())
    hacia.y = 0.0  # Solo en horizontal
    hacia = hacia.normalized()
    agente.velocity = hacia * rapidez

# La velocidad que no choca con los demás
func _al_esquivar(segura: Vector3) -> void:
    velocity = segura
    move_and_slide()
