extends Navegante  # Mubbit patrulla y persigue a Niblo

const RUTA: Array[Vector2i] = [
    Vector2i(1, 1), Vector2i(10, 1),  # Las esquinas
    Vector2i(10, 5), Vector2i(1, 5),  # del laberinto
]

@export var mundo: Mundo  # MainScene, con mundo.gd
@export var niblo: Node3D
@export var vista := 6.0  # Metros hasta los que ve
var siguiente: int = 0    # Esquina a la que va

func _physics_process(delta: float) -> void:
    var donde := niblo.global_position
    var meta := agente.target_position
    if global_position.distance_to(donde) < vista:
        # Lo persigue: meta nueva si Niblo se ha movido
        if meta.distance_to(donde) > 1.0:
            agente.target_position = donde
    elif agente.is_navigation_finished():
        # Patrulla: a la siguiente esquina de la ruta
        agente.target_position = mundo.a_mundo(
                RUTA[siguiente])
        siguiente = posmod(siguiente + 1, 4)
    super(delta)  # Navegante lo mueve
