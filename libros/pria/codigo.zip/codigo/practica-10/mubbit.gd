extends Navegante  # Patrulla y persigue a Niblo

const RUTA: Array[Vector2i] = [  # Las esquinas
    Vector2i(1, 1), Vector2i(10, 1),
    Vector2i(10, 5), Vector2i(1, 5),
]

@export var mundo: Mundo  # MainScene
@export var niblo: Node3D
@export var vista := 6.0  # Alcance, en metros
var siguiente: int = 0    # Esquina a la que va

func _physics_process(delta: float) -> void:
    var donde := niblo.global_position
    var meta := agente.target_position
    var aqui := global_position
    if aqui.distance_to(donde) < vista:
        # Lo persigue
        if meta.distance_to(donde) > 1.0:
            agente.target_position = donde
    elif agente.is_navigation_finished():
        # Patrulla: a la siguiente esquina
        agente.target_position = mundo.a_mundo(
                RUTA[siguiente])
        siguiente = posmod(siguiente + 1, 4)
    super(delta)  # Navegante lo mueve
