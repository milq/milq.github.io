extends Caminante  # Mubbit patrulla en bucle

const RUTA: Array[Vector2i] = [  # Las esquinas
    Vector2i(1, 1), Vector2i(10, 1),
    Vector2i(10, 5), Vector2i(1, 5),
]

var siguiente: int = 0  # Waypoint al que va

func _process(delta: float) -> void:
    if camino.is_empty():  # Ha llegado
        ir_a(mundo.a_mundo(RUTA[siguiente]))
        siguiente = posmod(siguiente + 1, 4)
    super(delta)  # Lo mueve Caminante
