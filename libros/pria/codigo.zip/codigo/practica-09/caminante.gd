class_name Caminante
extends Sprite3D  # Recorre caminos del mapa

@export var mundo: Mundo    # MainScene
@export var rapidez := 4.0  # Metros por segundo

var camino: Array[Vector3] = []  # Sus waypoints

func ir_a(punto: Vector3) -> void:
    camino = mundo.camino(position, punto)

func _process(delta: float) -> void:
    if camino.is_empty():
        return
    var meta := camino[0]
    meta.y = position.y  # A su altura
    var paso := rapidez * delta
    position = position.move_toward(meta, paso)
    if position == meta:  # Llega justo
        camino.pop_front()
