class_name Mundo
extends Node3D  # Construye el laberinto

const MURO := preload("res://muro.tscn")
const SUELO := preload("res://suelo.tscn")
const LADO := 2.0  # Metros por casilla
const MAPA: Array[String] = [
    "############",
    "#..........#",
    "#.##.####..#",
    "#.#......#.#",
    "#...##.#.#.#",
    "#..........#",
    "############",
]

var red := AStarGrid2D.new()  # Busca caminos

func _ready() -> void:
    var ancho := MAPA[0].length()
    var alto := MAPA.size()
    red.region = Rect2i(0, 0, ancho, alto)
    var modo := AStarGrid2D.DIAGONAL_MODE_NEVER
    red.diagonal_mode = modo
    red.update()
    for y in range(alto):
        for x in range(ancho):
            var casilla := Vector2i(x, y)
            var tile := SUELO
            if MAPA[y][x] == "#":
                tile = MURO
                red.set_point_solid(casilla)
            var nodo: Node3D = (
                    tile.instantiate())
            nodo.position += a_mundo(casilla)
            add_child(nodo)

# Centro de una casilla, en el suelo
func a_mundo(casilla: Vector2i) -> Vector3:
    var x := (casilla.x + 0.5) * LADO
    var z := (casilla.y + 0.5) * LADO
    return Vector3(x, 0, z)

# Casilla en la que está un punto del suelo
func a_casilla(punto: Vector3) -> Vector2i:
    var p := Vector2(punto.x, punto.z) / LADO
    return Vector2i(p.floor())

# Camino A* entre dos puntos, por los centros
func camino(desde: Vector3,
        hasta: Vector3) -> Array[Vector3]:
    var puntos: Array[Vector3] = []
    var inicio := a_casilla(desde)
    var fin := a_casilla(hasta)
    if not red.is_in_boundsv(fin):
        return puntos  # Fuera del mapa, vacío
    for casilla in red.get_id_path(inicio, fin):
        puntos.append(a_mundo(casilla))
    return puntos
