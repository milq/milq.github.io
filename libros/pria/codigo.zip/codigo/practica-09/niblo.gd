extends Caminante  # Niblo va adonde hagas clic

func _unhandled_input(event: InputEvent) -> void:
    var clic := event as InputEventMouseButton
    if clic and clic.pressed:
        var camara := get_viewport().get_camera_3d()
        var p := clic.position
        var desde := camara.project_ray_origin(p)
        var hacia := camara.project_ray_normal(p)
        var suelo := Plane(Vector3.UP, 0.0)  # y = 0
        var punto = suelo.intersects_ray(desde, hacia)
        if punto != null:  # null: no toca el suelo
            ir_a(punto)
