extends Caminante  # Niblo va adonde hagas clic

func _unhandled_input(
        event: InputEvent) -> void:
    var clic := event as InputEventMouseButton
    if not clic or not clic.pressed:
        return
    var camara := get_viewport().get_camera_3d()
    var p := clic.position
    var ojo := camara.project_ray_origin(p)
    var hacia := camara.project_ray_normal(p)
    var suelo := Plane(Vector3.UP, 0.0)  # y = 0
    var punto = suelo.intersects_ray(ojo, hacia)
    if punto != null:  # null: no toca el suelo
        ir_a(punto)
