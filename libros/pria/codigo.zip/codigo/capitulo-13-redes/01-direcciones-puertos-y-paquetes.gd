extends Node  # Un paquete UDP, de un programa a otro

var servidor := PacketPeerUDP.new()
var cliente := PacketPeerUDP.new()

func _ready() -> void:
    servidor.bind(4242)  # Reserva el puerto 4242
    cliente.set_dest_address("127.0.0.1", 4242)
    cliente.put_packet("orden 41".to_utf8_buffer())

func _process(_delta: float) -> void:
    while servidor.get_available_packet_count() > 0:
        var datos := servidor.get_packet()  # orden 41
        print(datos.get_string_from_utf8())
        print(servidor.get_packet_ip())     # 127.0.0.1
        print(servidor.get_packet_port())   # 52317
