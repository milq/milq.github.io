extends Node  # Un paquete UDP, de uno a otro

var servidor := PacketPeerUDP.new()
var cliente := PacketPeerUDP.new()

func _ready() -> void:
    servidor.bind(4242)  # Reserva el puerto
    cliente.set_dest_address("127.0.0.1", 4242)
    var datos := "orden 41".to_utf8_buffer()
    cliente.put_packet(datos)

func _process(_delta: float) -> void:
    while (servidor.get_available_packet_count()
            > 0):
        var datos := servidor.get_packet()
        print(datos.get_string_from_utf8())
        print(servidor.get_packet_ip())
        print(servidor.get_packet_port())
