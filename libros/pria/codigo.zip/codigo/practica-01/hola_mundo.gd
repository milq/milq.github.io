@tool
# Un script que se ejecuta en el editor
extends EditorScript

# File → Run (Ctrl + Shift + X) llama a _run()
func _run() -> void:
    print("¡Hola, mundo!")  # Escribe en Output
    print("Vidas: ", 3)     # Une el texto y el número
    print(2 + 3 * 4)        # 14: primero se multiplica
