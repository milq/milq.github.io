extends Sprite2D  # Persigue al ratón

const RAPIDEZ := 200.0  # Píxeles por segundo
var red := AStarGrid2D.new()  # Grafo del nivel
var camino: PackedVector2Array = []  # Waypoints

func _ready() -> void:
    red.region = Rect2i(0, 0, 9, 6)
    red.cell_size = Vector2(100, 100)  # Tamaño
    red.offset = Vector2(50, 50)       # Centro
    var modo := AStarGrid2D.DIAGONAL_MODE_NEVER
    red.diagonal_mode = modo
    red.update()
    for y in range(4):
        red.set_point_solid(Vector2i(4, y))
    var barro := Vector2i(4, 4)
    red.set_point_weight_scale(barro, 5.0)
    position = Vector2(250, 150)
    $Timer.timeout.connect(buscar)

func buscar() -> void:
    var desde := Vector2i(
            (position / 100.0).floor())
    var raton := get_global_mouse_position()
    var meta := Vector2i(
            (raton / 100.0).floor())
    if red.is_in_boundsv(meta):
        camino = red.get_point_path(desde, meta)

func _process(delta: float) -> void:
    if camino.is_empty():
        return
    position = position.move_toward(
            camino[0], RAPIDEZ * delta)
    if position == camino[0]:  # Llega: lo quita
        camino.remove_at(0)
