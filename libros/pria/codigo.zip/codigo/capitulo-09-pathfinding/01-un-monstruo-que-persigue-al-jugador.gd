extends Sprite2D  # El monstruo persigue al ratón

const RAPIDEZ := 200.0  # Píxeles por segundo
var red := AStarGrid2D.new()  # El nivel, como grafo
var camino: PackedVector2Array = []  # Sus waypoints

func _ready() -> void:
    red.region = Rect2i(0, 0, 9, 6)    # Las casillas
    red.cell_size = Vector2(100, 100)  # Su tamaño
    red.offset = Vector2(50, 50)       # Al centro
    red.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
    red.update()
    for y in range(4):
        red.set_point_solid(Vector2i(4, y))  # El muro
    red.set_point_weight_scale(Vector2i(4, 4), 5.0)
    position = Vector2(250, 150)
    $Timer.timeout.connect(buscar)

func buscar() -> void:
    var desde := Vector2i((position / 100.0).floor())
    var raton := get_global_mouse_position() / 100.0
    var hasta := Vector2i(raton.floor())
    if red.is_in_boundsv(hasta):
        camino = red.get_point_path(desde, hasta)

func _process(delta: float) -> void:
    if camino.is_empty():
        return
    var paso := RAPIDEZ * delta
    position = position.move_toward(camino[0], paso)
    if position == camino[0]:  # Llega: quita el punto
        camino.remove_at(0)
