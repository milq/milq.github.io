extends Sprite2D  # La pelota, hacia el jugador

const RAPIDEZ := 500.0  # Píxeles por segundo
var velocidad := Vector2.ZERO

func _ready() -> void:
    position = Vector2(200, 100)
    rotation = deg_to_rad(36.87)  # ≈ 0.6435 rad
    velocidad = Vector2.from_angle(rotation)
    velocidad *= RAPIDEZ
    print(velocidad.round())  # (400.0, 300.0)

func _process(delta: float) -> void:
    position += velocidad * delta
