extends Sprite2D  # El lanzapelotas que vigila y lanza

const GIRO := deg_to_rad(90.0)  # Velocidad angular
const CONO := deg_to_rad(20.0)  # A cada lado
const APLASTADA := Vector2(0.7, 1.3)
var tiempo := 0.0
var tw: Tween  # El tween del último lanzamiento

func _process(delta: float) -> void:
    var hacia := get_global_mouse_position() - position
    var meta := hacia.angle()  # Apunta al jugador...
    if absf(transform.x.angle_to(hacia)) > CONO:
        tiempo += delta  # ...o barre ±45° cada 4 s
        meta = PI / 4 * sin(TAU * tiempo / 4.0)
    var paso := GIRO * delta  # Lo que gira, como mucho
    rotation = rotate_toward(rotation, meta, paso)
    if tw and tw.is_running():
        return  # Aún está lanzando
    if is_zero_approx(transform.x.angle_to(hacia)):
        lanzar()

func lanzar() -> void:
    tw = create_tween()
    tw.tween_property(self, "scale", APLASTADA, 0.05)
    tw.set_trans(Tween.TRANS_BACK)  # Se pasa y vuelve
    tw.tween_property(self, "scale", Vector2.ONE, 0.3)
    tw.tween_interval(0.5)          # Recarga
