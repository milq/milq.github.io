extends Sprite2D  # El lanzapelotas

const GIRO := deg_to_rad(90.0)  # Por segundo
const CONO := deg_to_rad(45.0)  # A cada lado
const APLASTADA := Vector2(0.7, 1.3)
var tiempo := 0.0
var tw: Tween  # El tween del último lanzamiento

func _process(delta: float) -> void:
    var jugador := get_global_mouse_position()
    var hacia := jugador - position
    var meta := hacia.angle()  # Al jugador...
    if absf(transform.x.angle_to(hacia)) > CONO:
        tiempo += delta  # ...o barre ±45°
        meta = PI / 4 * sin(TAU * tiempo / 4.0)
    rotation = rotate_toward(
            rotation, meta, GIRO * delta)
    if tw and tw.is_running():
        return  # Aún está lanzando
    var desvio := transform.x.angle_to(hacia)
    if is_zero_approx(desvio):
        lanzar()

func lanzar() -> void:  # Anima el disparo
    tw = create_tween()
    tw.tween_property(
            self, "scale", APLASTADA, 0.05)
    tw.set_trans(Tween.TRANS_BACK)  # Se pasa
    tw.tween_property(
            self, "scale", Vector2.ONE, 0.3)
    tw.tween_interval(0.5)          # Recarga
