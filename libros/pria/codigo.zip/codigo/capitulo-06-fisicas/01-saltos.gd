extends CharacterBody2D  # El jugador: corre y salta

const RAPIDEZ := 300.0       # px/s
const ACELERACION := 1500.0  # px/s²
const SALTO := 490.0         # px/s hacia arriba

func _physics_process(delta: float) -> void:
    var eje := Input.get_axis("ui_left", "ui_right")
    var meta := eje * RAPIDEZ  # −300, 0 o 300
    var paso := ACELERACION * delta  # 25 px/s
    velocity.x = move_toward(velocity.x, meta, paso)
    if is_on_floor():
        $Coyote.start(0.1)  # Se renueva mientras pisa
    else:
        velocity += get_gravity() * delta
    if Input.is_action_just_pressed("ui_accept"):
        $Bufer.start(0.1)   # Recuerda la pulsación
    var puede: bool = not $Coyote.is_stopped()
    if puede and not $Bufer.is_stopped():
        velocity.y = -SALTO
        $Coyote.stop()
        $Bufer.stop()
    if Input.is_action_just_released("ui_accept"):
        if velocity.y < 0.0:   # Si aún sube,
            velocity.y /= 2.0  # salto variable
    move_and_slide()
