extends Area2D  # La hurtbox del jugador

signal golpeado  # Avisa al marcador de vidas

func _ready() -> void:
    area_entered.connect(_on_area_entered)

func _on_area_entered(_hitbox: Area2D) -> void:
    if $Invulnerable.is_stopped():  # 1 s sin daño
        $Invulnerable.start(1.0)
        golpeado.emit()
        var jugador: CharacterBody2D = get_parent()
        jugador.velocity.y = -245.0  # El bote
