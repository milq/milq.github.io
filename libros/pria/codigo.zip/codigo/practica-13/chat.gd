extends Control  # Un chat para la red local

const PUERTO: int = 4242             # Mensajes
const PUERTO_ANUNCIOS: int = 4243    # Anuncios
var servidor := UDPServer.new()      # Tu sala
var clientes: Array[PacketPeerUDP] = []
var conexion := PacketPeerUDP.new()  # A la sala
var anuncios := PacketPeerUDP.new()  # Difusión
var ips: Array[String] = []          # Las salas
@onready var nombre: LineEdit = %Nombre
@onready var mensajes: RichTextLabel = %Mensajes
@onready var texto: LineEdit = %Texto

func _ready() -> void:
    %Crear.pressed.connect(crear_sala)
    %Buscar.pressed.connect(buscar_salas)
    %Salas.item_activated.connect(unirse)
    texto.text_submitted.connect(escribir)
    $Anunciar.timeout.connect(anunciar)

func crear_sala() -> void:
    servidor.listen(PUERTO)
    anuncios.set_broadcast_enabled(true)
    anuncios.set_dest_address(
            "255.255.255.255", PUERTO_ANUNCIOS)
    $Anunciar.start()  # Un anuncio por segundo
    conectar("127.0.0.1")  # Tu propio ordenador

func anunciar() -> void:
    var sala := "Sala de " + nombre.text
    anuncios.put_packet(sala.to_utf8_buffer())

func buscar_salas() -> void:
    anuncios.bind(PUERTO_ANUNCIOS)

func recibir_anuncios() -> void:
    while (anuncios.get_available_packet_count()
            > 0):
        var datos := anuncios.get_packet()
        var sala := datos.get_string_from_utf8()
        var ip := anuncios.get_packet_ip()
        if not ips.has(ip):  # Solo las nuevas
            ips.append(ip)
            %Salas.add_item(sala + " " + ip)

func unirse(fila: int) -> void:
    conectar(ips[fila])

func conectar(ip: String) -> void:
    conexion.connect_to_host(ip, PUERTO)
    enviar("se ha unido")

func escribir(frase: String) -> void:
    enviar(frase)
    texto.clear()

func enviar(frase: String) -> void:
    var linea := nombre.text + ": " + frase
    conexion.put_packet(linea.to_utf8_buffer())

func _process(_delta: float) -> void:
    recibir_anuncios()
    if servidor.is_listening():
        atender()
    while (conexion.get_available_packet_count()
            > 0):
        var datos := conexion.get_packet()
        var linea := (
                datos.get_string_from_utf8())
        mensajes.add_text(linea + "\n")

func atender() -> void:
    servidor.poll()
    while servidor.is_connection_available():
        var nuevo := servidor.take_connection()
        clientes.append(nuevo)
    for uno in clientes:
        while (uno.get_available_packet_count()
                > 0):
            repartir(uno.get_packet())

# Enruta: reenvía cada mensaje a todos
func repartir(paquete: PackedByteArray) -> void:
    if paquete.size() > 200:
        return  # No se fía: tan largo, no
    for cliente in clientes:
        cliente.put_packet(paquete)
