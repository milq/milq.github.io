extends Control  # Un chat para la red local

const PUERTO: int = 4242                 # Mensajes
const PUERTO_ANUNCIOS: int = 4243        # Anuncios
var servidor := UDPServer.new()          # Tu sala
var clientes: Array[PacketPeerUDP] = []  # Los unidos
var conexion := PacketPeerUDP.new()      # A una sala
var anuncios := PacketPeerUDP.new()      # Difusión
@onready var nombre: LineEdit = %Nombre
@onready var mensajes: RichTextLabel = %Mensajes
@onready var texto: LineEdit = %Texto

func _ready() -> void:
    %Crear.pressed.connect(crear_sala)
    %Buscar.pressed.connect(buscar_sala)
    %Enviar.pressed.connect(escribir)
    texto.text_submitted.connect(escribir.unbind(1))
    $Anunciar.timeout.connect(anunciar)

# «Crear sala»: escucha, se anuncia y se une a ella
func crear_sala() -> void:
    servidor.listen(PUERTO)
    anuncios.set_broadcast_enabled(true)
    var todos := "255.255.255.255"  # Toda la red local
    anuncios.set_dest_address(todos, PUERTO_ANUNCIOS)
    $Anunciar.start()  # Un anuncio por segundo
    conectar("127.0.0.1")  # Tu propio ordenador

func anunciar() -> void:
    var sala := "Sala de " + nombre.text
    anuncios.put_packet(sala.to_utf8_buffer())

func buscar_sala() -> void:
    anuncios.bind(PUERTO_ANUNCIOS)

func recibir_anuncios() -> void:
    while anuncios.get_available_packet_count() > 0:
        var paquete := anuncios.get_packet()
        var sala := paquete.get_string_from_utf8()
        var ip := anuncios.get_packet_ip()
        if conexion.is_socket_connected():
            return  # Ya está en una sala
        mensajes.append_text(sala + " " + ip + "\n")
        conectar(ip)

func conectar(ip: String) -> void:
    conexion.connect_to_host(ip, PUERTO)
    enviar("se ha unido")

func escribir() -> void:
    enviar(texto.text)
    texto.clear()

func enviar(frase: String) -> void:
    var linea := nombre.text + ": " + frase
    conexion.put_packet(linea.to_utf8_buffer())

func _process(_delta: float) -> void:
    recibir_anuncios()
    if servidor.is_listening():
        atender()
    while conexion.get_available_packet_count() > 0:
        var paquete := conexion.get_packet()
        var linea := paquete.get_string_from_utf8()
        mensajes.append_text(linea + "\n")

# El anfitrión acepta a los que llegan y lee lo suyo
func atender() -> void:
    servidor.poll()
    while servidor.is_connection_available():
        clientes.append(servidor.take_connection())
    for cliente in clientes:
        while cliente.get_available_packet_count() > 0:
            repartir(cliente.get_packet())

# Enruta: reenvía cada mensaje a todos
func repartir(paquete: PackedByteArray) -> void:
    if paquete.size() > 200:
        return  # No se fía: tan largo, no
    for cliente in clientes:
        cliente.put_packet(paquete)
