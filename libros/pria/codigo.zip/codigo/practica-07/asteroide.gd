class_name Asteroide
extends Area2D  # Un asteroide que persigue o hace eses

enum Modo { PERSEGUIR, ZIGZAG }

@export var modo := Modo.PERSEGUIR
@export var rapidez := 140.0  # px/s
@export var giro := 2.0       # rad/s
@export var objetivo: Node2D  # La nave

var tiempo := 0.0

func _physics_process(delta: float) -> void:
    tiempo += delta
    match modo:
        Modo.PERSEGUIR: perseguir(delta)
        Modo.ZIGZAG: zigzag(delta)

# Con rotación: gira poco a poco hacia la nave y avanza
func perseguir(delta: float) -> void:
    var hacia := objetivo.position - position
    var meta := Vector2.UP.angle_to(hacia)
    var paso := giro * delta
    rotation = rotate_toward(rotation, meta, paso)
    var delante := Vector2.UP.rotated(rotation)
    position += delante * rapidez * delta

# Sin rotación: va hacia la nave haciendo eses
func zigzag(delta: float) -> void:
    var nave := objetivo.position
    var hacia := position.direction_to(nave)
    var lado := hacia.orthogonal() * sin(tiempo * 5.0)
    mover_hacia(position + hacia + lado, delta)

# Avanza hacia un punto y mira de golpe hacia allí
func mover_hacia(punto: Vector2, delta: float) -> void:
    var direccion := position.direction_to(punto)
    position += direccion * rapidez * delta
    if direccion != Vector2.ZERO:
        rotation = Vector2.UP.angle_to(direccion)
