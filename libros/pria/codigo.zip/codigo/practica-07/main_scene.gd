extends Node2D  # Asteroides, puntos y vidas

@export var escena_roca: PackedScene

var puntos: int = 0
var vidas: int = 3

func _ready() -> void:
    $Timer.timeout.connect(aparecer)
    actualizar()

func aparecer() -> void:
    var roca: Asteroide
    roca = escena_roca.instantiate()
    var ancho := get_viewport_rect().size.x
    var x := randf() * ancho
    roca.position = Vector2(x, 0.0)
    roca.rotation = randf() * TAU
    var modos := Asteroide.Modo.values()
    roca.modo = modos.pick_random()
    roca.objetivo = $Nave
    var al_chocar := _on_choque.bind(roca)
    roca.body_entered.connect(al_chocar)
    add_child(roca)

func sumar_punto() -> void:  # La llama el láser
    puntos += 1
    actualizar()

func actualizar() -> void:
    $Marcador.text = "PUNTOS %d   VIDAS %d" % [
        puntos, vidas]

func _on_choque(
        cuerpo: Node2D, roca: Node) -> void:
    if cuerpo != $Nave:
        return
    roca.queue_free()  # La que te toca
    vidas -= 1
    actualizar()
    var fin := get_tree().reload_current_scene
    if vidas == 0:
        fin.call_deferred()  # Vuelve a empezar
