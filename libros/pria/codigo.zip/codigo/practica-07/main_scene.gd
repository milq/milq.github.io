extends Node2D  # MainScene: enemigos, puntos y vidas

@export var escena_enemigo: PackedScene

var puntos: int = 0
var vidas: int = 3

func _ready() -> void:
    $Timer.timeout.connect(aparecer)
    actualizar()

func aparecer() -> void:
    var enemigo: Enemigo = escena_enemigo.instantiate()
    var ancho := get_viewport_rect().size.x
    enemigo.position = Vector2(randf() * ancho, 0.0)
    enemigo.rotation = randf() * TAU
    var modos := Enemigo.Modo.values()
    enemigo.modo = modos.pick_random()
    enemigo.objetivo = $Nave
    var al_chocar := _on_choque.bind(enemigo)
    enemigo.body_entered.connect(al_chocar)
    add_child(enemigo)

func sumar_punto() -> void:  # La llama el láser
    puntos += 1
    actualizar()

func actualizar() -> void:
    $Marcador.text = "PUNTOS %d   VIDAS %d" % [
        puntos, vidas]

func _on_choque(cuerpo: Node2D, enemigo: Node) -> void:
    if cuerpo != $Nave:
        return
    enemigo.queue_free()  # El que te toca desaparece
    vidas -= 1
    actualizar()
    if vidas == 0:  # Fin: la partida vuelve a empezar
        get_tree().reload_current_scene.call_deferred()
