extends CharacterBody2D  # Gira, acelera y lanza

@export var giro := 4.0        # rad/s
@export var empuje := 500.0    # px/s²
@export var rozamiento := 0.8  # Frena sola
@export var escena_laser: PackedScene

func _physics_process(delta: float) -> void:
    var mando := Input.get_axis(
            "ui_left", "ui_right")
    rotation += mando * giro * delta
    var delante := Vector2.UP.rotated(rotation)
    if Input.is_action_pressed("ui_up"):
        velocity += delante * empuje * delta
    velocity *= exp(-rozamiento * delta)
    move_and_slide()
    var ancho := get_viewport_rect().size.x
    var alto := get_viewport_rect().size.y
    position.x = wrapf(position.x, 0.0, ancho)
    position.y = wrapf(position.y, 0.0, alto)
    if Input.is_action_just_pressed(
            "ui_accept"):
        var laser: Area2D
        laser = escena_laser.instantiate()
        laser.position = position
        laser.position += delante * 36.0
        laser.rotation = rotation
        get_parent().add_child(laser)
