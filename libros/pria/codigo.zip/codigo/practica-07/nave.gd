extends CharacterBody2D  # Gira, acelera y dispara

@export var giro := 4.0        # rad/s
@export var empuje := 500.0    # px/s²
@export var rozamiento := 0.8  # Cuánto frena sola
@export var escena_laser: PackedScene

func _physics_process(delta: float) -> void:
    # Con rotación: la orientación cambia girando
    var mando := Input.get_axis("ui_left", "ui_right")
    rotation += mando * giro * delta
    var delante := Vector2.UP.rotated(rotation)
    if Input.is_action_pressed("ui_up"):
        velocity += delante * empuje * delta  # Acelera
    velocity *= exp(-rozamiento * delta)  # Frena
    move_and_slide()
    var ventana := get_viewport_rect().size
    position.x = wrapf(position.x, 0.0, ventana.x)
    position.y = wrapf(position.y, 0.0, ventana.y)
    if Input.is_action_just_pressed("ui_accept"):
        var laser: Area2D = escena_laser.instantiate()
        laser.position = position + delante * 36.0
        laser.rotation = rotation
        get_parent().add_child(laser)
