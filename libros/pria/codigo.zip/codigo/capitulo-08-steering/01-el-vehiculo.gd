extends CharacterBody2D  # El monstruo, un vehículo

@export var rapidez_maxima := 250.0  # px/s
@export var fuerza_maxima := 600.0
@export var masa := 1.0

func _physics_process(delta: float) -> void:
    var raton := get_global_mouse_position()
    mover(buscar(raton), delta)

func mover(fuerza: Vector2, delta: float) -> void:
    var paso := fuerza_maxima / masa * delta
    velocity += fuerza.limit_length(paso)
    velocity = velocity.limit_length(rapidez_maxima)
    move_and_slide()
    rotation = velocity.angle()  # Hacia donde va

func buscar(punto: Vector2) -> Vector2:
    var hacia := position.direction_to(punto)
    return hacia * rapidez_maxima - velocity
