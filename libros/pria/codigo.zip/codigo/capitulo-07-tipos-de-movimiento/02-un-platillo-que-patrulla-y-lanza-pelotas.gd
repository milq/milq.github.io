extends Sprite2D  # El platillo

const PASOS := [  # Velocidad y segundos
    [Vector2(150, 0), 3.0],   # Derecha
    [Vector2(0, 150), 1.6],   # Abajo
    [Vector2(-150, 0), 3.0],  # Izquierda
    [Vector2(0, -150), 1.6],  # Arriba
]

var paso: int = 0
var tiempo := 0.0  # Segundos en el paso actual
var espera := 1.0  # Segundos hasta lanzar

func _process(delta: float) -> void:
    position += PASOS[paso][0] * delta
    tiempo += delta
    if tiempo >= PASOS[paso][1]:  # Al siguiente
        tiempo -= PASOS[paso][1]
        paso = (paso + 1) % PASOS.size()
    espera -= delta
    if espera <= 0.0:  # Lanza al ratón
        espera = 1.0
        var raton := get_global_mouse_position()
        var angulo := (raton - position).angle()
        var error := randf_range(-22.5, 22.5)
        print(rad_to_deg(angulo) + error)
