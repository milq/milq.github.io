extends Sprite2D  # El platillo: patrulla y dispara

const PASOS := [  # Cada paso: velocidad y segundos
    [Vector2(200, 0), 2.0],   # Derecha
    [Vector2(0, 200), 1.5],   # Abajo
    [Vector2(-200, 0), 2.0],  # Izquierda
    [Vector2(0, -200), 1.5],  # Arriba
]

var paso: int = 0
var tiempo := 0.0  # Segundos en el paso actual
var espera := 1.0  # Segundos hasta el próximo disparo

func _ready() -> void:
    position = Vector2(200, 100)

func _process(delta: float) -> void:
    position += PASOS[paso][0] * delta
    tiempo += delta
    if tiempo >= PASOS[paso][1]:  # Pasa al siguiente
        tiempo -= PASOS[paso][1]
        paso = (paso + 1) % PASOS.size()
    espera -= delta
    if espera <= 0.0:  # Dispara al ratón, con error
        espera = 1.0
        var raton := get_global_mouse_position()
        var angulo := (raton - position).angle()
        var error := randf_range(-22.5, 22.5)  # Grados
        print(rad_to_deg(angulo) + error)
