extends Sprite2D  # El monstruo, con rotación

const RAPIDEZ := 170.0  # Píxeles por segundo
const GIRO := 2.0       # Radianes por segundo

func _process(delta: float) -> void:
    var jugador := get_global_mouse_position()
    var meta := (jugador - position).angle()
    var paso := GIRO * delta
    rotation = rotate_toward(
            rotation, meta, paso)
    position += transform.x * RAPIDEZ * delta
