extends Sprite2D  # Mubbit: se acerca por detrás

const RAPIDEZ := 100.0  # Píxeles por segundo

@onready var niblo: Node2D = $"../Niblo"

func _process(delta: float) -> void:
    # Mubbit, en el sistema local de Niblo
    var visto := niblo.to_local(global_position)
    if visto.x < 0.0:  # A su espalda: avanza
        position = position.move_toward(
                niblo.position, RAPIDEZ * delta)
