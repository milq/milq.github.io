extends Sprite2D  # La varita de Niblo

const GIRO := 360.0  # Grados por segundo

func _process(delta: float) -> void:
    rotation_degrees += GIRO * delta
    # Al acabar el tajo, abajo, vuelve arriba
    if rotation_degrees > 90.0:
        rotation_degrees = -90.0
