extends Area2D  # La manzana: decide el servidor

var puntos := {}  # Identificador → manzanas

func _ready() -> void:
    body_entered.connect(_al_tocar)

func _al_tocar(jugador: Node2D) -> void:
    if not multiplayer.is_server():
        return  # En los clientes solo se ve
    sumar_punto.rpc(jugador.name.to_int())
    position.x = randf_range(60, 580)
    position.y = randf_range(60, 300)

# El servidor avisa a todos, también a sí mismo
@rpc("authority", "call_local", "reliable")
func sumar_punto(id: int) -> void:
    puntos[id] = puntos.get(id, 0) + 1
    var texto := ""
    for quien in puntos:
        var n: int = puntos[quien]
        texto += "Jugador %d: %d\n" % [quien, n]
    get_node("../Marcador").text = texto
