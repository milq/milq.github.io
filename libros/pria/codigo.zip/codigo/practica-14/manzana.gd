extends Area2D  # La manzana: decide el servidor

var puntos := {}  # Identificador → manzanas

func _ready() -> void:
    body_entered.connect(_al_tocar)

func _process(_delta: float) -> void:
    var texto := ""
    for quien in puntos:
        var n: int = puntos[quien]
        texto += "Jugador %d: %d\n" % [quien, n]
    %Marcador.text = texto

func _al_tocar(jugador: Node2D) -> void:
    if jugador.is_multiplayer_authority():
        coger.rpc_id(1)  # Comando al servidor

@rpc("any_peer", "call_local", "reliable")
func coger() -> void:
    var id := multiplayer.get_remote_sender_id()
    var jugador := %Jugadores.get_node(str(id))
    if (position.distance_to(jugador.position)
            > 60):
        return  # Llegó otro antes, o es trampa
    puntos[id] = puntos.get(id, 0) + 1
    position.x = randf_range(60, 580)
    position.y = randf_range(60, 300)
    celebrar.rpc(id)  # Evento: a todos

@rpc("call_local")
func celebrar(id: int) -> void:
    var jugador := %Jugadores.get_node(str(id))
    jugador.modulate = Color.GOLD
    create_tween().tween_property(jugador,
            "modulate", Color.WHITE, 0.5)
