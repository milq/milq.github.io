extends Node2D  # La partida, con sus jugadores

const JUGADOR := preload("res://jugador.tscn")
const PUERTO: int = 4242
const DIRECCION := "127.0.0.1"  # Del anfitrión

func _ready() -> void:
    var peer := ENetMultiplayerPeer.new()
    if "--cliente" in OS.get_cmdline_args():
        peer.create_client(DIRECCION, PUERTO)
        multiplayer.multiplayer_peer = peer
        # Si el servidor se va, la partida acaba
        multiplayer.server_disconnected.connect(
                get_tree().quit)
        return  # Los trae el spawner
    peer.create_server(PUERTO, 3)  # 3 clientes
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_connected.connect(anadir)
    multiplayer.peer_disconnected.connect(
            quitar)
    anadir(1)  # El anfitrión es siempre el 1

# En el servidor; el spawner lo copia al resto
func anadir(id: int) -> void:
    var jugador := JUGADOR.instantiate()
    jugador.name = str(id)  # Su identificador
    $Jugadores.add_child(jugador)

func quitar(id: int) -> void:
    $Jugadores.get_node(str(id)).queue_free()
