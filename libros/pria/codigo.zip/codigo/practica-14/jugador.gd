extends CharacterBody2D  # Lo mueve su dueño

@export var rapidez := 300.0  # px/s

func _enter_tree() -> void:
    set_multiplayer_authority(name.to_int())

func _ready() -> void:
    # El anfitrión es Niblo; los demás, Mubbit
    if name != "1":
        $Sprite2D.texture = load("res://mubbit.png")
    if is_multiplayer_authority():  # Dónde empieza
        position = Vector2(randf_range(100, 540), 240)

func _physics_process(_delta: float) -> void:
    if not is_multiplayer_authority():
        # Lo mueve otro ordenador; aquí solo se copia
        return
    var direccion := Input.get_vector(
            "ui_left", "ui_right", "ui_up", "ui_down")
    velocity = direccion * rapidez
    move_and_slide()
