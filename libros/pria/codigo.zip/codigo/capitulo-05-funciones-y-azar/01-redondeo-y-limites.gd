extends Node  # Nivel, energía y hechizos del jugador

func nivel_con(puntos: int) -> int:
    var n := floori(log(puntos / 50.0) / log(2))
    return maxi(n, 0)  # Con menos de 100, el 0

func _ready() -> void:
    print(nivel_con(1000))          # 4
    print(clampi(20 - 30, 0, 100))  # 0
    print(wrapi(2 + 1, 0, 3))       # 0
    print(posmod(0 - 1, 3))         # 2
    print(roundi(7.5))              # 8
    print(int(-7.5))                # -7
