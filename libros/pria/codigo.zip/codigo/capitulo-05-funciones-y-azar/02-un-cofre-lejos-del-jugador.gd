extends Node  # El premio del cofre, de dos maneras

const PREMIOS := ["monedas", "poción", "varita"]
const LLENA := ["monedas", "monedas", "monedas",
    "monedas", "monedas", "monedas", "poción",
    "poción", "poción", "varita"]

var azar := RandomNumberGenerator.new()
var bolsa: Array = []

func con_pesos() -> String:  # 60, 30 y 10
    var pesos := PackedFloat32Array([60, 30, 10])
    return PREMIOS[azar.rand_weighted(pesos)]

func de_la_bolsa() -> String:
    if bolsa.is_empty():  # Se rellena y se baraja
        bolsa = LLENA.duplicate()
        bolsa.shuffle()
    return bolsa.pop_back()

func _ready() -> void:
    azar.seed = 2026  # Mientras pruebas
    for i: int in range(10):
        print(con_pesos(), " / ", de_la_bolsa())
