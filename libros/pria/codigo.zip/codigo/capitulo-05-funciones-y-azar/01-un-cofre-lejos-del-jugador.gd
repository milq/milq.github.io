extends Node  # El cofre del monstruo

const LLENA := ["monedas", "monedas", "monedas",
    "monedas", "monedas", "monedas", "poción",
    "poción", "poción", "varita"]

var bolsa: Array = []

# Un punto a 300 píxeles o más de otro
func punto_lejos_de(otro: Vector2) -> Vector2:
    var punto := Vector2.ZERO
    for intento: int in range(100):
        punto = Vector2(randf_range(0, 1280),
                randf_range(0, 720))
        if punto.distance_to(otro) >= 300:
            break  # Ya está lo bastante lejos
    return punto

func premio() -> String:
    if bolsa.is_empty():  # Se llena y se baraja
        bolsa = LLENA.duplicate()
        bolsa.shuffle()
    return bolsa.pop_back()
