extends Navegante  # Decide con una máquina

enum Estado { PATRULLAR, PERSEGUIR, BUSCAR }

@export var mundo: Mundo  # MainScene
@export var niblo: Node3D
@export var vista := 6.0  # Alcance, en metros
var estado := Estado.PATRULLAR
var espera := 0.0         # Segundos buscando
@onready var etiqueta: Label3D = $Etiqueta

func _ready() -> void:
    super()  # El _ready() de Navegante
    rapidez = Director.ajustar(2.0, 4.0)
    vista = Director.ajustar(4.0, 10.0)

func _physics_process(delta: float) -> void:
    match estado:
        Estado.PATRULLAR:
            patrullar()
        Estado.PERSEGUIR:
            perseguir()
        Estado.BUSCAR:
            buscar(delta)
        _:
            push_error("Estado inesperado")
    super(delta)  # Navegante lo mueve

func patrullar() -> void:
    if agente.is_navigation_finished():
        agente.target_position = mundo.al_azar()
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)

func perseguir() -> void:
    var donde := niblo.global_position
    if global_position.distance_to(donde) < 1.5:
        mundo.acabar(false)  # Lo ha atrapado
        return
    var meta := agente.target_position
    if meta.distance_to(donde) > 1.0:
        agente.target_position = donde
    if not ve_a_niblo():
        # Adonde iba: lo que avanza en 1 s
        agente.target_position += niblo.velocity
        cambiar_a(Estado.BUSCAR)

func buscar(delta: float) -> void:
    espera += delta  # Desde que lo perdió
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)
    elif espera > 6.0:
        cambiar_a(Estado.PATRULLAR)

func cambiar_a(nuevo: Estado) -> void:
    estado = nuevo
    espera = 0.0
    etiqueta.text = Estado.keys()[nuevo]

# Lo ve si está a menos de vista metros
func ve_a_niblo() -> bool:
    var donde := niblo.global_position
    var aqui := global_position
    return aqui.distance_to(donde) < vista

# Evento: un cuerpo entra en su oído
func _on_oido_body_entered(
        body: Node3D) -> void:
    if body != niblo:
        return  # Otro Mubbit, o él mismo
    if estado == Estado.PATRULLAR:
        var donde := niblo.global_position
        agente.target_position = donde
        cambiar_a(Estado.BUSCAR)
