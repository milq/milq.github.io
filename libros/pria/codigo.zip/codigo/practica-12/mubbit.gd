extends Navegante  # Mubbit decide con una máquina

enum Estado { PATRULLAR, PERSEGUIR, BUSCAR }


@export var mundo: Mundo  # MainScene, con mundo.gd
@export var niblo: Node3D
@export var vista := 6.0  # Metros hasta los que ve
var estado := Estado.PATRULLAR
var espera := 0.0         # Segundos que lleva buscando
@onready var etiqueta: Label3D = $Estado

func _ready() -> void:
    super()  # El _ready() de Navegante, con su señal
    rapidez = Director.ajustar(2.0, 4.0)
    vista = Director.ajustar(4.0, 10.0)

func _physics_process(delta: float) -> void:
    match estado:
        Estado.PATRULLAR:
            patrullar()
        Estado.PERSEGUIR:
            perseguir()
        Estado.BUSCAR:
            buscar(delta)
        _:
            push_error("Estado inesperado")
    super(delta)  # Navegante lo mueve

func patrullar() -> void:
    if agente.is_navigation_finished():
        agente.target_position = mundo.al_azar()
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)

func perseguir() -> void:
    var donde := niblo.global_position
    if global_position.distance_to(donde) < 1.5:
        mundo.acabar(false)  # Lo ha atrapado
        return
    if agente.target_position.distance_to(donde) > 1.0:
        agente.target_position = donde  # Se ha movido
    if not ve_a_niblo():
        # Adonde iba: lo que avanza en un segundo
        agente.target_position += niblo.velocity
        cambiar_a(Estado.BUSCAR)

func buscar(delta: float) -> void:
    espera += delta  # Segundos desde que lo perdió
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)
    elif espera > 6.0:
        cambiar_a(Estado.PATRULLAR)

func cambiar_a(nuevo: Estado) -> void:
    estado = nuevo
    espera = 0.0
    etiqueta.text = Estado.keys()[nuevo]  # Su nombre

# Lo ve si está a menos de vista metros
func ve_a_niblo() -> bool:
    var donde := niblo.global_position
    return global_position.distance_to(donde) < vista

