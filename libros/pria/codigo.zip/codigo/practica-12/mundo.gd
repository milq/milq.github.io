class_name Mundo
extends Node3D  # Construye el laberinto con un mapa

const MURO := preload("res://muro.tscn")
const SUELO := preload("res://suelo.tscn")
const SALIDA := preload("res://salida.tscn")
const LADO := 2.0  # Metros que mide cada casilla
var mapa := Laberinto.generar(
        13, 9, Vector2i(5, 3))

var red := AStarGrid2D.new()  # Para buscar caminos
@onready var region: NavigationRegion3D = $Region
var salida := Vector3.ZERO
var acabada := false

func _ready() -> void:
    Laberinto.abrir_atajos(mapa, 6)
    var ancho := mapa[0].length()
    var alto := mapa.size()
    red.region = Rect2i(0, 0, ancho, alto)
    var modo := AStarGrid2D.DIAGONAL_MODE_NEVER
    red.diagonal_mode = modo
    red.update()
    for y in range(alto):
        for x in range(ancho):
            var casilla := Vector2i(x, y)
            var tile := SUELO
            if mapa[y][x] == "#":
                tile = MURO
                red.set_point_solid(casilla)
            elif mapa[y][x] == "S":
                tile = SALIDA  # La salida
                salida = a_mundo(casilla)
            var nodo: Node3D = (
                    tile.instantiate())
            nodo.position += a_mundo(casilla)
            region.add_child(nodo)
    region.bake_navigation_mesh(false)

# Centro de una casilla, en el suelo
func a_mundo(casilla: Vector2i) -> Vector3:
    var x := (casilla.x + 0.5) * LADO
    var z := (casilla.y + 0.5) * LADO
    return Vector3(x, 0, z)

# Casilla en la que está un punto del suelo
func a_casilla(punto: Vector3) -> Vector2i:
    var p := Vector2(punto.x, punto.z) / LADO
    return Vector2i(p.floor())

# Camino A* entre dos puntos, por los centros
func camino(desde: Vector3,
        hasta: Vector3) -> Array[Vector3]:
    var puntos: Array[Vector3] = []
    var inicio := a_casilla(desde)
    var meta := a_casilla(hasta)
    if not red.is_in_boundsv(meta):
        return puntos  # Fuera del mapa, vacío
    for casilla in red.get_id_path(inicio, meta):
        puntos.append(a_mundo(casilla))
    return puntos

# Centro de una casilla de suelo al azar
func al_azar() -> Vector3:
    var casilla := Vector2i.ZERO  # Un muro
    while mapa[casilla.y][casilla.x] == "#":
        casilla.x = randi() % mapa[0].length()
        casilla.y = randi() % mapa.size()
    return a_mundo(casilla)

# Ajusta el reto y trae otro laberinto
func acabar(ha_salido: bool) -> void:
    if acabada:
        return  # Ya contada
    acabada = true
    if ha_salido:
        Director.gana()
    else:
        Director.pierde()
    var arbol := get_tree()
    arbol.reload_current_scene.call_deferred()

func _physics_process(_delta: float) -> void:
    var donde: Vector3 = $Niblo.position
    if donde.distance_to(salida) < 1.5:
        acabar(true)  # Ha llegado a la salida
