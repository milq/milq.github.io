class_name Laberinto
extends RefCounted  # No es un nodo

const SALTOS: Array[Vector2i] = [
        Vector2i(2, 0), Vector2i(-2, 0),
        Vector2i(0, 2), Vector2i(0, -2)]

# Columnas y filas impares; «S», la más lejana
static func generar(columnas: int, filas: int,
        desde: Vector2i) -> Array[String]:
    var mapa: Array[String] = []
    for fila in filas:
        mapa.append("#".repeat(columnas))
    var zona := Rect2i(1, 1,
            columnas - 2, filas - 2)
    var pila: Array[Vector2i] = [desde]
    var salida := desde
    var profundidad: int = 1
    mapa[desde.y][desde.x] = "."
    while not pila.is_empty():
        var actual: Vector2i = pila.back()
        var cerradas: Array[Vector2i] = []
        for salto in SALTOS:
            var c := actual + salto
            var dentro := zona.has_point(c)
            if dentro and mapa[c.y][c.x] == "#":
                cerradas.append(c)
        if cerradas.is_empty():
            pila.pop_back()  # Vuelve atrás
            continue
        var nueva: Vector2i = (
                cerradas.pick_random())
        var muro := (actual + nueva) / 2
        mapa[muro.y][muro.x] = "."
        mapa[nueva.y][nueva.x] = "."
        pila.push_back(nueva)
        if pila.size() > profundidad:
            profundidad = pila.size()
            salida = nueva
    mapa[salida.y][salida.x] = "S"
    return mapa

# Derriba muros al azar para que haya rodeos
static func abrir_atajos(mapa: Array[String],
        cuantos: int) -> void:
    var columnas := mapa[0].length()
    var filas := mapa.size()
    while cuantos > 0:
        var x := randi_range(1, columnas - 2)
        var y := randi_range(1, filas - 2)
        var impar := (x + y) % 2 == 1
        if impar and mapa[y][x] == "#":
            mapa[y][x] = "."
            cuantos -= 1
