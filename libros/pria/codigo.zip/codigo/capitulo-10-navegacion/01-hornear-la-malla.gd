extends NavigationRegion2D  # La sala, con la columna

func _ready() -> void:
    var malla := NavigationPolygon.new()
    malla.agent_radius = 20.0
    # El borde de la sala, por dentro del cual se anda
    malla.add_outline(PackedVector2Array([
            Vector2(0, 0), Vector2(600, 0),
            Vector2(600, 400), Vector2(0, 400)]))
    navigation_polygon = malla
    bake_navigation_polygon(false)  # En este hilo
    print(malla.get_polygon_count())  # 4
