extends NavigationRegion2D  # La sala

func _ready() -> void:
    var malla := NavigationPolygon.new()
    malla.agent_radius = 20.0
    var borde := PackedVector2Array([
            Vector2(0, 0), Vector2(600, 0),
            Vector2(600, 400), Vector2(0, 400)])
    malla.add_outline(borde)
    navigation_polygon = malla
    bake_navigation_polygon(false)
    print(malla.get_polygon_count())  # 4
