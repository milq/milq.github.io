extends CharacterBody2D  # El monstruo, con su agente

const RAPIDEZ := 200.0  # Píxeles por segundo
@export var jugador: Node2D
@onready var agente: NavigationAgent2D = $Agente

func _physics_process(_delta: float) -> void:
    var meta := jugador.global_position
    # Meta nueva solo si el jugador se ha alejado
    if agente.target_position.distance_to(meta) > 32.0:
        agente.target_position = meta
    if agente.is_navigation_finished():
        return
    var punto := agente.get_next_path_position()
    var hacia := global_position.direction_to(punto)
    velocity = hacia * RAPIDEZ
    move_and_slide()
