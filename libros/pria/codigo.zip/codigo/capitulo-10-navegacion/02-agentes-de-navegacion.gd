extends CharacterBody2D  # El monstruo

const RAPIDEZ := 200.0  # Píxeles por segundo
@export var jugador: Node2D
@onready var agente: NavigationAgent2D = $Agente

func _physics_process(_delta: float) -> void:
    var meta := jugador.global_position
    var anterior := agente.target_position
    # Meta nueva solo si se ha alejado
    if anterior.distance_to(meta) > 32.0:
        agente.target_position = meta
    if agente.is_navigation_finished():
        return
    var hacia := global_position.direction_to(
            agente.get_next_path_position())
    velocity = hacia * RAPIDEZ
    move_and_slide()
