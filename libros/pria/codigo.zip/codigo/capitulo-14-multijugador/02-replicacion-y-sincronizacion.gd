extends CharacterBody2D  # Lo mueve su dueño

func _enter_tree() -> void:
    set_multiplayer_authority(name.to_int())

func _ready() -> void:
    if is_multiplayer_authority():
        var x := randf_range(100, 1000)
        position = Vector2(x, 300)

func _physics_process(_delta: float) -> void:
    if not is_multiplayer_authority():
        return  # Lo mueve otro: solo se copia
    var direccion := Input.get_vector(
            "ui_left", "ui_right",
            "ui_up", "ui_down")
    velocity = direccion * 300.0
    move_and_slide()
