extends Node  # Crea una partida o se une a ella

const PUERTO: int = 4242

func _ready() -> void:
    var peer := ENetMultiplayerPeer.new()
    if "--servidor" in OS.get_cmdline_args():
        peer.create_server(PUERTO, 3)  # Tres clientes
    else:
        peer.create_client("127.0.0.1", PUERTO)
    multiplayer.multiplayer_peer = peer
    print(multiplayer.get_unique_id())  # 1, 27…
