extends Area2D  # La manzana: decide el servidor

var puntos := {}  # Identificador → manzanas
var paso := -1  # Fotograma del último toque

func _ready() -> void:
    body_entered.connect(_al_tocar)

func _al_tocar(jugador: Node2D) -> void:
    var f := Engine.get_physics_frames()
    if not multiplayer.is_server() or f == paso:
        return  # Un cliente, o un segundo toque
    paso = f  # Si tocan dos a la vez, uno solo
    sumar_punto.rpc(jugador.name.to_int())
    position.x = randf_range(100.0, 1000.0)
    position.y = randf_range(100.0, 500.0)

@rpc("authority", "call_local", "reliable")
func sumar_punto(id: int) -> void:
    puntos[id] = puntos.get(id, 0) + 1
    print(puntos)  # { 1: 1 }, { 1: 1, 27: 1 }…
