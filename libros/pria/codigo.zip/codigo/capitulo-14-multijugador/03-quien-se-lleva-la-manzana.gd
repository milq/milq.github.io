extends Area2D  # La manzana: solo decide el servidor

var puntos := {}  # Identificador de red → manzanas

func _ready() -> void:
    body_entered.connect(_al_tocar)

func _al_tocar(jugador: Node2D) -> void:
    if not multiplayer.is_server():
        return  # En los clientes, solo se ve
    sumar_punto.rpc(jugador.name.to_int())
    position.x = randf_range(100.0, 1000.0)
    position.y = randf_range(100.0, 500.0)

# El servidor avisa a todos, también a sí mismo
@rpc("authority", "call_local", "reliable")
func sumar_punto(id: int) -> void:
    puntos[id] = puntos.get(id, 0) + 1
    print(puntos)  # { 1: 1 }, { 1: 1, 27: 1 }…
