extends Node2D  # MainScene: hace saltar a Mubbit

const MARGEN := 48.0  # Que no quede pegado al borde
const DISTANCIA := 300.0

@onready var mubbit: Sprite2D = $Mubbit
@onready var niblo: Sprite2D = $Niblo
@onready var temporizador: Timer = $Timer

func _ready() -> void:
    seed(2026)
    temporizador.timeout.connect(saltar)

func saltar() -> void:
    mubbit.position = punto_lejos_de(niblo.position)
    # La próxima espera, entre 1 y 3 segundos
    temporizador.start(randf_range(1.0, 3.0))
    print("Mubbit: ", mubbit.position.round())

# Un punto al azar de la ventana, sin tocar los bordes
func punto_al_azar() -> Vector2:
    var ventana := get_viewport_rect().size
    var x := randf_range(MARGEN, ventana.x - MARGEN)
    var y := randf_range(MARGEN, ventana.y - MARGEN)
    return Vector2(x, y)

# Un punto al azar a DISTANCIA o más de otro punto
func punto_lejos_de(otro: Vector2) -> Vector2:
    var punto := punto_al_azar()
    for intento: int in range(100):
        if punto.distance_to(otro) >= DISTANCIA:
            break  # Ya está lo bastante lejos
        punto = punto_al_azar()
    return punto

var puntos: int = 0

func _process(_delta: float) -> void:
    # Un punto si Niblo toca a Mubbit antes del salto
    var objetivo := mubbit.position
    if niblo.position.distance_to(objetivo) < 48.0:
        puntos += 1
        print("¡Atrapado! Puntos: %d" % puntos)
        saltar()  # Salta ya y el Timer vuelve a contar
