extends Sprite2D  # Niblo: lo mueven las flechas

const RAPIDEZ := 200.0  # Píxeles por segundo

func _process(delta: float) -> void:
    # −1, 0 o 1 según las flechas pulsadas
    var x := Input.get_axis(
            "ui_left", "ui_right")
    var y := Input.get_axis("ui_up", "ui_down")
    # Módulo 1: así no va más rápido en diagonal
    var direccion := Vector2(x, y).normalized()
    position += direccion * RAPIDEZ * delta
    # Se da la vuelta hacia donde va
    if x < 0.0:
        scale.x = -1.0
    elif x > 0.0:
        scale.x = 1.0
    # Que se vea entero: 32 es medio Niblo
    position = position.clamp(Vector2(32, 32),
            Vector2(1248, 688))
