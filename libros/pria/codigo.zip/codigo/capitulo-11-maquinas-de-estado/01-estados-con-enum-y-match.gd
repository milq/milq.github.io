extends Sprite2D  # El monstruo, con su máquina

enum Estado { PATRULLAR, PERSEGUIR, ATACAR, BUSCAR }

@export var jugador: Node2D
var estado := Estado.PATRULLAR

func _physics_process(delta: float) -> void:
    var d := position.distance_to(jugador.position)
    match estado:
        Estado.PATRULLAR:
            patrullar(d, delta)
        Estado.PERSEGUIR:
            perseguir(d, delta)
        Estado.ATACAR:
            atacar(d)
        Estado.BUSCAR:
            buscar(d, delta)
        _:
            push_error("Estado inesperado")
