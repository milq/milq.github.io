extends Navegante  # Decide con una máquina

enum Estado { PATRULLAR, PERSEGUIR, BUSCAR }

const RUTA: Array[Vector2i] = [  # Las esquinas
    Vector2i(1, 1), Vector2i(10, 1),
    Vector2i(10, 5), Vector2i(1, 5),
]

@export var mundo: Mundo  # MainScene
@export var niblo: Node3D
@export var vista := 6.0  # Alcance, en metros
var siguiente: int = 0    # Esquina a la que va
var estado := Estado.PATRULLAR
var espera := 0.0         # Segundos buscando
@onready var etiqueta: Label3D = $Estado

func _physics_process(delta: float) -> void:
    match estado:
        Estado.PATRULLAR:
            patrullar()
        Estado.PERSEGUIR:
            perseguir()
        Estado.BUSCAR:
            buscar(delta)
        _:
            push_error("Estado inesperado")
    super(delta)  # Navegante lo mueve

func patrullar() -> void:
    if agente.is_navigation_finished():
        # A la siguiente esquina de la ruta
        agente.target_position = mundo.a_mundo(
                RUTA[siguiente])
        siguiente = posmod(siguiente + 1, 4)
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)

func perseguir() -> void:
    var donde := niblo.global_position
    var meta := agente.target_position
    if meta.distance_to(donde) > 1.0:
        agente.target_position = donde
    if not ve_a_niblo():
        # Adonde iba: lo que avanza en 1 s
        agente.target_position += niblo.velocity
        cambiar_a(Estado.BUSCAR)

func buscar(delta: float) -> void:
    espera += delta  # Desde que lo perdió
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)
    elif espera > 6.0:
        cambiar_a(Estado.PATRULLAR)

func cambiar_a(nuevo: Estado) -> void:
    estado = nuevo
    espera = 0.0
    etiqueta.text = Estado.keys()[nuevo]

# Lo ve si está a menos de vista metros
func ve_a_niblo() -> bool:
    var donde := niblo.global_position
    var aqui := global_position
    return aqui.distance_to(donde) < vista
