extends Node2D

func _ready() -> void:
    var monstruo := Vector2(200, 100)
    var jugador := Vector2(600, 400)
    var radio := 200.0
    print(monstruo.distance_to(jugador))  # 500.0
    var d2 := monstruo.distance_squared_to(jugador)
    print(d2 < radio * radio)  # false: está fuera
