extends Sprite2D

const RADIO: float = 200.0
var mirada := Vector2.RIGHT  # Hacia dónde mira

func _process(delta: float) -> void:
    var jug := get_global_mouse_position()
    var hacia := position.direction_to(jug)
    var d2 := position.distance_squared_to(jug)
    var cerca := d2 < RADIO * RADIO
    var delante := mirada.dot(hacia) > 0.71
    if cerca and delante:
        position += hacia * 120.0 * delta
