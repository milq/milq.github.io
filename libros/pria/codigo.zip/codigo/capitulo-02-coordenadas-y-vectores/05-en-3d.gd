extends Node3D

func _ready() -> void:
    var monstruo := Vector3(2, 0, 1)
    var jugador := Vector3(6, 12, 4)
    print(monstruo.distance_to(jugador))  # 13.0
    var normal := Vector3.RIGHT.cross(
            Vector3.UP)
    print(normal)  # (0.0, 0.0, 1.0)
