extends Sprite2D

func _process(delta: float) -> void:
    var direccion: Vector2 = Input.get_vector(
            "ui_left", "ui_right", "ui_up", "ui_down")
    position += direccion * 300.0 * delta
