extends Sprite2D

func _process(delta: float) -> void:
    var raton := get_global_mouse_position()
    var paso := 120.0 * delta
    position = position.move_toward(raton, paso)
