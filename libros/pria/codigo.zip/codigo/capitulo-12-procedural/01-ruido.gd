extends Node  # Una isla de 13 × 9 casillas con ruido

func _ready() -> void:
    var ruido := FastNoiseLite.new()
    ruido.noise_type = FastNoiseLite.TYPE_PERLIN
    ruido.fractal_type = FastNoiseLite.FRACTAL_NONE
    ruido.frequency = 0.2
    ruido.seed = 2026
    for y in 9:
        var fila := ""
        for x in 13:
            var v := ruido.get_noise_2d(x, y)
            if v < -0.1:
                fila += "~"  # Agua
            elif v < 0.2:
                fila += "."  # Hierba
            else:
                fila += "^"  # Montaña
        print(fila)
