extends Node  # Un laberinto perfecto de 13 × 9

const SALTOS: Array[Vector2i] = [
        Vector2i(2, 0), Vector2i(-2, 0),
        Vector2i(0, 2), Vector2i(0, -2)]

func _ready() -> void:
    seed(2026)
    var mapa: Array[String] = []
    for fila in 9:
        mapa.append("#".repeat(13))  # Todo muro
    var zona := Rect2i(1, 1, 11, 7)  # Sin borde
    var pila: Array[Vector2i] = [Vector2i(1, 1)]
    mapa[1][1] = "."
    while not pila.is_empty():
        var actual: Vector2i = pila.back()
        var cerradas: Array[Vector2i] = []
        for salto in SALTOS:
            var c := actual + salto
            var dentro := zona.has_point(c)
            if dentro and mapa[c.y][c.x] == "#":
                cerradas.append(c)
        if cerradas.is_empty():
            pila.pop_back()  # Vuelve atrás
            continue
        var nueva: Vector2i = (
                cerradas.pick_random())
        var muro := (actual + nueva) / 2
        mapa[muro.y][muro.x] = "."
        mapa[nueva.y][nueva.x] = "."
        pila.push_back(nueva)
    for fila in mapa:
        print(fila)
