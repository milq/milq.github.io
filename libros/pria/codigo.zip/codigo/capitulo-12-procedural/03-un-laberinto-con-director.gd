extends Node  # Ajusta el reto según juegas

var nivel := 0.3  # De 0, fácil, a 1, difícil

func gana() -> void:
    nivel = clampf(nivel + 0.1, 0.0, 1.0)

func pierde() -> void:
    nivel = clampf(nivel - 0.2, 0.0, 1.0)

func ajustar(
        facil: float, dificil: float) -> float:
    return lerpf(facil, dificil, nivel)
