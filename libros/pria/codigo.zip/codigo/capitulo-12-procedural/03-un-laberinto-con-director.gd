extends Node  # Director: ajusta el reto según juegas

var nivel := 0.3  # De 0, muy fácil, a 1, muy difícil

func gana() -> void:
    nivel = clampf(nivel + 0.1, 0.0, 1.0)

func pierde() -> void:
    nivel = clampf(nivel - 0.2, 0.0, 1.0)

func ajustar(facil: float, dificil: float) -> float:
    return lerpf(facil, dificil, nivel)
