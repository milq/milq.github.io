extends Sprite2D  # El jugador, girado 180°

func _ready() -> void:
    position = Vector2(600, 400)
    rotation_degrees = 180.0
    var monstruo := Vector2(200, 100)
    var local := to_local(monstruo).round()
    print(local)          # (400.0, 300.0)
    print(local.x > 0.0)  # true: delante
    print(local.y > 0.0)  # true: a su derecha
