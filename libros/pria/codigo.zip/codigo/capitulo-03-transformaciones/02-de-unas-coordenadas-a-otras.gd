extends Sprite2D  # El vehículo, girado 90°

func _ready() -> void:
    position = Vector2(300, 200)
    rotation_degrees = 90.0
    var jugador := Vector2(600, 600)
    var local := to_local(jugador)
    print(local)          # (400.0, -300.0)
    print(local.x > 0.0)  # true: delante
    print(local.y > 0.0)  # false: izquierda
