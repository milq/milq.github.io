extends Sprite2D  # El jugador, con la espada de hija

func _ready() -> void:
    position = Vector2(600, 400)
    $Espada.position = Vector2(50, 0)
    print($Espada.global_position)  # (650.0, 400.0)
    rotation_degrees = 90.0         # Gira el jugador
    print($Espada.position)         # (50.0, 0.0)
    print($Espada.global_position)  # (600.0, 450.0)
