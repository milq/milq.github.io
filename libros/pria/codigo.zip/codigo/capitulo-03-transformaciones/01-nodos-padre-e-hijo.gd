extends Sprite2D  # El jugador, con su varita

func _ready() -> void:
    position = Vector2(600, 600)
    $Varita.position = Vector2(50, 0)
    print($Varita.global_position)
    rotation_degrees = 90.0  # Gira el jugador
    print($Varita.position)
    print($Varita.global_position)
