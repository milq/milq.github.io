extends Node3D  # El cuerpo, con la cabeza de hija

func _ready() -> void:
    position = Vector3(6, 0, 4)
    $Cabeza.position = Vector3(0, 1.6, -0.2)
    rotation_degrees.y = 90.0       # Guiñada
    print($Cabeza.global_position)  # (5.8, 1.6, 4.0)
    print(-global_basis.z)          # (-1.0, 0.0, 0.0)
