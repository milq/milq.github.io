extends Node3D  # El cuerpo, con su cabeza

func _ready() -> void:
    position = Vector3(6, 0, 4)
    $Cabeza.position = Vector3(0, 1.6, -0.2)
    rotation_degrees.y = 90.0  # Guiñada
    print($Cabeza.global_position)
    print(-global_basis.z)
