extends Sprite2D  # El vehículo, con su lanzapelotas

func _ready() -> void:
    position = Vector2(200, 100)

func _process(delta: float) -> void:
    rotation_degrees += 30.0 * delta         # Gira
    position += transform.x * 100.0 * delta  # Avanza
    var jugador := get_global_mouse_position()
    if to_local(jugador).x > 0.0:  # Lo tiene delante
        $Lanzapelotas.look_at(jugador)
