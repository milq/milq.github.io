extends Sprite2D  # El vehículo

func _ready() -> void:
    position = Vector2(300, 200)

func _process(delta: float) -> void:
    rotation_degrees += 30.0 * delta
    position += transform.x * 100.0 * delta
    var jugador := get_global_mouse_position()
    if to_local(jugador).x > 0.0:
        $Lanzapelotas.look_at(jugador)
