extends Node  # Un generador del mundo y otro del combate

var rng_mundo := RandomNumberGenerator.new()
var rng_combate := RandomNumberGenerator.new()


func _ready() -> void:
	rng_mundo.seed = 2026     # El mismo mapa en cada partida
	rng_combate.randomize()   # Combates distintos cada vez
	var ancho := rng_mundo.randi_range(20, 40)
	var critico := rng_combate.randf() < 0.1  # 10 %
	print(ancho, " ", critico)
