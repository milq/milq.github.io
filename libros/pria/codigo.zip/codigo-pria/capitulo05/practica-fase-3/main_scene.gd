extends Node2D  # MainScene: Mubbit salta al azar con un Timer

const MARGEN := 48.0  # Que no quede pegado al borde

@onready var mubbit: Sprite2D = $Mubbit
@onready var temporizador: Timer = $Timer

func _ready() -> void:
    temporizador.timeout.connect(saltar)

func saltar() -> void:
    mubbit.position = punto_al_azar()
    # La próxima espera, entre 1 y 3 segundos
    temporizador.start(randf_range(1.0, 3.0))

# Un punto al azar de la ventana, sin tocar los bordes
func punto_al_azar() -> Vector2:
    var ventana := get_viewport_rect().size
    var x := randf_range(MARGEN, ventana.x - MARGEN)
    var y := randf_range(MARGEN, ventana.y - MARGEN)
    return Vector2(x, y)
