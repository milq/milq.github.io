extends Node  # La vida de un personaje

@export var vida_maxima := 100

var vida := 100

func cambiar_vida(cantidad: int) -> void:
    # Negativa para el daño y positiva para la cura
    vida = clampi(vida + cantidad, 0, vida_maxima)
    if vida == 0:
        print("Sin vida")
