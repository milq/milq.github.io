extends Sprite2D  # Una nave que atraviesa los bordes

@export var velocidad := Vector2(180, 60)  # Píxeles por segundo

func _process(delta: float) -> void:
    position += velocidad * delta
    var ventana := get_viewport_rect().size
    # wrapf: al pasar de un extremo, vuelve por el otro
    position.x = wrapf(position.x, 0.0, ventana.x)
    position.y = wrapf(position.y, 0.0, ventana.y)
