extends Node  # Un generador congruencial lineal

var estado := 7  # La semilla: el primer estado

func siguiente() -> int:
    # Multiplica, suma y se queda con el resto: de 0 a 99
    estado = (21 * estado + 17) % 100
    return estado

func _ready() -> void:
    for i in 8:
        printraw(siguiente(), " ")  # 64 61 98 75 92 49 46 83
