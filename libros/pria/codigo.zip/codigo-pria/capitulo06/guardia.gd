extends Node2D  # Un guardia que no ve a través de las paredes

@export var jugador: Node2D

@onready var rayo: RayCast2D = $RayCast2D

func hay_linea_de_vision() -> bool:
    # El destino del rayo se mide desde el propio guardia
    rayo.target_position = to_local(jugador.global_position)
    rayo.force_raycast_update()  # Recalcula el rayo ya
    if not rayo.is_colliding():
        return true  # No hay nada en medio
    return rayo.get_collider() == jugador  # Lo primero es él
