extends CharacterBody2D  # Un enemigo que persigue al ver

@export var rapidez := 140.0  # px/s

@onready var vision: Area2D = $Vision

var objetivo: Node2D = null  # A quién persigue, si a alguien

func _ready() -> void:
    vision.body_entered.connect(_on_entra)
    vision.body_exited.connect(_on_sale)

func _on_entra(body: Node2D) -> void:
    if body.is_in_group("jugador"):
        objetivo = body

func _on_sale(body: Node2D) -> void:
    if body == objetivo:
        objetivo = null

func _physics_process(_delta: float) -> void:
    velocity = Vector2.ZERO
    if objetivo:
        var donde := objetivo.global_position
        velocity = global_position.direction_to(donde) * rapidez
    move_and_slide()
