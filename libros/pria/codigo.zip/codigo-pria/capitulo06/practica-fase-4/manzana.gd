extends RigidBody2D  # Una manzana que cae, rebota y se recoge

func _ready() -> void:
    $Recoger.body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("jugador"):
        Marcador.sumar(1)  # El autoload, desde cualquier sitio
        queue_free()       # La manzana desaparece
