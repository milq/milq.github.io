extends Control  # Inicio y fin: un texto e Intro para jugar

func _ready() -> void:
    var datos := {"puntos": Marcador.puntos}  # Para {puntos}
    $Texto.text = $Texto.text.format(datos)

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_accept"):  # Intro
        Marcador.reiniciar()
        get_tree().change_scene_to_file("res://main_scene.tscn")
