extends Node  # Marcador: los puntos de toda la partida

signal cambiado(puntos: int)  # Avisa cuando cambian

var puntos := 0

func sumar(cantidad: int) -> void:
    puntos += cantidad
    cambiado.emit(puntos)

func reiniciar() -> void:
    puntos = 0
    cambiado.emit(puntos)
