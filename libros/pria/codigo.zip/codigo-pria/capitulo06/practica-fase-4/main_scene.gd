extends Node2D  # MainScene: puntos, sonido y final

const TOTAL := 5  # Manzanas que hay en la escena

@onready var etiqueta: Label = $Puntos
@onready var sonido: AudioStreamPlayer = $Sonido

func _ready() -> void:
    Marcador.cambiado.connect(_on_cambiado)

func _on_cambiado(puntos: int) -> void:
    etiqueta.text = "Puntos: %d" % puntos
    sonido.pitch_scale = randf_range(0.8, 1.2)  # Nunca igual
    sonido.play()
    if puntos == TOTAL:  # Ya no queda ninguna
        await get_tree().create_timer(0.5).timeout
        get_tree().change_scene_to_file("res://fin.tscn")
