extends Sprite2D  # Un proyectil con gravedad

var velocidad := Vector2(300, -500)  # Hacia arriba a la derecha
var gravedad := Vector2(0, 980)      # px/s², hacia abajo

func _process(delta: float) -> void:
    velocidad += gravedad * delta  # La gravedad, a la velocidad
    position += velocidad * delta  # La velocidad, a la posición
