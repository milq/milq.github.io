extends CharacterBody2D  # Un protagonista visto desde arriba

@export var rapidez := 200.0  # px/s

func _physics_process(_delta: float) -> void:
    # Sin gravedad: las cuatro flechas dan la dirección
    var direccion := Input.get_vector("ui_left", "ui_right",
            "ui_up", "ui_down")
    velocity = direccion * rapidez
    move_and_slide()  # Choca y se desliza por las paredes
