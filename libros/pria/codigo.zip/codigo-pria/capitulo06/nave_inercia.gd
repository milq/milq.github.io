extends Sprite2D  # Una nave con inercia

@export var empuje := 600.0   # Aceleración en px/s²
@export var frenado := 300.0  # Desaceleración sin teclas
@export var maxima := 350.0   # Rapidez máxima en px/s

var velocidad := Vector2.ZERO

func _process(delta: float) -> void:
    var x := Input.get_axis("ui_left", "ui_right")
    var y := Input.get_axis("ui_up", "ui_down")
    var direccion := Vector2(x, y).normalized()
    if direccion != Vector2.ZERO:
        # La aceleración cambia la velocidad
        velocidad += direccion * empuje * delta
    else:
        var paso := frenado * delta  # Frena poco a poco
        velocidad = velocidad.move_toward(Vector2.ZERO, paso)
    velocidad = velocidad.limit_length(maxima)
    position += velocidad * delta  # Y la velocidad, la posición
