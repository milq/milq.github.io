extends CharacterBody2D  # Un personaje de plataformas

@export var rapidez := 300.0       # px/s
@export var altura_salto := 128.0  # Píxeles

func _physics_process(delta: float) -> void:
    if not is_on_floor():  # En el aire, la gravedad actúa
        velocity += get_gravity() * delta
    var saltar := Input.is_action_just_pressed("ui_accept")
    if saltar and is_on_floor():
        velocity.y = -sqrt(2.0 * get_gravity().y * altura_salto)
    velocity.x = Input.get_axis("ui_left", "ui_right") * rapidez
    move_and_slide()
