extends CharacterBody2D  # Una pelota que rebota en todo

@export var rapidez := 400.0  # px/s

func _ready() -> void:
    velocity = Vector2(1, -1).normalized() * rapidez

func _physics_process(delta: float) -> void:
    # move_and_collide() se detiene al chocar y lo cuenta
    var choque := move_and_collide(velocity * delta)
    if choque:
        velocity = velocity.bounce(choque.get_normal())
