extends Area2D  # Hitbox: el área de un ataque, como una espada

func _ready() -> void:
    area_entered.connect(_on_area_entered)

# Ha entrado otra área: la hurtbox de un personaje
func _on_area_entered(area: Area2D) -> void:
    var victima := area.get_parent()  # El personaje
    if victima.has_method("recibir_golpe"):
        victima.recibir_golpe()
