extends Area2D  # Una moneda que se recoge al tocarla

signal recogida(valor: int)  # Su propia señal

@export var valor := 10

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("jugador"):  # Solo el jugador
        recogida.emit(valor)  # Avisa a quien le interese
        queue_free()          # Y desaparece
