extends Node  # Niblo aprende con Q-learning a llegar al queso

const MAPA: Array[String] = ["...Q", ".#.T", "N..."]
const ACCIONES: Array[Vector2i] = [
    Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]
const ALFA := 0.5     # Tasa de aprendizaje
const GAMMA := 0.9    # Factor de descuento
const EPSILON := 0.2  # Probabilidad de explorar

var q: Dictionary[Vector2i, Array] = {}  # Casilla → 4 valores

func _ready() -> void:
    seed(7)  # El mismo azar en cada ejecución
    for fila in MAPA.size():
        for columna in MAPA[fila].length():
            q[Vector2i(columna, fila)] = [0.0, 0.0, 0.0, 0.0]
    for episodio in 300:
        var total := episodio_desde(Vector2i(0, 2))
        print("Episodio ", episodio, ": ", total)
    mostrar()

# Un episodio, desde una casilla hasta el queso o la trampa
func episodio_desde(s: Vector2i) -> float:
    var total := 0.0  # Recompensa acumulada
    while letra(s) != "Q" and letra(s) != "T":
        var a := elegir(s)
        var s2 := mover(s, a)
        var r := recompensa(s2)
        var mejor: float = q[s2].max()  # Lo que espera allí
        q[s][a] += ALFA * (r + GAMMA * mejor - q[s][a])
        total += r
        s = s2
    return total

func elegir(s: Vector2i) -> int:
    if randf() < EPSILON:
        return randi() % ACCIONES.size()  # Explora
    var valores: Array = q[s]
    return valores.find(valores.max())  # Explota

func mover(s: Vector2i, a: int) -> Vector2i:
    var destino := s + ACCIONES[a]
    if not q.has(destino) or letra(destino) == "#":
        return s  # Fuera del mapa o contra el muro: no se mueve
    return destino

func recompensa(s: Vector2i) -> float:
    match letra(s):
        "Q":
            return 10.0   # El queso
        "T":
            return -10.0  # La trampa
    return -1.0  # Cada paso cuesta

func letra(s: Vector2i) -> String:
    return MAPA[s.y][s.x]

func mostrar() -> void:
    const FLECHAS := ["↑", "→", "↓", "←"]
    for fila in MAPA.size():
        var linea := ""
        for columna in MAPA[fila].length():
            var v: Array = q[Vector2i(columna, fila)]
            var i: int = v.find(v.max())  # La mejor acción
            linea += "%s %5.2f   " % [FLECHAS[i], v[i]]
        print(linea)

# El camino de Niblo con lo aprendido, sin explorar
func camino_aprendido(s: Vector2i) -> Array[Vector2i]:
    var camino: Array[Vector2i] = [s]
    for _paso in 20:  # Como mucho 20 pasos, por si no aprendió
        if letra(s) == "Q" or letra(s) == "T":
            break
        var v: Array = q[s]
        s = mover(s, v.find(v.max()))  # Siempre la mejor acción
        camino.append(s)
    return camino
