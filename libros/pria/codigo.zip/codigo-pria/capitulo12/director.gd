extends Node  # Director: ajusta la dificultad a cómo juegas

var nivel := 0.3  # De 0, muy fácil, a 1, muy difícil

# El jugador ha superado el reto: un poco más difícil
func gana() -> void:
    nivel = minf(nivel + 0.1, 1.0)

# El jugador ha perdido: más fácil, y más deprisa
func pierde() -> void:
    nivel = maxf(nivel - 0.2, 0.0)

# Un valor entre el de fácil y el de difícil, según el nivel
func ajustar(facil: float, dificil: float) -> float:
    return lerpf(facil, dificil, nivel)
