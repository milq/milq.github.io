class_name Laberinto
extends RefCounted  # Genera laberintos como mapas de texto

const SALTOS: Array[Vector2i] = [Vector2i(2, 0),  # A dos pasos
    Vector2i(-2, 0), Vector2i(0, 2), Vector2i(0, -2)]

# Columnas y filas impares; «S» es la casilla más lejana
static func generar(columnas: int, filas: int,
        desde: Vector2i) -> Array[String]:
    var mapa: Array[String] = []
    for fila in filas:
        mapa.append("#".repeat(columnas))  # Todo es muro
    var zona := Rect2i(1, 1, columnas - 2, filas - 2)
    var pila: Array[Vector2i] = [desde]
    var salida := desde
    var profundidad := 1
    mapa[desde.y][desde.x] = "."
    while not pila.is_empty():
        var actual: Vector2i = pila.back()
        var cerradas: Array[Vector2i] = []
        for salto in SALTOS:  # Casillas a dos pasos, sin abrir
            var c := actual + salto
            if zona.has_point(c) and mapa[c.y][c.x] == "#":
                cerradas.append(c)
        if cerradas.is_empty():
            pila.pop_back()  # Callejón sin salida: vuelve atrás
            continue
        var nueva: Vector2i = cerradas.pick_random()
        var muro := (actual + nueva) / 2
        mapa[muro.y][muro.x] = "."  # Abre el muro de en medio
        mapa[nueva.y][nueva.x] = "."
        pila.push_back(nueva)
        if pila.size() > profundidad:  # La más lejana
            profundidad = pila.size()
            salida = nueva
    mapa[salida.y][salida.x] = "S"
    return mapa
