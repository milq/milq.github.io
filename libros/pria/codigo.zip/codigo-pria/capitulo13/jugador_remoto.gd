extends Node2D  # El personaje de otro jugador, visto por la red

var recibida := Vector2.ZERO   # Última posición que llegó
var velocidad := Vector2.ZERO  # Y su velocidad en ese momento

# La llama el código de red al recibir un paquete
func al_recibir(posicion: Vector2, nueva: Vector2) -> void:
    recibida = posicion
    velocidad = nueva

func _process(delta: float) -> void:
    recibida += velocidad * delta  # Supone que sigue igual
    position = position.lerp(recibida, 10.0 * delta)
