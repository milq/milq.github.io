extends Control  # Un chat para la red local, con salas

const PUERTO := 4242           # Por él viajan los mensajes
const PUERTO_ANUNCIOS := 4243  # Por él se anuncian las salas
var servidor := UDPServer.new()          # Si creas una sala
var clientes: Array[PacketPeerUDP] = []  # Los que se han unido
var conexion := PacketPeerUDP.new()      # Si te unes a una sala
var anuncios := PacketPeerUDP.new()      # Anunciar o buscar
@onready var nombre: LineEdit = %Nombre
@onready var salas: ItemList = %Salas
@onready var mensajes: RichTextLabel = %Mensajes
@onready var texto: LineEdit = %Texto

func _ready() -> void:
    %Crear.pressed.connect(crear_sala)
    %Buscar.pressed.connect(buscar_salas)
    salas.item_activated.connect(unirse)  # Doble clic
    %Enviar.pressed.connect(enviar_texto)
    texto.text_submitted.connect(enviar_texto.unbind(1))
    $Anunciar.timeout.connect(anunciar)

# «Crear sala»: espera jugadores y se anuncia en la red local
func crear_sala() -> void:
    servidor.listen(PUERTO)
    anuncios.set_broadcast_enabled(true)
    var todos := "255.255.255.255"  # Difusión: toda la red
    anuncios.set_dest_address(todos, PUERTO_ANUNCIOS)
    $Anunciar.start()  # Un anuncio por segundo
    mostrar({"nombre": nombre.text,
        "texto": "ha creado la sala"})

func anunciar() -> void:
    var sala := "Sala de " + nombre.text
    anuncios.put_packet(sala.to_utf8_buffer())

# «Buscar salas»: escucha los anuncios de la red local
func buscar_salas() -> void:
    anuncios.bind(PUERTO_ANUNCIOS)

# Cada sala nueva se añade a la lista, con su dirección IP
func recibir_anuncios() -> void:
    while anuncios.get_available_packet_count() > 0:
        var sala := anuncios.get_packet().get_string_from_utf8()
        var ip := anuncios.get_packet_ip()
        var fila := "%s (%s)" % [sala, ip]
        if not ya_esta(fila):
            var i := salas.add_item(fila)
            salas.set_item_metadata(i, ip)  # La IP, escondida

func ya_esta(fila: String) -> bool:
    for i in salas.item_count:
        if salas.get_item_text(i) == fila:
            return true
    return false

# Doble clic en una sala: se une a ella y saluda
func unirse(indice: int) -> void:
    var ip: String = salas.get_item_metadata(indice)
    conexion.connect_to_host(ip, PUERTO)
    enviar({"nombre": nombre.text, "texto": "se ha unido"})

# «Enviar»: el servidor reparte; un cliente envía al servidor
func enviar_texto() -> void:
    var mensaje := {"nombre": nombre.text, "texto": texto.text}
    if servidor.is_listening():
        repartir(mensaje)
    else:
        enviar(mensaje)
    texto.clear()

func enviar(mensaje: Dictionary) -> void:
    var texto_json := JSON.stringify(mensaje)
    conexion.put_packet(texto_json.to_utf8_buffer())

func leer(paquete: PackedByteArray) -> Dictionary:
    var texto_json := paquete.get_string_from_utf8()
    var mensaje = JSON.parse_string(texto_json)
    return mensaje if mensaje is Dictionary else {}

func mostrar(mensaje: Dictionary) -> void:
    if mensaje.has("nombre") and mensaje.has("texto"):
        mensajes.append_text("[b]%s:[/b] %s\n" % [
            mensaje["nombre"], mensaje["texto"]])

func _process(_delta: float) -> void:
    recibir_anuncios()
    if servidor.is_listening():
        servidor.poll()  # Atiende a los que llegan
        while servidor.is_connection_available():
            clientes.append(servidor.take_connection())
        for cliente in clientes:
            while cliente.get_available_packet_count() > 0:
                repartir(leer(cliente.get_packet()))
    while conexion.get_available_packet_count() > 0:
        mostrar(leer(conexion.get_packet()))

# El servidor enruta: muestra el mensaje y se lo manda a todos
func repartir(mensaje: Dictionary) -> void:
    mostrar(mensaje)
    var paquete := JSON.stringify(mensaje).to_utf8_buffer()
    for cliente in clientes:
        cliente.put_packet(paquete)
