extends Node2D

@export var giro := 180.0  # Grados por segundo

func _process(delta: float) -> void:
    # La hélice gira un poco en cada fotograma
    $Helice.rotation_degrees += giro * delta
    # La torreta calcula su giro para mirar al ratón
    $Torreta.look_at(get_global_mouse_position())
