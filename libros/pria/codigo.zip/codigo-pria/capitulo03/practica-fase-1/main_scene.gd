extends Node2D  # MainScene: Mubbit persigue a Niblo

const RAPIDEZ := 100.0  # Mubbit es más lento que Niblo

@onready var niblo: Sprite2D = $Niblo
@onready var mubbit: Sprite2D = $Mubbit

var tiempo := 0.0  # Segundos desde el último mensaje

func _process(delta: float) -> void:
    # Vector que va de Mubbit a Niblo: extremo menos origen
    var hacia_niblo := niblo.position - mubbit.position
    var direccion := hacia_niblo.normalized()
    mubbit.position += direccion * RAPIDEZ * delta
    # Una vez por segundo, la distancia y el punto medio
    tiempo += delta
    if tiempo >= 1.0:
        tiempo = 0.0
        var d := niblo.position.distance_to(mubbit.position)
        var medio := (niblo.position + mubbit.position) / 2.0
        var texto := "Distancia: %d px, punto medio: %s"
        print(texto % [d, medio.round()])
