extends Sprite2D  # Un protagonista que se mueve con las flechas

const RAPIDEZ := 150.0  # Píxeles por segundo

func _process(delta: float) -> void:
    # −1, 0 o 1 según las flechas pulsadas
    var x := Input.get_axis("ui_left", "ui_right")
    var y := Input.get_axis("ui_up", "ui_down")
    # Módulo 1: así no va más rápido en diagonal
    var direccion := Vector2(x, y).normalized()
    position += direccion * RAPIDEZ * delta
