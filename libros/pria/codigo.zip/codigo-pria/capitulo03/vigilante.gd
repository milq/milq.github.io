extends Sprite2D  # Un enemigo que vigila su zona

@export var jugador: Node2D
@export var radio := 200.0  # Píxeles

func _process(_delta: float) -> void:
    var d := position.distance_to(jugador.position)
    # Rojo si el jugador ha entrado en su zona
    modulate = Color.RED if d < radio else Color.WHITE
