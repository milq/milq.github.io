extends Sprite2D  # Una nave vista desde arriba

@export var velocidad := 250.0
@export var giro := 3.0  # Radianes por segundo

func _process(delta: float) -> void:
    # Las flechas izquierda y derecha giran la nave
    var g := Input.get_axis("ui_left", "ui_right")
    rotation += g * giro * delta
    # Avanza siempre hacia su eje X: hacia donde mira
    position += transform.x * velocidad * delta
