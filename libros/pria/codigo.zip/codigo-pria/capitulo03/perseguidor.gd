extends Sprite2D  # Un enemigo que persigue

@export var objetivo: Node2D
@export var rapidez := 100.0  # Píxeles por segundo

func _process(delta: float) -> void:
    var hacia := objetivo.position - position
    # Si ya está encima, no se mueve: así no tiembla
    if hacia.length() < 4.0:
        return
    position += hacia.normalized() * rapidez * delta
