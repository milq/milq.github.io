extends Vehiculo  # Un zombi que combina tres comportamientos

@export var jugador: CharacterBody2D

func _physics_process(delta: float) -> void:
    var zombis := get_tree().get_nodes_in_group("zombis")
    var fuerza := perseguir(jugador) * 1.0
    fuerza += separar(zombis) * 1.5
    fuerza += evitar($RayCast2D) * 3.0
    mover(fuerza, delta)
