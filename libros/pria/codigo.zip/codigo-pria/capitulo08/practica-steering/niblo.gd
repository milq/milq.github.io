extends Vehiculo  # Niblo sigue al ratón y se para encima

func _physics_process(delta: float) -> void:
    var raton := get_global_mouse_position()
    mover(llegar(raton, 150.0), delta)
