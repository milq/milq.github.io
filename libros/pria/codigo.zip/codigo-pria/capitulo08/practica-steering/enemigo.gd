extends Vehiculo  # Un enemigo que busca la nave o huye de ella

@export var objetivo: Node2D  # La nave del jugador
@export var huye := false     # Si huye en lugar de buscar

func _ready() -> void:
    add_to_group("enemigos")  # Así se encuentran unos a otros

func _physics_process(delta: float) -> void:
    var fuerza := buscar(objetivo.position)
    if huye:
        fuerza = huir(objetivo.position, 250.0)
    var vecinos := get_tree().get_nodes_in_group("enemigos")
    fuerza += separar(vecinos) * 1.5  # Sin amontonarse
    mover(fuerza, delta)
    var ventana := get_viewport_rect().size
    position = position.clamp(Vector2.ZERO, ventana)  # Dentro

# Si toca la nave, la caza o es cazado
func comprobar_choque() -> void:
    if position.distance_to(objetivo.position) > 52.0:
        return  # Dos círculos de 24 px: no se tocan
    if not huye:  # Te ha cazado: la partida vuelve a empezar
        get_tree().reload_current_scene.call_deferred()
        return
    remove_from_group("enemigos")  # La nave lo ha cazado
    queue_free()
    for otro in get_tree().get_nodes_in_group("enemigos"):
        if otro.huye:
            return  # Aún queda alguna presa
    print("¡Has cazado a todas las presas!")
    get_tree().reload_current_scene.call_deferred()
