extends Vehiculo  # La nave: va adonde haces clic derecho

var destino := Vector2.ZERO

func _ready() -> void:
    destino = position  # Al empezar, se queda donde está

func _physics_process(delta: float) -> void:
    mover(llegar(destino, 120.0), delta)

func _unhandled_input(event: InputEvent) -> void:
    var clic := event as InputEventMouseButton
    if clic and clic.pressed:
        if clic.button_index == MOUSE_BUTTON_RIGHT:
            destino = get_global_mouse_position()
