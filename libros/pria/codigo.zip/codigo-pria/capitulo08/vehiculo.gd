class_name Vehiculo
extends CharacterBody2D  # Un personaje que se mueve con fuerzas

@export var rapidez_maxima := 250.0  # px/s
@export var fuerza_maxima := 600.0   # Su aceleración es F / m
@export var masa := 1.0              # Más masa, menos agilidad
@export var gira := true             # Si mira hacia donde va

# Corrige la velocidad con la fuerza de dirección y se mueve
func mover(fuerza: Vector2, delta: float) -> void:
    var aceleracion := fuerza_maxima / masa  # a = F / m
    # Corrige lo que le falta, pero como mucho lo que da de sí
    velocity += fuerza.limit_length(aceleracion * delta)
    velocity = velocity.limit_length(rapidez_maxima)
    move_and_slide()
    if gira and velocity.length() > 10.0:
        rotation = Vector2.UP.angle_to(velocity)

# Buscar: ir hacia un punto a toda velocidad
func buscar(punto: Vector2) -> Vector2:
    var deseada := position.direction_to(punto) * rapidez_maxima
    return deseada - velocity

# Huir: alejarse de un punto, si está a menos de «panico» px
func huir(punto: Vector2, panico := 250.0) -> Vector2:
    if position.distance_to(punto) > panico:
        return -velocity  # Ya está a salvo: frena
    var deseada := punto.direction_to(position) * rapidez_maxima
    return deseada - velocity

# Llegar: buscar, pero frenando dentro del radio de frenado
func llegar(punto: Vector2, frenado := 150.0) -> Vector2:
    var hacia := punto - position
    var factor := minf(hacia.length() / frenado, 1.0)
    var deseada := hacia.normalized() * rapidez_maxima * factor
    return deseada - velocity

# Perseguir: buscar el punto donde estará el otro
func perseguir(otro: CharacterBody2D) -> Vector2:
    var distancia := position.distance_to(otro.position)
    var t := distancia / rapidez_maxima  # Segundos
    return buscar(otro.position + otro.velocity * t)

# Evadir: huir del punto donde estará el perseguidor
func evadir(otro: CharacterBody2D, panico := 250.0) -> Vector2:
    var distancia := position.distance_to(otro.position)
    var t := distancia / rapidez_maxima
    return huir(otro.position + otro.velocity * t, panico)

var angulo_vagar := randf() * TAU  # Dónde está el punto

# Vagar: buscar un punto de un círculo que va por delante
func vagar(delta: float) -> Vector2:
    angulo_vagar += randf_range(-3.0, 3.0) * delta
    var centro := position + velocity.normalized() * 100.0
    var punto := centro + Vector2.from_angle(angulo_vagar) * 60
    return buscar(punto)

# Evitar obstáculos: un rayo hacia delante
func evitar(rayo: RayCast2D) -> Vector2:
    var delante := velocity.normalized()
    var largo := 40.0 + velocity.length() * 0.5  # Más si corre
    var punta := global_position + delante * largo
    rayo.target_position = rayo.to_local(punta)
    rayo.force_raycast_update()
    if not rayo.is_colliding():
        return Vector2.ZERO
    # Gira hacia el lado al que apunta la normal del obstáculo
    var lado := delante.orthogonal()
    if lado.dot(rayo.get_collision_normal()) < 0.0:
        lado = -lado
    return lado * fuerza_maxima

var punto_actual := 0  # Índice del punto del camino al que va

# Seguir un camino: buscar cada punto y pasar al siguiente
func seguir_camino(camino: PackedVector2Array) -> Vector2:
    if position.distance_to(camino[punto_actual]) < 30.0:
        punto_actual = (punto_actual + 1) % camino.size()
    return buscar(camino[punto_actual])

func separar(vecinos: Array[Node], radio := 60.0) -> Vector2:
    var lejos := Vector2.ZERO
    for nodo in vecinos:
        var otro := nodo as Node2D
        var desde := position - otro.position
        if otro != self and desde.length() < radio:
            # Cuanto más cerca está el vecino, más pesa
            var cerca := radio - desde.length()
            lejos += desde.normalized() * cerca
    if lejos == Vector2.ZERO:
        return Vector2.ZERO
    return lejos.normalized() * rapidez_maxima - velocity

func alinear(vecinos: Array[Node], radio := 120.0) -> Vector2:
    var suma := Vector2.ZERO
    for nodo in vecinos:
        var otro := nodo as CharacterBody2D
        var distancia := position.distance_to(otro.position)
        if otro != self and distancia < radio:
            suma += otro.velocity
    if suma == Vector2.ZERO:
        return Vector2.ZERO
    return suma.normalized() * rapidez_maxima - velocity

func cohesion(vecinos: Array[Node], radio := 120.0) -> Vector2:
    var centro := Vector2.ZERO
    var cuantos := 0
    for nodo in vecinos:
        var otro := nodo as Node2D
        var distancia := position.distance_to(otro.position)
        if otro != self and distancia < radio:
            centro += otro.position
            cuantos += 1
    if cuantos == 0:
        return Vector2.ZERO
    return buscar(centro / cuantos)  # Su centro (capítulo 3)

# Seguir al líder: llegar a un punto que está detrás de él
func seguir(lider: CharacterBody2D, hueco := 60.0) -> Vector2:
    if lider.velocity.length() < 10.0:
        return llegar(position)  # Quiere estar quieto: frena
    var detras := -lider.velocity.normalized() * hueco
    return llegar(lider.position + detras)
