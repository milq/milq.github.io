class_name Mapa
extends TileMapLayer  # Datos: «transitable» y «coste»

var rejilla := AStarGrid2D.new()

func _ready() -> void:
    rejilla.region = get_used_rect()  # Las casillas pintadas
    rejilla.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
    rejilla.update()  # Crea las casillas: antes que nada
    for casilla in get_used_cells():
        var datos := get_cell_tile_data(casilla)
        if not datos.get_custom_data("transitable"):
            rejilla.set_point_solid(casilla)
        var coste: float = datos.get_custom_data("coste")
        rejilla.set_point_weight_scale(casilla, coste)

# Camino de un punto a otro, por el centro de las casillas
func camino(desde: Vector2, hasta: Vector2) -> Array[Vector2]:
    var a := local_to_map(to_local(desde))
    var b := local_to_map(to_local(hasta))
    var puntos: Array[Vector2] = []
    for casilla in rejilla.get_id_path(a, b):
        puntos.append(to_global(map_to_local(casilla)))
    return puntos
