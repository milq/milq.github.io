extends CharacterBody2D  # Un guardia que patrulla

@export var ruta: Node2D           # Sus hijos son los Marker2D
@export var rapidez := 120.0       # px/s
@export var ida_y_vuelta := false  # Si no, va en bucle

var puntos: Array[Vector2] = []
var actual := 0   # Índice del punto al que va
var sentido := 1  # 1 hacia delante; -1 hacia atrás

func _ready() -> void:
    for marca in ruta.get_children():
        puntos.append((marca as Marker2D).global_position)

func _physics_process(_delta: float) -> void:
    var meta := puntos[actual]
    if global_position.distance_to(meta) < 4.0:
        var siguiente := actual + sentido
        var fuera := siguiente < 0 or siguiente >= puntos.size()
        if ida_y_vuelta and fuera:
            sentido = -sentido  # En un extremo, da la vuelta
        actual = posmod(actual + sentido, puntos.size())
    velocity = global_position.direction_to(meta) * rapidez
    move_and_slide()
