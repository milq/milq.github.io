class_name Caminante
extends Sprite3D  # Un personaje que recorre caminos del mapa

@export var mundo: Mundo     # MainScene, con mundo.gd
@export var rapidez := 4.0   # Metros por segundo

var camino: Array[Vector3] = []

# Pide al mundo el camino más corto hasta un punto
func ir_a(punto: Vector3) -> void:
    camino = mundo.camino(position, punto)
    # Si ya va hacia el segundo punto, no vuelve al primero
    if camino.size() > 1:
        var aqui := Vector3(position.x, 0.0, position.z)
        if aqui.distance_to(camino[1]) < Mundo.LADO:
            camino.pop_front()

func _process(delta: float) -> void:
    if camino.is_empty():
        return
    # El siguiente punto, a la altura del personaje
    var meta := Vector3(camino[0].x, position.y, camino[0].z)
    position = position.move_toward(meta, rapidez * delta)
    if position == meta:  # move_toward() llega justo
        camino.pop_front()
