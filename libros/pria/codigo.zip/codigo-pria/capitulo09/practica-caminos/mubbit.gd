extends Caminante  # Mubbit patrulla las letras del mapa

const RUTA: Array[String] = ["A", "B", "C", "D"]
var siguiente: int = 0  # Índice de la letra a la que va


func _process(delta: float) -> void:
	if camino.is_empty():  # Ha llegado: a por la siguiente
		ir_a(mundo.buscar(RUTA[siguiente]))
		siguiente = (siguiente + 1) % RUTA.size()
	super(delta)  # El _process() de Caminante lo mueve
