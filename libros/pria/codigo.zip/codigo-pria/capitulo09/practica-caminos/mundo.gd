class_name Mundo
extends Node3D  # Construye el laberinto con un mapa de texto

const MURO := preload("res://muro.tscn")
const SUELO := preload("res://suelo.tscn")
const LADO := 2.0  # Metros que mide cada casilla
const MAPA: Array[String] = [
    "############",
    "#A........B#",
    "#.##.####..#",
    "#.#......#.#",
    "#.#.##.#.#.#",
    "#...#..#...#",
    "#.###.####.#",
    "#D........C#",
    "############",
]

var rejilla := AStarGrid2D.new()  # Para buscar caminos

func _ready() -> void:
    rejilla.region = Rect2i(0, 0, MAPA[0].length(), MAPA.size())
    rejilla.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
    rejilla.update()
    for fila in MAPA.size():
        for columna in MAPA[fila].length():
            var casilla := Vector2i(columna, fila)
            var tile := SUELO
            if MAPA[fila][columna] == "#":
                tile = MURO
                rejilla.set_point_solid(casilla)
            var nodo: Node3D = tile.instantiate()
            nodo.position = a_mundo(casilla)
            add_child(nodo)

# Centro de una casilla, en el suelo del mundo 3D
func a_mundo(casilla: Vector2i) -> Vector3:
    return Vector3(casilla.x + 0.5, 0.0, casilla.y + 0.5) * LADO

# Casilla en la que está un punto del mundo 3D
func a_casilla(punto: Vector3) -> Vector2i:
    var columna := floori(punto.x / LADO)
    var fila := floori(punto.z / LADO)
    return Vector2i(columna, fila)

func buscar(letra: String) -> Vector3:
    for fila in MAPA.size():
        var columna := MAPA[fila].find(letra)
        if columna >= 0:  # find() da −1 si no está
            return a_mundo(Vector2i(columna, fila))
    return Vector3.ZERO

# Camino con A* entre dos puntos, por el centro de las casillas
func camino(desde: Vector3, hasta: Vector3) -> Array[Vector3]:
    var a := a_casilla(desde)
    var b := a_casilla(hasta)
    var puntos: Array[Vector3] = []
    if not rejilla.is_in_boundsv(b):
        return puntos  # Fuera del mapa: no hay camino
    for casilla in rejilla.get_id_path(a, b):
        puntos.append(a_mundo(casilla))
    return puntos
