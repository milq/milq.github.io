extends Sprite2D  # Un satélite que orbita

@export var centro := Vector2(400, 300)
@export var radio := 120.0
@export var vueltas_por_segundo := 0.5

var angulo := 0.0

func _process(delta: float) -> void:
    angulo += TAU * vueltas_por_segundo * delta
    # cos da la x y sin da la y del punto de la circunferencia
    var punto := Vector2(cos(angulo), sin(angulo)) * radio
    position = centro + punto
