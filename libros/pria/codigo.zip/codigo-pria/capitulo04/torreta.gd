extends Sprite2D  # Una torreta dibujada mirando a la derecha

@export var jugador: Node2D
@export var giro := 90.0  # Grados por segundo

func _process(delta: float) -> void:
    var hacia := jugador.global_position - global_position
    var paso := deg_to_rad(giro) * delta
    # Gira por el camino más corto, como mucho «paso» radianes
    rotation = rotate_toward(rotation, hacia.angle(), paso)
