extends PathFollow2D  # Hijo de un Path2D con la ruta

@export var duracion := 4.0  # Segundos de un extremo a otro

func _ready() -> void:
    var tween := create_tween().set_loops()
    tween.set_trans(Tween.TRANS_SINE)
    tween.set_ease(Tween.EASE_IN_OUT)
    # Ida y vuelta por la ruta, sin parar
    tween.tween_property(self, "progress_ratio", 1.0, duracion)
    tween.tween_property(self, "progress_ratio", 0.0, duracion)
