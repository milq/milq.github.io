extends Sprite2D

@export var destino := Vector2(600, 300)
@export var duracion := 2.0  # Segundos que tarda

var origen: Vector2
var tiempo := 0.0

func _ready() -> void:
    origen = position

func _process(delta: float) -> void:
    tiempo += delta
    # t pasa de 0 a 1 en «duracion» segundos
    var t := minf(tiempo / duracion, 1.0)
    position = origen.lerp(destino, t)
