extends Sprite2D  # Un guardia dibujado mirando a la derecha

@export var jugador: Node2D
@export var campo_de_vision := 90.0  # Grados en total
@export var alcance := 300.0         # Píxeles

func ve_al_jugador() -> bool:
    var hacia := jugador.global_position - global_position
    if hacia.length() > alcance:
        return false
    # Hacia dónde mira el guardia, según su rotación
    var mirada := Vector2.from_angle(rotation)
    var angulo := absf(rad_to_deg(mirada.angle_to(hacia)))
    return angulo <= campo_de_vision / 2.0

func _process(_delta: float) -> void:
    modulate = Color.RED if ve_al_jugador() else Color.WHITE
