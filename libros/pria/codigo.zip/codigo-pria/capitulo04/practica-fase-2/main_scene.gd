extends Node2D  # MainScene: las reglas del juego

@onready var niblo: Sprite2D = $Niblo
@onready var mubbit: Sprite2D = $Mubbit
@onready var manzana: Sprite2D = $Manzana
@onready var casa: TextureRect = $Casa

func _process(_delta: float) -> void:
    var en_casa := casa.get_rect().has_point(niblo.position)
    if mubbit.ve_a_niblo():
        atrapado()
    elif manzana.cogida and en_casa:
        ganar()

func atrapado() -> void:
    manzana.cogida = false  # Vuelve flotando a su sitio
    niblo.position = casa.get_rect().get_center()
    niblo.scale = Vector2.ZERO  # Reaparece en casa
    var tween := create_tween().set_trans(Tween.TRANS_BACK)
    tween.tween_property(niblo, "scale", Vector2.ONE, 0.4)

func ganar() -> void:
    set_process(false)  # Ya no se comprueban las reglas
    manzana.set_process(false)  # Deja de seguir a Niblo
    var tween := create_tween().set_trans(Tween.TRANS_BACK)
    tween.tween_property(manzana, "scale", Vector2(2, 2), 0.4)
    tween.tween_property(manzana, "modulate:a", 0.0, 0.3)
    tween.tween_callback(get_tree().reload_current_scene)
