extends Sprite2D  # Mubbit: vigila la manzana como un faro

@export var manzana: Node2D
@export var niblo: Node2D
@export var radio := 160.0
@export var vueltas_por_segundo := 0.2
@export var campo_de_vision := 60.0  # Grados en total
@export var alcance := 300.0         # Píxeles

var angulo := 0.0  # Dónde está y hacia dónde mira
@onready var centro := manzana.position  # Su sitio de siempre
@onready var vista: Polygon2D = $Vista

func _ready() -> void:
    # El cono: el vértice y nueve puntos del arco
    var puntos := PackedVector2Array([Vector2.ZERO])
    for i in 9:
        var a := deg_to_rad(campo_de_vision * (i / 8.0 - 0.5))
        puntos.append(Vector2.from_angle(a) * alcance)
    vista.polygon = puntos
    vista.color = Color(1, 1, 1, 0.3)  # Blanco translúcido

func _process(delta: float) -> void:
    angulo += TAU * vueltas_por_segundo * delta
    # Da vueltas a la manzana y mira hacia fuera
    position = centro + Vector2.from_angle(angulo) * radio
    vista.rotation = angulo

# El guardia de la sección 4.2, con la mirada de la vista
func ve_a_niblo() -> bool:
    var hacia := niblo.position - position
    if hacia.length() > alcance:
        return false
    var mirada := Vector2.from_angle(angulo)
    var diferencia := absf(rad_to_deg(mirada.angle_to(hacia)))
    return diferencia <= campo_de_vision / 2.0
