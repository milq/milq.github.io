extends Sprite2D  # La manzana: flota y sigue a quien la coge

@export var niblo: Node2D
@export var suavidad := 5.0  # Cuanto mayor, más pegada va

var cogida := false
var tiempo := 0.0
@onready var origen := position  # Su sitio, para volver

func _process(delta: float) -> void:
    tiempo += delta
    offset.y = 8.0 * sin(tiempo * 3.0)  # Flota: solo el dibujo
    var meta := origen
    if cogida:
        meta = niblo.position + Vector2(0, -48)  # Sobre Niblo
    elif position.distance_to(niblo.position) < 48.0:
        cogida = true  # Niblo la ha alcanzado
    position = position.lerp(meta, suavidad * delta)
