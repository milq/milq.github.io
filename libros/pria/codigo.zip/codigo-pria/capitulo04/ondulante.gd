extends Sprite2D  # Avanza ondulando

const MARGEN := 32.0

@export var velocidad := 200.0  # Píxeles por segundo
@export var y_centro := 300.0
@export var amplitud := 50.0    # Píxeles arriba y abajo
@export var frecuencia := 4.0   # Rapidez de la onda

var tiempo := 0.0

func _process(delta: float) -> void:
    tiempo += delta
    position.x += velocidad * delta
    position.y = y_centro + amplitud * sin(tiempo * frecuencia)
    # Al salir por la derecha, vuelve a entrar por la izquierda
    if position.x > get_viewport_rect().size.x + MARGEN:
        position.x = -MARGEN
