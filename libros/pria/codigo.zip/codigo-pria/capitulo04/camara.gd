extends Camera2D

@export var objetivo: Node2D
@export var suavidad := 5.0  # Cuanto mayor, antes llega

func _process(delta: float) -> void:
    var meta := objetivo.global_position
    var peso := suavidad * delta
    # Cada fotograma recorre una parte de lo que falta
    global_position = global_position.lerp(meta, peso)
