extends Node2D  # Una torreta

@export var objetivo: CharacterBody2D
@export var velocidad_bala := 400.0  # Píxeles por segundo

func punto_de_mira() -> Vector2:
    var donde_esta := objetivo.global_position
    # Tiempo que tardaría la bala en llegar hasta allí
    var distancia := global_position.distance_to(donde_esta)
    var vuelo := distancia / velocidad_bala
    # Extrapolación: donde estará al terminar el vuelo
    return donde_esta + objetivo.velocity * vuelo

func _process(_delta: float) -> void:
    look_at(punto_de_mira())
