class_name MaquinaEstados
extends Node  # Pasa el trabajo al estado actual

@export var inicial: EstadoBase
var actual: EstadoBase
@onready var personaje: CharacterBody2D = get_parent()

func _ready() -> void:
    for estado: EstadoBase in get_children():
        estado.personaje = personaje
    actual = inicial
    actual.entrar()

func _physics_process(delta: float) -> void:
    var siguiente := actual.actualizar(delta)
    if siguiente != "":
        actual.salir()
        actual = get_node(siguiente)  # El nodo con ese nombre
        actual.entrar()
    personaje.move_and_slide()
