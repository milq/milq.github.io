extends Navegante  # Mubbit decide con una máquina de estados

enum Estado { PATRULLAR, PERSEGUIR, BUSCAR }

const RUTA: Array[String] = ["A", "B", "C", "D"]
@export var niblo: CharacterBody3D
@export var vista := 7.0  # Metros a los que puede ver a Niblo
var estado := Estado.PATRULLAR
var siguiente := 0  # Letra de la ruta a la que va
var espera := 0.0   # Segundos que lleva buscando
@onready var etiqueta: Label3D = $Label3D

func _physics_process(delta: float) -> void:
    match estado:
        Estado.PATRULLAR:
            patrullar()
        Estado.PERSEGUIR:
            perseguir()
        Estado.BUSCAR:
            buscar(delta)
    super(delta)  # Navegante lo lleva hasta su meta

func patrullar() -> void:
    if agente.is_navigation_finished():  # A la siguiente letra
        agente.target_position = mundo.buscar(RUTA[siguiente])
        siguiente = (siguiente + 1) % RUTA.size()
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)

func perseguir() -> void:
    var donde := niblo.global_position
    if agente.target_position.distance_to(donde) > 1.0:
        agente.target_position = donde  # Niblo se ha movido
    if not ve_a_niblo():
        agente.target_position += niblo.velocity  # Adonde iba
        cambiar_a(Estado.BUSCAR)

func buscar(delta: float) -> void:
    espera += delta  # Segundos desde que lo perdió
    if ve_a_niblo():
        cambiar_a(Estado.PERSEGUIR)
    elif espera > 6.0:
        cambiar_a(Estado.PATRULLAR)

func cambiar_a(nuevo: Estado) -> void:
    estado = nuevo
    espera = 0.0
    etiqueta.text = Estado.keys()[nuevo]  # Su nombre, encima

# Lo ve si está cerca y no hay nada en medio
func ve_a_niblo() -> bool:
    var ojos := global_position + Vector3.UP  # A 1 m del suelo
    var donde := niblo.global_position + Vector3.UP
    if ojos.distance_to(donde) > vista:
        return false
    var rayo := PhysicsRayQueryParameters3D.create(ojos, donde)
    rayo.exclude = [get_rid()]  # Que no choque consigo mismo
    var espacio := get_world_3d().direct_space_state
    var choque := espacio.intersect_ray(rayo)
    return choque.get("collider") == niblo
