class_name EstadoBase
extends Node  # Un estado: un nodo hijo de la máquina

var personaje: CharacterBody2D  # Lo asigna la máquina

func entrar() -> void:  # Al entrar en el estado
    pass

func salir() -> void:  # Al salir de él
    pass

# Hace su trabajo en cada paso y devuelve el nombre del
# estado siguiente, o una cadena vacía para seguir en este
func actualizar(_delta: float) -> String:
    return ""
