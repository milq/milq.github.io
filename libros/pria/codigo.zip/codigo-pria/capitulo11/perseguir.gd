extends EstadoBase  # Perseguir: va hacia el jugador si lo ve

@export var jugador: Node2D
@export var rapidez := 120.0  # px/s
@export var vista := 250.0    # px

func entrar() -> void:
    personaje.get_node("Alerta").show()  # Un «!»

func salir() -> void:
    personaje.get_node("Alerta").hide()

func actualizar(_delta: float) -> String:
    var donde := jugador.global_position
    var desde := personaje.global_position
    personaje.velocity = desde.direction_to(donde) * rapidez
    if desde.distance_to(donde) > vista:
        return "Buscar"  # Lo ha perdido
    return ""
