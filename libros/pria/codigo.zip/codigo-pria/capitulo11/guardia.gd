extends CharacterBody2D  # Un guardia con una máquina de estados

enum Estado { PATRULLAR, PERSEGUIR, BUSCAR }

@export var jugador: Node2D
@export var ruta: Array[Marker2D] = []  # Puntos de patrulla
@export var rapidez := 120.0  # px/s
@export var vista := 250.0    # px a los que ve al jugador
var estado := Estado.PATRULLAR
var siguiente := 0              # Punto de la ruta al que va
var ultima_vez := Vector2.ZERO  # Donde vio al jugador
var espera := 0.0               # Segundos que lleva buscando

func _physics_process(delta: float) -> void:
    match estado:
        Estado.PATRULLAR:
            patrullar()
        Estado.PERSEGUIR:
            perseguir()
        Estado.BUSCAR:
            buscar(delta)
    move_and_slide()

func patrullar() -> void:
    var meta := ruta[siguiente].global_position
    ir_hacia(meta)
    if global_position.distance_to(meta) < 4.0:
        siguiente = (siguiente + 1) % ruta.size()
    if ve_al_jugador():
        estado = Estado.PERSEGUIR

func perseguir() -> void:
    ultima_vez = jugador.global_position
    ir_hacia(ultima_vez)
    if not ve_al_jugador():
        estado = Estado.BUSCAR
        espera = 0.0

func buscar(delta: float) -> void:
    if global_position.distance_to(ultima_vez) > 4.0:
        ir_hacia(ultima_vez)  # Va adonde lo vio
    else:
        velocity = Vector2.ZERO  # Ya está allí: espera
        espera += delta
    if ve_al_jugador():
        estado = Estado.PERSEGUIR
    elif espera > 3.0:
        estado = Estado.PATRULLAR

func ir_hacia(punto: Vector2) -> void:
    velocity = global_position.direction_to(punto) * rapidez

func ve_al_jugador() -> bool:
    var donde := jugador.global_position
    return global_position.distance_to(donde) < vista

# Cambia de estado y hace las acciones de entrada del nuevo
func cambiar_a(nuevo: Estado) -> void:
    estado = nuevo
    match nuevo:
        Estado.PERSEGUIR:
            $Alerta.show()  # Un «!» sobre la cabeza
        Estado.BUSCAR:
            $Alerta.hide()
            espera = 0.0

# Estado siguiente para cada estado y cada evento
const TRANSICIONES := {
    Estado.PATRULLAR: {"ve": Estado.PERSEGUIR},
    Estado.PERSEGUIR: {"pierde": Estado.BUSCAR},
    Estado.BUSCAR: {"ve": Estado.PERSEGUIR,
        "se_cansa": Estado.PATRULLAR},
}

func recibir(evento: String) -> void:
    var salidas: Dictionary = TRANSICIONES[estado]
    if salidas.has(evento):  # Si no está, no cambia nada
        cambiar_a(salidas[evento])
