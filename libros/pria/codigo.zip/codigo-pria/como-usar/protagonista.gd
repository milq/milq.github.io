extends Sprite2D

@export var velocidad := 200.0  # Píxeles por segundo

func _process(delta: float) -> void:
    var x := Input.get_axis("ui_left", "ui_right")
    var y := Input.get_axis("ui_up", "ui_down")
    position += Vector2(x, y).normalized() * velocidad * delta
