class_name Enemigo
extends Area2D  # Un enemigo con uno de tres patrones

enum Patron { PERSEGUIR, ORBITAR, ZIGZAG }

@export var patron := Patron.PERSEGUIR
@export var rapidez := 140.0  # px/s
@export var giro := 2.0       # Velocidad angular en rad/s
@export var objetivo: Node2D  # La nave

var tiempo := 0.0

func _physics_process(delta: float) -> void:
    tiempo += delta
    match patron:
        Patron.PERSEGUIR: perseguir(delta)
        Patron.ORBITAR: orbitar(delta)
        Patron.ZIGZAG: zigzag(delta)

# Con rotación: gira poco a poco hacia la nave y avanza
func perseguir(delta: float) -> void:
    var hacia := objetivo.position - position
    var meta := Vector2.UP.angle_to(hacia)  # Mira arriba
    rotation = rotate_toward(rotation, meta, giro * delta)
    position += Vector2.UP.rotated(rotation) * rapidez * delta

# Sin rotación: da vueltas a la nave y mira hacia donde va
func orbitar(delta: float) -> void:
    var angulo := tiempo * 1.2  # Radianes recorridos
    var radio := Vector2.from_angle(angulo) * 200.0  # 200 px
    mover_hacia(objetivo.position + radio, delta)

# Sin rotación: va hacia la nave haciendo eses
func zigzag(delta: float) -> void:
    var hacia := (objetivo.position - position).normalized()
    var lado := hacia.orthogonal() * sin(tiempo * 5.0)
    mover_hacia(position + hacia + lado, delta)

# Avanza hacia un punto y se orienta de golpe hacia allí
func mover_hacia(punto: Vector2, delta: float) -> void:
    var paso := position.direction_to(punto) * rapidez * delta
    position += paso
    if paso != Vector2.ZERO:
        rotation = Vector2.UP.angle_to(paso)
