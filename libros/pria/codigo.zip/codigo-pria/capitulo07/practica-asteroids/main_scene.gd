extends Node2D  # MainScene: enemigos, puntos y vidas

@export var escena_enemigo: PackedScene

var puntos := 0
var vidas := 3

func _ready() -> void:
    $Timer.timeout.connect(aparecer)
    actualizar()

func aparecer() -> void:
    var enemigo := escena_enemigo.instantiate() as Enemigo
    var ancho := get_viewport_rect().size.x
    enemigo.position = Vector2(randf() * ancho, 0.0)  # Arriba
    enemigo.rotation = randf() * TAU
    enemigo.patron = Enemigo.Patron.values().pick_random()
    enemigo.objetivo = $Nave
    enemigo.body_entered.connect(_on_choque.bind(enemigo))
    add_child(enemigo)

func _on_choque(cuerpo: Node2D, enemigo: Enemigo) -> void:
    if cuerpo != $Nave:
        return
    enemigo.queue_free()  # El que te toca desaparece
    vidas -= 1
    actualizar()
    if vidas == 0:  # Fin: la partida vuelve a empezar
        get_tree().reload_current_scene.call_deferred()

func sumar_punto() -> void:  # La llama cada bala que acierta
    puntos += 1
    actualizar()
    $Explosion.pitch_scale = randf_range(0.8, 1.2)  # Nunca igual
    $Explosion.play()

func actualizar() -> void:
    $Marcador.text = "PUNTOS %d   VIDAS %d" % [puntos, vidas]
