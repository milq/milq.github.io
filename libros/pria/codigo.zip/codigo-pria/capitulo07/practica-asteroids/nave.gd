extends CharacterBody2D  # La nave: gira, acelera y dispara

@export var giro := 4.0        # Velocidad angular en rad/s
@export var empuje := 500.0    # Aceleración en px/s²
@export var rozamiento := 0.8  # Cuánto frena sola
@export var escena_bala: PackedScene

func _physics_process(delta: float) -> void:
    # Con rotación: la orientación cambia girando
    var mando := Input.get_axis("ui_left", "ui_right")
    rotation += mando * giro * delta
    var delante := Vector2.UP.rotated(rotation)  # Mira arriba
    if Input.is_action_pressed("ui_up"):
        velocity += delante * empuje * delta  # Acelera
    velocity *= exp(-rozamiento * delta)  # Frena
    move_and_slide()
    var ventana := get_viewport_rect().size
    position.x = wrapf(position.x, 0.0, ventana.x)
    position.y = wrapf(position.y, 0.0, ventana.y)
    if Input.is_action_just_pressed("ui_accept"):  # Dispara
        var bala := escena_bala.instantiate() as Area2D
        bala.position = position + delante * 36.0  # El morro
        bala.rotation = rotation
        get_parent().add_child(bala)
        $Disparo.play()
