extends Area2D  # Una bala que avanza y destruye enemigos

@export var rapidez := 700.0  # px/s

func _ready() -> void:
    area_entered.connect(_on_area_entered)
    get_tree().create_timer(1.2).timeout.connect(queue_free)

func _physics_process(delta: float) -> void:
    position += Vector2.UP.rotated(rotation) * rapidez * delta

func _on_area_entered(otra: Area2D) -> void:
    if otra is Enemigo:  # La clase del paso 9
        otra.queue_free()
        queue_free()
        get_parent().sumar_punto()  # MainScene, en el paso 10
