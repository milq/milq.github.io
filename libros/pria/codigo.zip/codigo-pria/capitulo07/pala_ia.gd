extends CharacterBody2D  # La pala de la IA en un Pong vertical

@export var pelota: Node2D
@export var rapidez := 300.0  # px/s: si es poca, puede fallar
@export var margen := 10.0    # Por menos de esto, no se mueve

func _physics_process(_delta: float) -> void:
    var diferencia := pelota.position.y - position.y
    velocity = Vector2.ZERO
    if absf(diferencia) > margen:
        velocity.y = signf(diferencia) * rapidez
    move_and_slide()
