extends Node2D  # Un enemigo con un patrón de pasos

const PASOS := [  # Dirección y segundos de cada paso
    [Vector2.RIGHT, 2.0], [Vector2.DOWN, 0.5],
    [Vector2.LEFT, 2.0], [Vector2.DOWN, 0.5]]

@export var rapidez := 100.0  # px/s

var paso := 0      # Paso actual
var tiempo := 0.0  # Segundos en el paso actual

func _process(delta: float) -> void:
    var direccion: Vector2 = PASOS[paso][0]
    position += direccion * rapidez * delta
    tiempo += delta
    if tiempo >= PASOS[paso][1]:  # Se acabó este paso
        tiempo = 0.0
        paso = (paso + 1) % PASOS.size()  # Al siguiente
