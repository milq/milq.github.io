extends Area2D  # Un enemigo que persigue girando

@export var objetivo: Node2D
@export var rapidez := 180.0  # px/s
@export var giro := 2.0       # rad/s: menos, curva más abierta

func _physics_process(delta: float) -> void:
    var delante := Vector2.UP.rotated(rotation)
    var hacia := objetivo.position - position
    # Producto vectorial: positivo a la derecha (capítulo 3)
    var lado := signf(delante.cross(hacia))
    rotation += lado * giro * delta  # Gira hacia el objetivo
    position += delante * rapidez * delta  # Y siempre avanza
