extends Camera2D  # Una cámara que cambia de pantalla

@export var jugador: Node2D

func _process(_delta: float) -> void:
    var ventana := get_viewport_rect().size
    # La pantalla del jugador, como una casilla: (1, 0)…
    var pantalla := (jugador.global_position / ventana).floor()
    # Su centro: esquina más media ventana
    global_position = pantalla * ventana + ventana / 2.0
