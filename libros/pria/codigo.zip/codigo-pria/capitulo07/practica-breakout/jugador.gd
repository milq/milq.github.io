extends CharacterBody2D  # La pala del jugador: solo en x

@export var rapidez := 600.0  # px/s

func _physics_process(_delta: float) -> void:
    velocity.x = Input.get_axis("ui_left", "ui_right") * rapidez
    move_and_slide()
