extends CharacterBody2D  # La pelota: rebota y rompe ladrillos

signal punto(para: String)  # Quién gana el punto

@export var rapidez := 420.0  # px/s

func _ready() -> void:
    sacar()

func sacar() -> void:
    position = get_viewport_rect().size / 2.0
    var x := randf_range(-0.6, 0.6)
    var y := 1.0 if randf() < 0.5 else -1.0  # Hacia una pala
    velocity = Vector2(x, y).normalized() * rapidez

func _physics_process(delta: float) -> void:
    var choque := move_and_collide(velocity * delta)
    if choque:
        rebotar(choque)
    if position.y > get_viewport_rect().size.y:
        punto.emit("ia")  # Se ha colado por abajo
        sacar()
    elif position.y < 0.0:
        punto.emit("jugador")  # Se ha colado por arriba
        sacar()

func rebotar(choque: KinematicCollision2D) -> void:
    var otro := choque.get_collider() as Node2D
    if otro.is_in_group("palas"):
        # Cuanto más lejos del centro de la pala, más se inclina
        var desvio := (position.x - otro.position.x) / 60.0
        var hacia := signf(position.y - otro.position.y)
        var direccion := Vector2(clampf(desvio, -1, 1), hacia)
        velocity = direccion.normalized() * rapidez
    else:
        velocity = velocity.bounce(choque.get_normal())
        if otro.is_in_group("ladrillos"):
            otro.queue_free()
