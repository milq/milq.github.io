extends CharacterBody2D  # La pala de la IA: sigue a la pelota

@export var pelota: CharacterBody2D
@export var rapidez := 300.0  # px/s: menos que el jugador
@export var margen := 12.0    # Por menos de esto, no se mueve

@onready var centro_x := position.x  # Adonde vuelve si espera

func _physics_process(_delta: float) -> void:
    # Percibe: ¿la pelota viene hacia arriba, hacia ella?
    var viene := pelota.velocity.y < 0.0
    # Decide: si viene, va a por ella; si no, vuelve al centro
    var destino := pelota.position.x if viene else centro_x
    var diferencia := destino - position.x
    # Se mueve: solo en x y como mucho a su rapidez
    velocity.x = 0.0
    if absf(diferencia) > margen:
        velocity.x = signf(diferencia) * rapidez
    move_and_slide()
