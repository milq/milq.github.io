extends Node2D  # MainScene: los ladrillos y los puntos

@export var escena_ladrillo: PackedScene

var puntos := {"jugador": 0, "ia": 0}

func _ready() -> void:
    $Pelota.punto.connect(_on_punto)
    for fila in 6:
        var color := Color.from_hsv(fila / 6.0, 0.6, 0.9)
        for columna in 12:
            var ladrillo: Node2D = escena_ladrillo.instantiate()
            # Paso de 92 × 28: el ladrillo más 4 px de hueco
            var x := 134.0 + 92.0 * columna
            ladrillo.position = Vector2(x, 122.0 + 28.0 * fila)
            ladrillo.modulate = color
            add_child(ladrillo)

func _on_punto(para: String) -> void:
    puntos[para] += 1
    $PuntosJugador.text = "Jugador: %d" % puntos["jugador"]
    $PuntosIA.text = "IA: %d" % puntos["ia"]
