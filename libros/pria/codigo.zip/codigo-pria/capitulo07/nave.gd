extends CharacterBody2D  # Una nave como la de Asteroids

@export var giro := 4.0      # Velocidad angular en rad/s
@export var empuje := 500.0  # Aceleración en px/s²

func _physics_process(delta: float) -> void:
    # La rotación cambia la orientación: giro por tiempo
    var mando := Input.get_axis("ui_left", "ui_right")
    rotation += mando * giro * delta
    var delante := Vector2.UP.rotated(rotation)  # Mira arriba
    if Input.is_action_pressed("ui_up"):
        velocity += delante * empuje * delta
    move_and_slide()
