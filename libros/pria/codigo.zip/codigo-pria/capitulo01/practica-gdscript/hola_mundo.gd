@tool
extends EditorScript  # Un script que se ejecuta en el editor

# Godot llama a _run() con File → Run (Ctrl + Shift + X)
func _run() -> void:
    print("¡Hola, mundo!")  # Escribe en el panel Output
    print("Vidas: ", 3)     # Une el texto y el número
    print(2 + 3 * 4)        # 14: primero se multiplica
