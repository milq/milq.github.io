class_name Navegante
extends CharacterBody3D  # Un cuerpo que se mueve con su agente

@export var mundo: Mundo     # MainScene, con mundo.gd
@export var rapidez := 4.0   # Metros por segundo
@onready var agente: NavigationAgent3D = $NavigationAgent3D

func _ready() -> void:
    agente.velocity_computed.connect(_al_calcular_velocidad)

func _physics_process(_delta: float) -> void:
    if agente.is_navigation_finished():
        agente.velocity = Vector3.ZERO  # Quieto, pero esquiva
        return
    var siguiente := agente.get_next_path_position()
    var hacia := global_position.direction_to(siguiente)
    agente.velocity = Vector3(hacia.x, 0.0, hacia.z) * rapidez

# La velocidad segura, que no choca con los demás agentes
func _al_calcular_velocidad(segura: Vector3) -> void:
    velocity = segura
    move_and_slide()
