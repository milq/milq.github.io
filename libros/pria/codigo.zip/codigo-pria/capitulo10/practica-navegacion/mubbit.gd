extends Navegante  # Mubbit patrulla y persigue a Niblo

const RUTA: Array[String] = ["A", "B", "C", "D"]
@export var niblo: Node3D
@export var vista := 6.0  # Metros a los que ve a Niblo
var siguiente := 0

func _physics_process(delta: float) -> void:
    var donde := niblo.global_position
    if global_position.distance_to(donde) < vista:
        # Lo persigue: meta nueva si Niblo se ha movido
        if agente.target_position.distance_to(donde) > 1.0:
            agente.target_position = donde
    elif agente.is_navigation_finished():
        # Patrulla: a la siguiente letra de la ruta
        agente.target_position = mundo.buscar(RUTA[siguiente])
        siguiente = (siguiente + 1) % RUTA.size()
    super(delta)  # Navegante lo mueve
