extends Navegante  # Niblo va adonde hagas clic

func _unhandled_input(event: InputEvent) -> void:
    var clic := event as InputEventMouseButton
    if clic and clic.pressed:
        var camara := get_viewport().get_camera_3d()
        var desde := camara.project_ray_origin(clic.position)
        var hacia := camara.project_ray_normal(clic.position)
        var suelo := Plane(Vector3.UP, 0.0)  # El plano y = 0
        var punto = suelo.intersects_ray(desde, hacia)
        if punto != null:
            agente.target_position = punto
