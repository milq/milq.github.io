extends CharacterBody2D  # Va adonde hagas clic, por la malla

@export var rapidez := 200.0  # px/s
@onready var agente: NavigationAgent2D = $NavigationAgent2D

func _unhandled_input(event: InputEvent) -> void:
    var clic := event as InputEventMouseButton
    if clic and clic.pressed:
        agente.target_position = get_global_mouse_position()

func _physics_process(_delta: float) -> void:
    if agente.is_navigation_finished():
        return  # Ha llegado, o no tiene adónde ir
    var siguiente := agente.get_next_path_position()
    velocity = global_position.direction_to(siguiente) * rapidez
    move_and_slide()
