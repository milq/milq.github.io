extends CharacterBody3D  # Va adonde hagas clic, en 3D

@export var rapidez := 5.0  # m/s
@onready var agente: NavigationAgent3D = $NavigationAgent3D

func _unhandled_input(event: InputEvent) -> void:
    var clic := event as InputEventMouseButton
    if clic and clic.pressed:
        var camara := get_viewport().get_camera_3d()
        var desde := camara.project_ray_origin(clic.position)
        var hacia := camara.project_ray_normal(clic.position)
        var hasta := desde + hacia * 1000.0  # Un rayo largo
        var mapa := get_world_3d().navigation_map
        var servidor := NavigationServer3D
        var punto := servidor.map_get_closest_point_to_segment(
            mapa, desde, hasta)
        agente.target_position = punto

func _physics_process(_delta: float) -> void:
    if agente.is_navigation_finished():
        return
    var siguiente := agente.get_next_path_position()
    velocity = global_position.direction_to(siguiente) * rapidez
    move_and_slide()
