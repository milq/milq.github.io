extends Node2D  # main.gd: una clase que hereda de Node2D

func _ready() -> void:
    print("MainScene está lista")  # Una vez, al empezar

func _process(delta: float) -> void:
    $Icono.rotation += TAU * delta  # Una vuelta por segundo
