class_name Azar  # azar.gd: una librería propia
# Azar.probabilidad(25) es true una de cada cuatro veces
static func probabilidad(porcentaje: float) -> bool:
    return randf() * 100.0 < porcentaje
