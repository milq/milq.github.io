extends Node  # Global: registrado como autoload en Globals

var nivel: int = 1
var vidas: int = 3

func perder_vida() -> void:
    vidas -= 1
    if vidas == 0:  # Fin de la partida: vuelve a empezar
        nivel = 1
        vidas = 3
