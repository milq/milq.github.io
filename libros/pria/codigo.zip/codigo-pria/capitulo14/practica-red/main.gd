extends Node2D  # La partida: un jugador por cada conexión

const JUGADOR := preload("res://jugador.tscn")
var puntos := {}  # Identificador de red → manzanas

func _ready() -> void:
    $Menu/Crear.pressed.connect(crear)
    $Menu/Unirse.pressed.connect(unirse)
    var argumentos := OS.get_cmdline_args()  # Para probar
    if "--servidor" in argumentos:
        crear()
    elif "--cliente" in argumentos:
        unirse()

func crear() -> void:
    if Red.crear() != OK:
        return
    $Menu.hide()
    Red.jugador_llega.connect(anadir)
    Red.jugador_se_va.connect(quitar)
    anadir(1)  # El anfitrión es siempre el 1

func unirse() -> void:
    if Red.unirse($Menu/IP.text) == OK:
        $Menu.hide()

# Solo en el servidor: el spawner lo copia en los clientes
func anadir(id: int) -> void:
    var jugador := JUGADOR.instantiate()
    jugador.name = str(id)  # Su nombre es su identificador
    $Jugadores.add_child(jugador)

func quitar(id: int) -> void:
    $Jugadores.get_node(str(id)).queue_free()

# El servidor avisa a todos de que alguien ha cogido una manzana
@rpc("authority", "call_local", "reliable")
func sumar_punto(id: int) -> void:
    puntos[id] = puntos.get(id, 0) + 1
    var texto := ""
    for jugador in puntos:
        texto += "Jugador %d: %d\n" % [jugador, puntos[jugador]]
    $Marcador.text = texto
