extends Area2D  # Solo el servidor decide quién coge la manzana

func _ready() -> void:
    body_entered.connect(_al_tocar)

func _al_tocar(jugador: Node2D) -> void:
    if not multiplayer.is_server():
        return  # En los clientes, la manzana solo se ve
    get_parent().sumar_punto.rpc(jugador.name.to_int())
    position.x = randf_range(60, 580)  # Otro sitio al azar
    position.y = randf_range(60, 300)
