extends CharacterBody2D  # Cada jugador lo mueve su dueño

@export var rapidez := 300.0  # px/s

func _enter_tree() -> void:
    set_multiplayer_authority(name.to_int())  # Su dueño

func _ready() -> void:
    if name != "1":  # El anfitrión es Niblo; los demás, Mubbit
        $Sprite2D.texture = load("res://mubbit.png")
    if is_multiplayer_authority():  # Elige dónde empieza
        position = Vector2(randf_range(100, 540), 240)

func _physics_process(_delta: float) -> void:
    if not is_multiplayer_authority():
        return  # Lo mueve otro ordenador; aquí solo se copia
    var direccion := Input.get_vector("ui_left", "ui_right",
        "ui_up", "ui_down")
    velocity = direccion * rapidez
    move_and_slide()
