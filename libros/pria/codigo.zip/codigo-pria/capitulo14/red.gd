extends Node  # Red: crea partidas, se une a ellas y avisa

signal jugador_llega(id: int)
signal jugador_se_va(id: int)

const PUERTO := 4242
const MAXIMO := 4  # Jugadores, contando el anfitrión

func _ready() -> void:
    multiplayer.peer_connected.connect(jugador_llega.emit)
    multiplayer.peer_disconnected.connect(jugador_se_va.emit)
    multiplayer.server_disconnected.connect(salir)

# Crea una partida en este ordenador: el anfitrión también juega
func crear() -> Error:
    var par := ENetMultiplayerPeer.new()
    var error := par.create_server(PUERTO, MAXIMO - 1)
    if error == OK:
        multiplayer.multiplayer_peer = par
    return error

# Se une a la partida del ordenador con esa dirección IP
func unirse(ip: String) -> Error:
    var par := ENetMultiplayerPeer.new()
    var error := par.create_client(ip, PUERTO)
    if error == OK:
        multiplayer.multiplayer_peer = par
    return error

# Cierra la conexión y vuelve a empezar
func salir() -> void:
    multiplayer.multiplayer_peer.close()
    multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
    get_tree().reload_current_scene()
