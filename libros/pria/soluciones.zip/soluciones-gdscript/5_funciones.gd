@tool
extends EditorScript
# Soluciones de «Funciones» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.


func _run() -> void:
	print("— Ejercicio 1 —")
	print(es_turno_de_niblo(4), " ", es_turno_de_niblo(7))  # true false
	print("— Ejercicio 2 —")
	print(resumen(30.0, 12.0))  # [30.0, 12.0, 21.0]
	print("— Ejercicio 3 —")
	print(cifras(344), " ", cifras(-344))  # [3, 4, 4] [3, 4, 4]
	print("— Ejercicio 4 —")
	print(calcular(6.0, 3.0, "+"), " ", calcular(6.0, 3.0, "/"))  # 9.0 2.0


# Un número es par si el resto de dividirlo entre 2 es 0. La comparación ya
# es un booleano, así que se devuelve directamente.
func es_turno_de_niblo(turno: int) -> bool:
	return turno % 2 == 0


# Un array se escribe entre corchetes y puede contener el resultado de
# varias expresiones.
func resumen(a: float, b: float) -> Array:
	return [maxf(a, b), minf(a, b), (a + b) / 2.0]


# str() convierte la puntuación en texto, el bucle recorre sus caracteres e
# int() convierte cada uno de nuevo en número. absi() quita el signo, para
# que con -344 no aparezca el guion entre las cifras. También se puede hacer
# sin textos, como en el ejercicio 2 de «Bucles»: n % 10 da la última cifra.
func cifras(n: int) -> Array[int]:
	var resultado: Array[int] = []
	for caracter in str(absi(n)):
		resultado.append(int(caracter))
	return resultado


# match compara la operación con cada caso y ejecuta el que coincide. El
# return final cubre una operación desconocida. Dividir entre 0 da infinito
# (INF), que puedes comprobar aparte.
func calcular(a: float, b: float, op: String) -> float:
	match op:
		"+":
			return a + b
		"-":
			return a - b
		"*":
			return a * b
		"/":
			return a / b
	return 0.0
