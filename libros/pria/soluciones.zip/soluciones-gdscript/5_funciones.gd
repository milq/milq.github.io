@tool
extends EditorScript
# Soluciones de «Funciones» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 5_funciones.gd, en
# https://milq.github.io/libros/pria/gdscript/


func _run() -> void:
	print("— Ejercicio 1 —")
	print(es_turno_de_niblo(4), " ", es_turno_de_niblo(7))  # true false
	print("— Ejercicio 2 —")
	print(resumen(30.0, 12.0))  # [30.0, 12.0, 21.0]
	print("— Ejercicio 3 —")
	print(cifras(344), " ", cifras(7))  # [3, 4, 4] [7]
	print("— Ejercicio 4 —")
	print(calcular(6.0, 3.0, "+"), " ", calcular(6.0, 3.0, "/"))  # 9.0 2.0


# Un número es par si el resto de dividirlo entre 2 es 0. La comparación ya
# es un booleano, así que se devuelve directamente.
func es_turno_de_niblo(turno: int) -> bool:
	return turno % 2 == 0


# Con los dos daños en un array, max() y min() dan el mayor y el menor. El
# resultado es otro array, escrito entre corchetes, con tres expresiones.
func resumen(a: float, b: float) -> Array[float]:
	var daños: Array[float] = [a, b]
	return [daños.max(), daños.min(), (a + b) / 2.0]


# Como en el ejercicio 2 de «Bucles»: n % 10 da la última cifra, y la
# división entera entre 10 la quita. Las cifras salen de la última a la
# primera, así que cada una se mete al principio del array con push_front().
# Con 0, el bucle no da ninguna vuelta y devuelve un array vacío.
func cifras(puntuacion: int) -> Array[int]:
	var resultado: Array[int] = []
	var n := puntuacion
	while n > 0:
		resultado.push_front(n % 10)
		@warning_ignore("integer_division")
		n = n / 10
	return resultado


# match compara la operación con cada caso y ejecuta el que coincide. El
# return final cubre una operación desconocida. Dividir entre 0 da infinito
# (inf), que puedes comprobar aparte.
func calcular(a: float, b: float, op: String) -> float:
	match op:
		"+":
			return a + b
		"-":
			return a - b
		"*":
			return a * b
		"/":
			return a / b
	return 0.0
