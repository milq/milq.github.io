@tool
extends EditorScript
# Soluciones de los ejercicios 51 a 60 del apéndice A, «Funciones». Ejecútalo
# con File → Run (Ctrl + Shift + X): el resultado sale en el panel Output. Solo
# usa lo que explica el apéndice hasta su apartado «Funciones». Las funciones
# van fuera de _run(), a su lado, y desde _run() se llaman.

var nivel: int = 1  # Del script, fuera de las funciones: la usa subir_nivel()


func _run() -> void:
	# 51. Llama dos veces a saludar() desde _run(), donde empieza todo.
	print("— Ejercicio 51 —")
	saludar()
	saludar()
	ejercicio_52()
	ejercicio_53()
	ejercicio_54()
	ejercicio_55()
	ejercicio_56()
	ejercicio_57()
	ejercicio_58()
	ejercicio_59()
	ejercicio_60()


# 51. Define saludar() -> void, que muestre «¡Hola!». void dice que no
# devuelve nada.
func saludar() -> void:
	print("¡Hola!")


# 52. Define cuadrado(n: int) -> int, que devuelva el cuadrado de n, y muestra
# el valor que devuelve con 7.
func cuadrado(n: int) -> int:
	return n * n


func ejercicio_52() -> void:
	print("— Ejercicio 52 —")
	print(cuadrado(7))  # 49


# 53. Define subir_nivel() -> void, que incremente la variable nivel del
# script, y llámala tres veces seguidas.
func subir_nivel() -> void:
	nivel += 1  # nivel es la del script, la de arriba del todo


func ejercicio_53() -> void:
	print("— Ejercicio 53 —")
	subir_nivel()
	subir_nivel()
	subir_nivel()
	print(nivel)  # 4: empezaba en 1


# 54. Define sumar(vida: int, extra: int = 10) -> int y muestra lo que
# devuelven sumar(50) y sumar(50, 5).
func sumar(vida: int, extra: int = 10) -> int:
	return vida + extra


func ejercicio_54() -> void:
	print("— Ejercicio 54 —")
	# Si no le pasas extra, vale 10.
	print(sumar(50))     # 60
	print(sumar(50, 5))  # 55


# 55. Define daño(magia: int, escudo: int) -> int, que devuelva la diferencia,
# o 0 si es negativa, y pruébala.
func daño(magia: int, escudo: int) -> int:
	var diferencia: int = magia - escudo
	if diferencia < 0:
		return 0  # return sale de la función: lo de debajo ya no se ejecuta
	return diferencia


func ejercicio_55() -> void:
	print("— Ejercicio 55 —")
	print(daño(30, 12))  # 18
	print(daño(10, 25))  # 0, y no -15


# 56. Define es_par(n: int) -> bool y úsala dentro de un bucle que muestre
# solo los números pares del 1 al 20.
func es_par(n: int) -> bool:
	return n % 2 == 0  # La comparación ya es un booleano


func ejercicio_56() -> void:
	print("— Ejercicio 56 —")
	var pares: String = ""
	for i: int in range(1, 21):
		if es_par(i):
			pares += str(i) + " "
	print(pares)  # 2 4 6 8 10 12 14 16 18 20


# 57. Define _avisar(texto: String) -> void, privada por convención, que
# muestre «[Juego]» delante del texto.
func _avisar(texto: String) -> void:
	# El _ del principio no impide llamarla desde fuera: avisa a quien lee de
	# que es de uso interno del script.
	print("[Juego] ", texto)


func ejercicio_57() -> void:
	print("— Ejercicio 57 —")
	_avisar("Partida guardada")  # [Juego] Partida guardada


# 58. Define una función que reciba un Array[int] de puntos y devuelva un
# diccionario con su total y su media.
func resumen(puntos: Array[int]) -> Dictionary:
	# Para devolver dos valores, se devuelve un diccionario. float() hace que
	# la media sea una división real y no pierda los decimales.
	var total: int = 0
	for p: int in puntos:
		total += p
	return {"total": total, "media": float(total) / puntos.size()}


func ejercicio_58() -> void:
	print("— Ejercicio 58 —")
	var datos := resumen([7, 9, 5, 10])
	print(datos["total"], " ", datos["media"])  # 31 7.75


# 59. Guarda una lambda que triplique un entero, llámala con call(), y suma un
# array con reduce() y otra lambda.
func ejercicio_59() -> void:
	print("— Ejercicio 59 —")
	# Una lambda es una función sin nombre guardada en una variable. reduce()
	# va acumulando: suma el primero y el segundo, el resultado y el
	# tercero, y así hasta el final.
	var triple := func(n: int) -> int: return n * 3
	var nueve: int = triple.call(3)
	var sumar_dos := func(a: int, b: int) -> int: return a + b
	var numeros: Array[int] = [4, 8, 15, 16]
	var total: int = numeros.reduce(sumar_dos)
	print(nueve, " ", total)  # 9 43


# 60. Define una función recursiva que calcule una potencia sin **
# (potencia(2, 3) devuelve 8), con su caso base.
func potencia(base: int, exponente: int) -> int:
	# Caso base: cualquier número elevado a 0 es 1. Si no, base elevado a n
	# es base por base elevado a n - 1, y la función se llama a sí misma con
	# un exponente cada vez menor, hasta llegar al 0.
	if exponente == 0:
		return 1
	return base * potencia(base, exponente - 1)


func ejercicio_60() -> void:
	print("— Ejercicio 60 —")
	print(potencia(2, 3))  # 8
	print(potencia(5, 0))  # 1
