class_name Geometria  # Librería de funciones estáticas
# Solución del ejercicio 4 de «Librerías» (capítulo 2, apartado 2.10).
# Un script sin extends hereda de RefCounted, que basta para una librería. Las
# funciones static pertenecen a la clase y no a cada objeto, así que se usan
# sin crear objetos, como Geometria.distancia(a, b). Godot registra la clase
# en cuanto guardas el archivo, y el editor la autocompleta.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 7_bibliotecas.gd,
# en https://milq.github.io/libros/pria/gdscript/


# Reutiliza el cálculo del ejercicio 1: el teorema de Pitágoras.
static func distancia(a: Vector2, b: Vector2) -> float:
	var dx := b.x - a.x
	var dy := b.y - a.y
	return sqrt(dx * dx + dy * dy)


# El punto medio está a medio camino en x y a medio camino en y.
static func punto_medio(a: Vector2, b: Vector2) -> Vector2:
	return Vector2((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)


static func area_triangulo(base: float, altura: float) -> float:
	return base * altura / 2.0
