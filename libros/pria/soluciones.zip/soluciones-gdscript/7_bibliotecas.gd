@tool
extends EditorScript
# Soluciones de los ejercicios 71 a 80 del apéndice A, «Bibliotecas».
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en el panel
# Output. Usa todo lo que explica el apéndice. El ejercicio 78 guarda
# user://notas.txt: para verlo o borrarlo, usa Project → Open User Data Folder.


# 80. La clase Dados, con un método estático: se llama con el nombre de la
# clase, Dados.tirar(3), sin crear ningún objeto con new().
class Dados:
	static func tirar(n: int) -> int:
		var total: int = 0
		for i: int in range(n):
			total += randi_range(1, 6)
		return total


func _run() -> void:
	ejercicio_71()
	ejercicio_72()
	ejercicio_73()
	ejercicio_74()
	ejercicio_75()
	ejercicio_76()
	ejercicio_77()
	ejercicio_78()
	ejercicio_79()
	ejercicio_80()


# 71. Muestra PI y TAU, y calcula con pow(), sqrt(), exp() y log() la potencia,
# la raíz, la exponencial y el logaritmo.
func ejercicio_71() -> void:
	print("— Ejercicio 71 —")
	# TAU es 2π, una vuelta entera en radianes. log() es el logaritmo de base
	# e, el número de exp(): log(exp(1.0)) da 1.
	print(PI, " ", TAU)          # 3.14159265358979 6.28318530717959
	print(pow(2.0, 10.0))        # 1024.0
	print(sqrt(81.0))            # 9.0
	print(exp(1.0))              # 2.71828182845905, el número e
	print(log(exp(1.0)))         # 1.0


# 72. Calcula con absf() y absi() el valor absoluto de -7.5 y de -7, y
# redondea 2.6 con roundf() y con roundi().
func ejercicio_72() -> void:
	print("— Ejercicio 72 —")
	# Las versiones con f devuelven un real, y las que acaban en i, un entero.
	print(absf(-7.5), " ", absi(-7))      # 7.5 7
	print(roundf(2.6), " ", roundi(2.6))  # 3.0 3


# 73. Redondea 7.49 con roundf(), floorf() y ceilf().
func ejercicio_73() -> void:
	print("— Ejercicio 73 —")
	print(roundf(7.49))  # 7.0: el entero más cercano
	print(floorf(7.49))  # 7.0: hacia abajo
	print(ceilf(7.49))   # 8.0: hacia arriba


# 74. Halla con max() y min() el mayor y el menor de 3, 9 y 4, y limita 15 a un
# máximo de 10 con clamp() y clampi().
func ejercicio_74() -> void:
	print("— Ejercicio 74 —")
	# max(), min() y clamp() valen para enteros y reales, y devuelven un
	# Variant: por eso sus variables llevan el tipo escrito. clamp() pide
	# también un mínimo, aquí 0.
	var mayor: int = max(3, 9, 4)
	var menor: int = min(3, 9, 4)
	var tope: int = clamp(15, 0, 10)
	print(mayor, " ", menor, " ", tope, " ", clampi(15, 0, 10))  # 9 3 10 10


# 75. Convierte 45° a radianes y muestra su seno, su coseno y su tangente, y
# con atan2() el ángulo del punto (5, 2).
func ejercicio_75() -> void:
	print("— Ejercicio 75 —")
	# Las funciones trigonométricas trabajan en radianes. atan2() recibe
	# primero la y y después la x.
	var angulo := deg_to_rad(45.0)
	print(angulo)                          # 0.78539816339745: π / 4
	print(sin(angulo), " ", cos(angulo))   # 0.70710678118655 0.70710678118655
	print(tan(angulo))                     # 1.0
	var del_punto := atan2(2.0, 5.0)
	print(del_punto)                       # 0.38050637711236, en radianes


# 76. Genera un real con randf(), un entero del 1 al 6 con randi_range() y un
# real de 0 a 100 con randf_range().
func ejercicio_76() -> void:
	print("— Ejercicio 76 —")
	# Cada vez que lo ejecutes saldrán otros números.
	print(randf())                     # Entre 0 y 1
	print(randi_range(1, 6))           # Del 1 al 6, ambos incluidos
	print(randf_range(0.0, 100.0))     # Entre 0 y 100


# 77. Crea un RandomNumberGenerator, fija su semilla en 7 y genera tres
# enteros, y luego cámbiala con randomize().
func ejercicio_77() -> void:
	print("— Ejercicio 77 —")
	# Con la misma semilla, el generador repite siempre la misma secuencia: esos
	# tres números salen iguales cada vez que lo ejecutes. randomize() le pone
	# una semilla al azar, y lo que salga después cambia en cada ejecución.
	var azar := RandomNumberGenerator.new()
	azar.seed = 7
	print(azar.randi_range(1, 6), " ", azar.randi_range(1, 6), " ", azar.randi_range(1, 6))  # 6 2 5
	azar.randomize()
	print(azar.randi_range(1, 6))  # Cualquiera del 1 al 6


# 78. Escribe con FileAccess y WRITE dos líneas en user://notas.txt, y léelas
# con READ si file_exists().
func ejercicio_78() -> void:
	print("— Ejercicio 78 —")
	# \n es un salto de línea dentro de un texto. get_as_text() lee el archivo
	# entero, y un archivo abierto se cierra con close() al acabar con él.
	var ruta: String = "user://notas.txt"
	var f := FileAccess.open(ruta, FileAccess.WRITE)
	f.store_string("Nivel 1: superado\nNivel 2: en curso")
	f.close()
	if FileAccess.file_exists(ruta):
		f = FileAccess.open(ruta, FileAccess.READ)
		print(f.get_as_text())  # Las dos líneas
		f.close()


# 79. Convierte {"nivel": 2, "monedas": 30} en texto con JSON.stringify() y al
# revés con JSON.parse_string().
func ejercicio_79() -> void:
	print("— Ejercicio 79 —")
	# JSON.stringify() ordena las claves por orden alfabético. JSON solo tiene un
	# tipo de número, así que al leerlo los enteros vuelven como reales: 2.0 y
	# 30.0.
	var partida := {"nivel": 2, "monedas": 30}
	var texto: String = JSON.stringify(partida)
	print(texto)  # {"monedas":30,"nivel":2}
	var leida: Dictionary = JSON.parse_string(texto)
	print(leida, " ", type_string(typeof(leida["nivel"])))  # { "monedas": 30.0, "nivel": 2.0 } float


# 80. Llama a Dados.tirar() sin crear ninguna instancia.
func ejercicio_80() -> void:
	print("— Ejercicio 80 —")
	print(Dados.tirar(3))  # Entre 3 y 18
