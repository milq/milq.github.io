extends Node2D
# Soluciones de «Librerías», ejercicios 1 a 4 (capítulo 2, apartado 2.10).
# Es el script de la escena 7_librerias.tscn: ábrela y ejecútala con F6 (Run
# Current Scene). El resultado sale en Output. El ejercicio 5 está en la
# escena 7_atrapa_a_mubbit.tscn.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.

const RUTA := "user://partida.json"


func _ready() -> void:
	print("— Ejercicio 1 —")
	matematicas()
	print("— Ejercicio 2 —")
	var rng := RandomNumberGenerator.new()
	rng.seed = 1234  # Quita esta línea y compara dos ejecuciones
	tiradas_2d6(rng)
	print("— Ejercicio 3 —")
	var partida := cargar_partida()
	partida["nivel"] += 1
	guardar_partida(partida)
	print(partida)  # El nivel sube en cada ejecución
	print("— Ejercicio 4 —")
	usar_geometria()


# 1. Todas son funciones globales: se escriben directamente, sin crear nada
# antes. pow() siempre devuelve un real, aunque reciba enteros, y max()
# admite tantos números como quieras. La diferencia en horizontal y la
# diferencia en vertical son los catetos de un triángulo rectángulo, y la
# distancia es su hipotenusa: √(3² + 4²) = 5.
func matematicas() -> void:
	print(sqrt(2))  # 1.4142135623731
	print(pow(2, 10))  # 1024.0
	print(absf(-7.5))  # 7.5
	print(max(3, 9, 4))  # 9
	var dx := 4.0 - 1.0  # De Niblo a Mubbit, en horizontal
	var dy := 6.0 - 2.0  # De Niblo a Mubbit, en vertical
	print(sqrt(dx * dx + dy * dy))  # 5.0


# 2. El diccionario empieza vacío y cuentas.get(suma, 0) devuelve 0 la
# primera vez que sale cada suma. Siempre gana el 7, porque se puede sacar de
# seis formas (1 + 6, 2 + 5…), y el 2 y el 12 son los más raros, con una sola.
# Con la misma semilla, dos ejecuciones dan exactamente los mismos números:
# así se repite una partida o se encuentra un error que depende del azar.
func tiradas_2d6(rng: RandomNumberGenerator) -> Dictionary:
	var cuentas := {}
	for i in 10000:
		var suma := rng.randi_range(1, 6)
		suma += rng.randi_range(1, 6)  # Dos dados
		cuentas[suma] = cuentas.get(suma, 0) + 1
	var mas_frecuente := 2
	for resultado: int in cuentas:
		if cuentas[resultado] > cuentas[mas_frecuente]:
			mas_frecuente = resultado
	print(cuentas, " Más frecuente: ", mas_frecuente)
	return cuentas


# 3. La primera vez no hay archivo, así que cargar_partida() crea una partida
# nueva. JSON es texto y no distingue entre enteros y decimales: al leerlo,
# todos los números vuelven como float, y el nivel 1 vuelve como 1.0.
func guardar_partida(partida: Dictionary) -> void:
	var archivo := FileAccess.open(RUTA, FileAccess.WRITE)
	archivo.store_string(JSON.stringify(partida))


func cargar_partida() -> Dictionary:
	if not FileAccess.file_exists(RUTA):
		return {"nombre": "Niblo", "nivel": 1, "salud": 100,
			"inventario": ["espada", "poción"]}
	var texto := FileAccess.get_file_as_string(RUTA)
	return JSON.parse_string(texto)


# 4. Las funciones de Geometria (geometria.gd) son static: se llaman con el
# nombre de la clase, sin new(), desde cualquier script del proyecto.
func usar_geometria() -> void:
	var a := Vector2(0, 0)
	var b := Vector2(30, 40)
	print(Geometria.distancia(a, b))  # 50.0
	print(Geometria.distancia(Vector2(1, 2), Vector2(4, 6)))  # 5.0
	print(Geometria.distancia(b, b))  # 0.0
	print(Geometria.punto_medio(a, b))  # (15.0, 20.0)
	print(Geometria.punto_medio(Vector2(-2, 4), Vector2(2, 0)))  # (0.0, 2.0)
	print(Geometria.punto_medio(b, b))  # (30.0, 40.0)
	print(Geometria.area_triangulo(6, 4))  # 12.0
	print(Geometria.area_triangulo(10, 3))  # 15.0
	print(Geometria.area_triangulo(5, 5))  # 12.5
