extends Node2D  # Atrapa a Mubbit
# Solución del ejercicio 5 de «Librerías» (capítulo 2, apartado 2.10).
# Es el script de la escena 7_atrapa_a_mubbit.tscn, donde Niblo y Mubbit son
# dos Sprite2D hijos de MainScene. Ejecútala con F6 (Run Current Scene) y
# mueve a Niblo con las flechas. Ejecútala dos veces seguidas: en la segunda,
# el récord de la primera aparece desde el principio, porque Records lo lee
# de user://records.json. Para empezar de cero, borra ese archivo desde la
# carpeta que abre Project → Open User Data Folder.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 7_bibliotecas.gd,
# en https://milq.github.io/libros/pria/gdscript/

@export var velocidad := 300.0
var puntos := 0
var record := 0


func _ready() -> void:
	record = Records.cargar()
	print("Récord: %d" % record)
	$Niblo.position = get_viewport_rect().size / 2.0
	mover_mubbit()


func mover_mubbit() -> void:
	var tamaño := get_viewport_rect().size
	var x := randf_range(0.0, tamaño.x)
	var y := randf_range(0.0, tamaño.y)
	$Mubbit.position = Vector2(x, y)


func _process(delta: float) -> void:
	var direccion := Input.get_vector(
		"ui_left", "ui_right", "ui_up", "ui_down")
	$Niblo.position += direccion * velocidad * delta
	if $Niblo.position.distance_to($Mubbit.position) < 32.0:
		puntos += 1
		mover_mubbit()
		if puntos > record:
			record = puntos
			Records.guardar(record)
		print("Puntos: %d  Récord: %d" % [puntos, record])
