extends Node2D
# Solución del ejercicio 70 del apéndice A: «En una escena, coloca el icono con
# $Icono en _ready(), muévelo en _process() y reiníciala con la tecla R».
# Es el script de la raíz de 6_escena.tscn, que tiene un Sprite2D hijo
# llamado Icono, con icon.svg en su Texture. Abre la escena y pulsa F6: las
# flechas mueven el icono, y R lo devuelve al centro.

@export var velocidad := 300.0  # Píxeles por segundo, editable en el Inspector


# Godot llama a _ready() una vez, al empezar. $Icono es el nodo hijo llamado
# Icono, y la mitad del tamaño de la ventana es su centro.
func _ready() -> void:
	$Icono.position = get_viewport_rect().size / 2


# Godot llama a _process() en cada fotograma, con delta, los segundos desde el
# anterior: multiplicar por delta hace que el icono vaya a la misma velocidad
# con cualquier número de fotogramas por segundo.
func _process(delta: float) -> void:
	var direccion: Vector2 = Input.get_vector(
			"ui_left", "ui_right", "ui_up", "ui_down")
	$Icono.position += direccion * velocidad * delta


# Godot llama a _unhandled_input() con cada pulsación que no ha usado otro
# nodo. reload_current_scene() vuelve a cargar la escena, como al empezar.
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_R:
			get_tree().reload_current_scene()
