extends Node  # Autoload Records: guarda y carga el récord
# Solución del ejercicio 5 de «Librerías» (capítulo 2, apartado 2.10).
# Está registrado como autoload con el nombre Records en Project → Project
# Settings → Globals. Godot lo crea al arrancar, antes que la escena
# principal, y lo mantiene aunque cambies de escena: cualquier script puede
# usarlo por su nombre. Solo hay un Records en todo el juego.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 7_bibliotecas.gd,
# en https://milq.github.io/libros/pria/gdscript/

const RUTA := "user://records.json"


# La primera vez que se juega aún no hay archivo, así que se comprueba antes.
# JSON.parse_string() devuelve un valor genérico; se guarda en un Dictionary
# para leer su clave "record", y int() lo convierte, porque JSON devuelve los
# números como float. Si el archivo estuviera estropeado, devolvería null.
func cargar() -> int:
	if not FileAccess.file_exists(RUTA):
		return 0  # Aún no hay récord
	var texto := FileAccess.get_file_as_string(RUTA)
	var datos: Dictionary = JSON.parse_string(texto)
	return int(datos["record"])


func guardar(record: int) -> void:
	var archivo := FileAccess.open(RUTA, FileAccess.WRITE)
	archivo.store_string(JSON.stringify({"record": record}))
