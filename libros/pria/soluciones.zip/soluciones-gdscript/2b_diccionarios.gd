@tool
extends EditorScript
# Soluciones de los ejercicios 21 a 30 del apéndice A, «Diccionarios».
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en el panel
# Output. Solo usa lo que explica el apéndice hasta su apartado
# «Diccionarios»: puede usar arrays, pero no condicionales ni bucles. Cada
# ejercicio va en su propia función, para que sus variables no choquen; tú
# puedes escribirlos en _run(), uno tras otro.


func _run() -> void:
	ejercicio_21()
	ejercicio_22()
	ejercicio_23()
	ejercicio_24()
	ejercicio_25()
	ejercicio_26()
	ejercicio_27()
	ejercicio_28()
	ejercicio_29()
	ejercicio_30()


# 21. Declara un diccionario con las claves «nombre», «vida» y «nivel» de
# Mubbit, y lee su nombre con los corchetes.
func ejercicio_21() -> void:
	print("— Ejercicio 21 —")
	# Un valor se busca por su clave, no por su posición. Godot no sabe de
	# antemano de qué tipo es lo que guarda un diccionario, así que la
	# variable lleva el tipo escrito.
	var mubbit: Dictionary = {"nombre": "Mubbit", "vida": 30, "nivel": 2}
	var nombre: String = mubbit["nombre"]
	print(nombre)  # Mubbit


# 22. Incrementa en 1 el «nivel» de Mubbit con +=, añádele el par «objeto»:
# «varita» y elimínalo con erase().
func ejercicio_22() -> void:
	print("— Ejercicio 22 —")
	# Asignar a una clave que no existe añade el par.
	var mubbit: Dictionary = {"nombre": "Mubbit", "vida": 30, "nivel": 2}
	mubbit["nivel"] += 1
	mubbit["objeto"] = "varita"
	print(mubbit)  # { "nombre": "Mubbit", "vida": 30, "nivel": 3, "objeto": "varita" }
	mubbit.erase("objeto")
	print(mubbit)  # { "nombre": "Mubbit", "vida": 30, "nivel": 3 }


# 23. Comprueba con in y con has() si existe la clave «vida», y lee con get()
# la clave «escudo» con 0 por defecto.
func ejercicio_23() -> void:
	print("— Ejercicio 23 —")
	# Con los corchetes, una clave que no existe da un error; get() devuelve
	# el valor por defecto que le pases.
	var mubbit: Dictionary = {"nombre": "Mubbit", "vida": 30, "nivel": 2}
	print("vida" in mubbit)       # true
	print(mubbit.has("vida"))     # true
	var escudo: int = mubbit.get("escudo", 0)
	print(escudo)                 # 0


# 24. Muestra las claves de Mubbit con keys(), sus valores con values() y
# cuántos pares tiene en total con size().
func ejercicio_24() -> void:
	print("— Ejercicio 24 —")
	var mubbit: Dictionary = {"nombre": "Mubbit", "vida": 30, "nivel": 2}
	print(mubbit.keys())    # ["nombre", "vida", "nivel"]
	print(mubbit.values())  # ["Mubbit", 30, 2]
	print(mubbit.size())    # 3


# 25. Declara un Dictionary[String, int] con los puntos de dos jugadores, y
# guarda uno en una variable Variant.
func ejercicio_25() -> void:
	print("— Ejercicio 25 —")
	# Con Dictionary[String, int], las claves solo pueden ser textos, y los
	# valores, enteros. Una variable Variant admite cualquier valor.
	var puntos: Dictionary[String, int] = {"Niblo": 30, "Mubbit": 25}
	var uno: Variant = puntos["Niblo"]
	print(uno, " ", type_string(typeof(uno)))  # 30 int


# 26. Comprueba con has_all() si Mubbit tiene «vida» y «nivel», y con
# is_empty() si está vacío tras clear().
func ejercicio_26() -> void:
	print("— Ejercicio 26 —")
	var mubbit: Dictionary = {"nombre": "Mubbit", "vida": 30, "nivel": 2}
	print(mubbit.has_all(["vida", "nivel"]))  # true
	mubbit.clear()
	print(mubbit.is_empty())  # true


# 27. Copia un diccionario con duplicate(), cambia un valor de la copia y
# compara los dos con ==, != y hash().
func ejercicio_27() -> void:
	print("— Ejercicio 27 —")
	# hash() da un entero que resume el contenido: dos diccionarios iguales dan
	# el mismo, y casi siempre, dos distintos, uno distinto.
	var mubbit: Dictionary = {"nombre": "Mubbit", "vida": 30, "nivel": 2}
	var copia := mubbit.duplicate()
	print(mubbit == copia, " ", mubbit.hash() == copia.hash())  # true true
	copia["vida"] = 10
	print(mubbit == copia, " ", mubbit != copia)  # false true
	print(mubbit.hash() == copia.hash())          # false


# 28. Combina con merge() {"pociones": 2} y {"pociones": 5, "llaves": 1},
# para que gane este.
func ejercicio_28() -> void:
	print("— Ejercicio 28 —")
	# merge() añade al primero los pares del segundo. Con true, si una clave
	# está en los dos, gana el valor del segundo; sin él, se queda el del
	# primero.
	var bolsa := {"pociones": 2}
	var botin := {"pociones": 5, "llaves": 1}
	bolsa.merge(botin, true)
	print(bolsa)  # { "pociones": 5, "llaves": 1 }


# 29. Guarda en un diccionario otro con la «edad» de Ana y un array de notas, y
# lee la edad y la segunda nota.
func ejercicio_29() -> void:
	print("— Ejercicio 29 —")
	# Cada par de corchetes baja un nivel: datos["ana"] es el diccionario de
	# Ana, y datos["ana"]["edad"], su edad. La segunda nota es la del índice 1.
	var datos: Dictionary = {"ana": {"edad": 30}, "notas": [7, 9]}
	var edad: int = datos["ana"]["edad"]
	var nota: int = datos["notas"][1]
	print(edad, " ", nota)  # 30 9


# 30. Declara un Array[Dictionary] con el nombre y la edad de dos jugadores, y
# accede al nombre del segundo.
func ejercicio_30() -> void:
	print("— Ejercicio 30 —")
	var jugadores: Array[Dictionary] = [
		{"nombre": "Niblo", "edad": 12},
		{"nombre": "Mubbit", "edad": 9},
	]
	var segundo: String = jugadores[1]["nombre"]
	print(segundo)  # Mubbit
