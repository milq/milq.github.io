@tool
extends EditorScript
# Soluciones de los ejercicios 1 a 10 del apéndice A, «Variables», con el
# texto y la conversión de tipos. Ejecútalo con File → Run (Ctrl + Shift + X):
# el resultado sale en el panel Output. Hay muchas formas correctas de resolver
# cada ejercicio; esta es solo una, y solo usa lo que explica el apéndice hasta
# su apartado «Texto y conversión de tipos», salvo @warning_ignore, que quita
# el aviso de la división entera.
# Cada ejercicio va en su propia función, ejercicio_1() a ejercicio_10(), para
# que sus variables no choquen: dentro de una función no se puede declarar dos
# veces el mismo nombre. Tú puedes escribirlos en _run(), uno tras otro, como
# en el apéndice, borrando el anterior o convirtiéndolo en comentario.


func _run() -> void:
	ejercicio_1()
	ejercicio_2()
	ejercicio_3()
	ejercicio_4()
	ejercicio_5()
	ejercicio_6()
	ejercicio_7()
	ejercicio_8()
	ejercicio_9()
	ejercicio_10()


# 1. Declara el entero vida con 100, el real velocidad con 2.5, la cadena
# nombre y el booleano activo, con true.
func ejercicio_1() -> void:
	print("— Ejercicio 1 —")
	# Con el tipo escrito tras los dos puntos, Godot avisa antes de ejecutar
	# si le das a la variable un valor de otro tipo.
	var vida: int = 100
	var velocidad: float = 2.5
	var nombre: String = "Niblo"
	var activo: bool = true
	print(vida, " ", velocidad, " ", nombre, " ", activo)  # 100 2.5 Niblo true


# 2. Escribe un comentario de una línea con # y otro de varias líneas entre
# """, y explica en ellos tu código.
func ejercicio_2() -> void:
	print("— Ejercicio 2 —")
	# La vida empieza llena: este comentario ocupa una sola línea
	var vida: int = 100
	"""
	Un comentario de varias líneas va entre tres comillas.
	Godot no lo ejecuta, así que sirve para explicar
	lo que hace un trozo entero de código.
	"""
	print("Vida: ", vida)  # Vida: 100


# 3. Declara altura := 182 y peso := 87.5, y muestra con type_string() y
# typeof() qué tipo ha deducido Godot.
func ejercicio_3() -> void:
	print("— Ejercicio 3 —")
	# Con :=, Godot deduce el tipo del valor: sin punto decimal es un entero,
	# y con él, un real. typeof() da el tipo como número, y type_string(), su
	# nombre.
	var altura := 182
	var peso := 87.5
	print(type_string(typeof(altura)))  # int
	print(type_string(typeof(peso)))    # float


# 4. Declara una variable sin tipo con el entero 5, asígnale después la cadena
# «cinco» y muestra su tipo cada vez.
func ejercicio_4() -> void:
	print("— Ejercicio 4 —")
	# Sin tipo, la variable admite cualquier valor, y su tipo cambia con él.
	var dato = 5
	print(type_string(typeof(dato)))  # int
	dato = "cinco"
	print(type_string(typeof(dato)))  # String


# 5. Declara la constante real GRAVEDAD con 9.8, asígnale otro valor en la
# línea siguiente y lee el error de Godot.
func ejercicio_5() -> void:
	print("— Ejercicio 5 —")
	const GRAVEDAD: float = 9.8
	# Si quitas el # de la línea de abajo, Godot marca la línea en rojo y no
	# deja ejecutar el script: «Cannot assign a new value to a constant.», no se
	# puede dar un valor nuevo a una constante. Una constante no cambia nunca.
	# GRAVEDAD = 1.6
	print(GRAVEDAD)  # 9.8


# 6. Declara la variable entera vida con 100, réstale 15 tres veces con -= y
# súmale 20 con +=. Muestra su valor.
func ejercicio_6() -> void:
	print("— Ejercicio 6 —")
	# vida -= 15 es lo mismo que vida = vida - 15.
	var vida: int = 100
	vida -= 15
	vida -= 15
	vida -= 15
	vida += 20
	print(vida)  # 75: 100 - 45 + 20


# 7. Evalúa 2 + 3 * 4, (2 + 3) * 4 y 2 * 3 ** 2, y explica en un comentario
# qué operación va antes en cada una.
func ejercicio_7() -> void:
	print("— Ejercicio 7 —")
	print(2 + 3 * 4)    # 14: * va antes que +
	print((2 + 3) * 4)  # 20: lo de dentro del paréntesis va primero
	print(2 * 3 ** 2)   # 18: ** va antes que *, y 3 ** 2 es 9


# 8. Divide 7 entre 2 con operandos enteros, que da 3, y con reales, que da
# 3.5, y muestra también PI con %.2f.
func ejercicio_8() -> void:
	print("— Ejercicio 8 —")
	# Entre dos enteros, / hace una división entera y pierde los decimales.
	# Godot avisa de ello; aquí es justo lo que se busca, y @warning_ignore
	# quita el aviso.
	@warning_ignore("integer_division")
	var entera: int = 7 / 2
	var real: float = 7.0 / 2.0
	print(entera, " ", real)  # 3 3.5
	# %.2f es un hueco para un real con dos decimales.
	print("%.2f" % PI)  # 3.14


# 9. Convierte "350" en entero con int(), "95.4" en real con float() y 42 en
# cadena con str(), y únela a otra con +.
func ejercicio_9() -> void:
	print("— Ejercicio 9 —")
	var entero := int("350")
	var real := float("95.4")
	var texto := str(42)
	print(entero + 1)              # 351: ya es un número, y se puede sumar
	print(real)                    # 95.4
	print("Respuesta: " + texto)   # Respuesta: 42
	# Sin str(), "Respuesta: " + 42 daría un error: + no une un texto y un
	# número.


# 10. Pasa 135 segundos a «2 min 15 s» con / y %, y muéstralo de tres formas:
# con comas, con %d y con format().
func ejercicio_10() -> void:
	print("— Ejercicio 10 —")
	# 135 / 60 da los minutos completos, 2, y 135 % 60, los segundos que
	# sobran, 15.
	var total: int = 135
	@warning_ignore("integer_division")
	var minutos: int = total / 60
	var segundos: int = total % 60
	print(minutos, " min ", segundos, " s")             # Con comas
	print("%d min %d s" % [minutos, segundos])          # Con %d
	print("{0} min {1} s".format([minutos, segundos]))  # Con format()
