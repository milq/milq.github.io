@tool
extends EditorScript
# Soluciones de «Variables» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.
# Solo usa lo que hay en 0_hola_mundo.gd y 1_variables.gd, en
# https://milq.github.io/libros/pria/gdscript/


func _run() -> void:
	# EJERCICIO 1
	# El operador % sustituye cada hueco del texto por un valor del array, en
	# orden: %s por un texto y %d por un entero.
	print("— Ejercicio 1 —")
	var nombre := "Niblo"
	var nivel := 3
	print("¡Hola, mundo!")
	print("Soy %s y estoy en el nivel %d" % [nombre, nivel])

	# EJERCICIO 2
	# PI es una constante de Godot con el valor de π. El formato %.2f muestra
	# un real con dos decimales, redondeando.
	print("— Ejercicio 2 —")
	var radio := 5.0
	var perimetro := 2 * PI * radio
	var area := PI * radio * radio
	print("Perímetro: %.2f m" % perimetro)  # 31.42
	print("Área: %.2f m²" % area)  # 78.54

	# EJERCICIO 3
	# float() convierte el texto en un número real. Sin convertirlo, Godot no
	# dejaría restarle un número: un texto y un número no se pueden restar.
	print("— Ejercicio 3 —")
	var record := "234.62"
	var nuevo := float(record) - 21.34
	print(nuevo)  # 213.28

	# EJERCICIO 4
	# Entre dos enteros, / hace una división entera: 754 / 60 da los minutos
	# completos, 12, y 754 % 60, los segundos que sobran, 34. Godot avisa de
	# que se pierden los decimales; aquí es justo lo que se busca, así que el
	# aviso se quita con @warning_ignore. Para probarlo con 59, se asigna el
	# nuevo valor y se repiten los cálculos: 0 min 59 s.
	print("— Ejercicio 4 —")
	var total := 754
	@warning_ignore("integer_division")
	var minutos: int = total / 60
	var segundos: int = total % 60
	print("%d min %d s" % [minutos, segundos])  # 12 min 34 s
	total = 59
	@warning_ignore("integer_division")
	minutos = total / 60
	segundos = total % 60
	print("%d min %d s" % [minutos, segundos])  # 0 min 59 s
