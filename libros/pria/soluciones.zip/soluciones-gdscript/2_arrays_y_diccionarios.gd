@tool
extends EditorScript
# Soluciones de «Arrays y diccionarios» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 2b_diccionarios.gd,
# en https://milq.github.io/libros/pria/gdscript/


func _run() -> void:
	# EJERCICIO 1
	# Los índices empiezan en 0, así que el tercero es el 2, y el último es el
	# -1, tenga los elementos que tenga el array. inventario[-1] sigue siendo
	# el último aunque Niblo coja o suelte objetos; inventario[4] dejaría de
	# serlo. Pedir un índice que no existe da el error «Out of bounds».
	print("— Ejercicio 1 —")
	var inventario: Array[String] = ["espada", "poción", "llave", "mapa",
		"arco"]
	print(inventario[0], " ", inventario[2], " ", inventario[-1])

	# EJERCICIO 2
	# Al quitar un elemento, los que van detrás bajan una posición: si se
	# quitara primero el 0, el que era el 2 pasaría a ser el 1. Por eso se
	# borra de atrás adelante.
	print("— Ejercicio 2 —")
	var cola: Array[String] = ["slime", "murciélago", "esqueleto", "fantasma",
		"jefe"]
	cola.remove_at(4)  # Primero el último: así no se mueven
	cola.remove_at(2)  # los índices de los que quedan
	cola.remove_at(0)
	print(cola)  # ["murciélago", "fantasma"]

	# EJERCICIO 3
	# sort() ordena de menor a mayor y reverse() le da la vuelta. Los textos,
	# en cambio, se ordenan letra a letra, como en un diccionario: «10» y
	# «100» empiezan por «1», que va antes que «9». Para ordenarlos como
	# números, hay que convertirlos antes con int().
	print("— Ejercicio 3 —")
	var tiempos: Array[float] = [83.2, 79.5, 88.0, 80.5]
	tiempos.sort()
	print(tiempos)  # [79.5, 80.5, 83.2, 88.0]
	tiempos.reverse()
	print(tiempos)  # [88.0, 83.2, 80.5, 79.5]
	var textos: Array[String] = ["10", "9", "100"]
	textos.sort()
	print(textos)  # ["10", "100", "9"]

	# EJERCICIO 4
	# Con += se suma a lo que ya había; asignar a una clave nueva la añade, y
	# erase() la quita. in comprueba si una clave existe.
	print("— Ejercicio 4 —")
	var mochila: Dictionary = {"espada": 1, "poción": 3}
	mochila["poción"] += 2
	mochila["escudo"] = 1
	mochila.erase("espada")
	print(mochila)  # { "poción": 5, "escudo": 1 }
	print("Claves: ", mochila.keys())  # ["poción", "escudo"]
	print("Valores: ", mochila.values())  # [5, 1]
	print("Objetos distintos: ", mochila.size())  # 2
	print("¿Tiene una llave? ", "llave" in mochila)  # false
