@tool
extends EditorScript
# Soluciones de «Condicionales» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 3_condicionales.gd,
# en https://milq.github.io/libros/pria/gdscript/
# Todavía no hay bucles, así que cada solución se prueba con un ejemplo: para
# probar los demás, cambia los valores y vuelve a ejecutarlo.


func _run() -> void:
	# EJERCICIO 1
	# Las condiciones se comprueban en orden, así que en el primer elif ya se
	# sabe que los puntos no son menos de 0: basta con comprobar que no pasan
	# de 50.
	print("— Ejercicio 1 —")
	var puntos := 73  # Prueba también con -5, 30 y 150
	if puntos < 0:
		print(puntos, ": puntuación no válida")
	elif puntos <= 50:
		print(puntos, ": bronce")
	elif puntos <= 100:
		print(puntos, ": plata")  # 73: plata
	else:
		print(puntos, ": oro")

	# EJERCICIO 2
	# «Entre 10 y 19, ambos incluidos» se escribe con >=, <= y and.
	print("— Ejercicio 2 —")
	var carta_1 := 7  # Prueba también con -5 y 7, -10 y 20, y -15 y 43
	var carta_2 := 6
	var suma := carta_1 + carta_2
	if suma >= 10 and suma <= 19:
		suma = 20
	print(carta_1, " y ", carta_2, ": ", suma)  # 20 (y después, 2, 20 y 28)

	# EJERCICIO 3
	# Primero se descartan las cartas que se pasan; si no se pasa ninguna,
	# gana la mayor, que es justo la más cercana a 21. El orden de las
	# condiciones importa: hay que descartar primero las que se pasan.
	print("— Ejercicio 3 —")
	var primera := 19  # Prueba también con 22 y 17, 16 y 23, y 25 y 30
	var segunda := 21
	var mas_cercana := 0
	if primera > 21 and segunda > 21:
		mas_cercana = 0
	elif primera > 21:
		mas_cercana = segunda
	elif segunda > 21:
		mas_cercana = primera
	elif primera > segunda:
		mas_cercana = primera
	else:
		mas_cercana = segunda
	print(primera, " y ", segunda, ": ", mas_cercana)  # 21 (y 17, 16 y 0)
