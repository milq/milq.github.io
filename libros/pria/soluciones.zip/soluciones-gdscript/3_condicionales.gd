@tool
extends EditorScript
# Soluciones de los ejercicios 31 a 40 del apéndice A, «Condicionales».
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en el panel
# Output. Solo usa lo que explica el apéndice hasta su apartado
# «Condicionales», sin bucles. Cada ejercicio va en su propia función, para
# que sus variables no choquen; tú puedes escribirlos en _run(), uno tras otro.


func _run() -> void:
	ejercicio_31()
	ejercicio_32()
	ejercicio_33()
	ejercicio_34()
	ejercicio_35()
	ejercicio_36()
	ejercicio_37()
	ejercicio_38()
	ejercicio_39()
	ejercicio_40()


# 31. Compara a igual a 5 y b igual a 3 con ==, !=, >, >=, < y <=, y muestra el
# valor booleano que da cada comparación.
func ejercicio_31() -> void:
	print("— Ejercicio 31 —")
	var a: int = 5
	var b: int = 3
	print(a == b)  # false
	print(a != b)  # true
	print(a > b)   # true
	print(a >= b)  # true
	print(a < b)   # false
	print(a <= b)  # false


# 32. Combina dos comparaciones con and, or y not, y comprueba con print() en
# qué casos da true cada una.
func ejercicio_32() -> void:
	print("— Ejercicio 32 —")
	# and da true si las dos son true; or, si lo es al menos una, y not
	# invierte el valor.
	var vida: int = 40
	var tiene_llave: bool = false
	print(vida > 0 and tiene_llave)   # false: falta la llave
	print(vida > 0 or tiene_llave)    # true: basta con la vida
	print(not tiene_llave)            # true
	tiene_llave = true
	print(vida > 0 and tiene_llave)   # true: ya se cumplen las dos


# 33. Si la variable vida es menor que 20, muestra «¡Peligro!», y si no,
# «Todo bien». Pruébalo con 15 y 80.
func ejercicio_33() -> void:
	print("— Ejercicio 33 —")
	var vida: int = 15
	if vida < 20:
		print("¡Peligro!")  # Sale este
	else:
		print("Todo bien")
	vida = 80
	if vida < 20:
		print("¡Peligro!")
	else:
		print("Todo bien")  # Sale este


# 34. Convierte una nota real de 0 a 10 en suspenso, aprobado, notable o
# sobresaliente con if, elif y else.
func ejercicio_34() -> void:
	print("— Ejercicio 34 —")
	# Las condiciones se comprueban en orden, y solo se ejecuta la primera que
	# se cumple: si la nota no es menor que 5, se mira si es menor que 7, y
	# así sigue.
	var nota: float = 8.5
	var texto: String
	if nota < 5.0:
		texto = "Suspenso"
	elif nota < 7.0:
		texto = "Aprobado"
	elif nota < 9.0:
		texto = "Notable"
	else:
		texto = "Sobresaliente"
	print(nota, ": ", texto)  # 8.5: Notable


# 35. Asigna «par» o «impar» a una variable con el operador ternario, según el
# resto de dividir los puntos entre 2.
func ejercicio_35() -> void:
	print("— Ejercicio 35 —")
	# Un número es par si al dividirlo entre 2 no sobra nada.
	var puntos: int = 7
	var tipo := "par" if puntos % 2 == 0 else "impar"
	print(puntos, " es ", tipo)  # 7 es impar


# 36. Si el inventario contiene «llave» y el diccionario de Mubbit tiene la
# clave «objeto», muestra «Puede pasar».
func ejercicio_36() -> void:
	print("— Ejercicio 36 —")
	var inventario: Array[String] = ["poción", "llave"]
	var mubbit: Dictionary = {"nombre": "Mubbit", "objeto": "varita"}
	if inventario.has("llave") and mubbit.has("objeto"):
		print("Puede pasar")  # Sale: se cumplen las dos


# 37. Con match, convierte «W», «A», «S» y «D» en «arriba», «izquierda»,
# «abajo» y «derecha», y el resto en «nada».
func ejercicio_37() -> void:
	print("— Ejercicio 37 —")
	# match compara la tecla con cada rama, y _ es «cualquier otra».
	var tecla: String = "A"
	var direccion: String
	match tecla:
		"W":
			direccion = "arriba"
		"A":
			direccion = "izquierda"
		"S":
			direccion = "abajo"
		"D":
			direccion = "derecha"
		_:
			direccion = "nada"
	print(tecla, ": ", direccion)  # A: izquierda


# 38. Con match, da 10 puntos al 1, 20 al 2 o al 3 en una misma rama, y 0 a
# cualquier otro número con el comodín _.
func ejercicio_38() -> void:
	print("— Ejercicio 38 —")
	# Varios valores separados por comas comparten rama.
	var numero: int = 3
	var puntos: int
	match numero:
		1:
			puntos = 10
		2, 3:
			puntos = 20
		_:
			puntos = 0
	print(numero, ": ", puntos)  # 3: 20


# 39. Si la cadena "300m" acaba en «m», extrae el número con substr() y
# length(), conviértelo y pásalo a centímetros.
func ejercicio_39() -> void:
	print("— Ejercicio 39 —")
	# El índice -1 de una cadena es su último carácter. substr(0, n) da los n
	# primeros, y n es la longitud menos 1, la de la «m».
	var dato: String = "300m"
	if dato[-1] == "m":
		var metros := int(dato.substr(0, dato.length() - 1))
		print(metros * 100, " cm")  # 30000 cm


# 40. Comprueba si un año es bisiesto: divisible entre 4 y no entre 100, o
# divisible entre 400. Prueba 1900 y 2000.
func ejercicio_40() -> void:
	print("— Ejercicio 40 —")
	# Un año es divisible entre otro número si el resto es 0. Los paréntesis
	# dicen qué va junto: (entre 4 y no entre 100) o entre 400.
	var año: int = 1900
	var bisiesto: bool = (año % 4 == 0 and año % 100 != 0) or año % 400 == 0
	print(año, ": ", bisiesto)  # 1900: false, divisible entre 100 y no entre 400
	año = 2000
	bisiesto = (año % 4 == 0 and año % 100 != 0) or año % 400 == 0
	print(año, ": ", bisiesto)  # 2000: true, divisible entre 400
