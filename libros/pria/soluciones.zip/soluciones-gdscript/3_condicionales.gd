@tool
extends EditorScript
# Soluciones de «Condicionales» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.
# Cada solución se prueba con los ejemplos del enunciado.


func _run() -> void:
	ejercicio_1()
	ejercicio_2()
	ejercicio_3()


# Las condiciones se comprueban en orden, así que en el primer elif ya se
# sabe que los puntos no son menos de 0: basta con comprobar que no pasan
# de 50.
func ejercicio_1() -> void:
	print("— Ejercicio 1 —")
	for puntos: int in [-5, 30, 73, 150]:
		if puntos < 0:
			print(puntos, ": puntuación no válida")
		elif puntos <= 50:
			print(puntos, ": bronce")
		elif puntos <= 100:
			print(puntos, ": plata")
		else:
			print(puntos, ": oro")


# «Entre 10 y 19, ambos incluidos» se escribe con >=, <= y and.
func ejercicio_2() -> void:
	print("— Ejercicio 2 —")
	for cartas: Array in [[7, 6], [-5, 7], [-10, 20], [-15, 43]]:
		var suma: int = cartas[0] + cartas[1]
		if suma >= 10 and suma <= 19:
			suma = 20
		print(cartas, ": ", suma)  # 20, 2, 20 y 28


# Primero se descartan las cartas que se pasan; si no se pasa ninguna, gana
# la mayor, que es justo la más cercana a 21. El orden de las condiciones
# importa: hay que descartar primero las que se pasan.
func ejercicio_3() -> void:
	print("— Ejercicio 3 —")
	for cartas: Array in [[19, 21], [22, 17], [16, 23], [25, 30]]:
		var a: int = cartas[0]
		var b: int = cartas[1]
		var resultado := 0
		if a > 21 and b > 21:
			resultado = 0
		elif a > 21:
			resultado = b
		elif b > 21:
			resultado = a
		else:
			resultado = maxi(a, b)
		print(cartas, ": ", resultado)  # 21, 17, 16 y 0
