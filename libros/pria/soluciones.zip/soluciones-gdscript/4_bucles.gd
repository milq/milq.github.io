@tool
extends EditorScript
# Soluciones de los ejercicios 41 a 50 del apéndice A, «Bucles». Ejecútalo con
# File → Run (Ctrl + Shift + X): el resultado sale en el panel Output. Solo usa
# lo que explica el apéndice hasta su apartado «Bucles». Cada ejercicio va en
# su propia función, para que sus variables no choquen; tú puedes escribirlos
# en _run(), uno tras otro.


func _run() -> void:
	ejercicio_41()
	ejercicio_42()
	ejercicio_43()
	ejercicio_44()
	ejercicio_45()
	ejercicio_46()
	ejercicio_47()
	ejercicio_48()
	ejercicio_49()
	ejercicio_50()


# 41. Muestra con un bucle for y range() los enteros del 0 al 4, los del 1 al
# 10 y los del 10 al 0 con un paso de -2.
func ejercicio_41() -> void:
	print("— Ejercicio 41 —")
	# El final de range() no entra: range(5) llega al 4, y para llegar al 0
	# hacia atrás hay que poner -1. print() sin más salta de línea, así que
	# los números se juntan en un texto para verlos en una sola.
	var texto: String = ""
	for i: int in range(5):
		texto += str(i) + " "
	print(texto)  # 0 1 2 3 4
	texto = ""
	for i: int in range(1, 11):
		texto += str(i) + " "
	print(texto)  # 1 2 3 4 5 6 7 8 9 10
	texto = ""
	for i: int in range(10, -1, -2):
		texto += str(i) + " "
	print(texto)  # 10 8 6 4 2 0


# 42. Recorre un Array[String] de frutas con range() y size(), y muestra cada
# una con su número, desde el 1.
func ejercicio_42() -> void:
	print("— Ejercicio 42 —")
	# range(frutas.size()) da los índices, del 0 al 2, y el número que se
	# muestra es el índice más 1.
	var frutas: Array[String] = ["kiwi", "pera", "lima"]
	for i: int in range(frutas.size()):
		print(i + 1, ". ", frutas[i])  # 1. kiwi, 2. pera, 3. lima


# 43. Acumula con un for la suma y, con *=, el producto de los reales [3.0,
# 2.0, -1.0, 4.0], y muestra los dos.
func ejercicio_43() -> void:
	print("— Ejercicio 43 —")
	# La suma empieza en 0, que no cambia nada al sumar, y el producto en 1,
	# que no cambia nada al multiplicar.
	var suma: float = 0.0
	var producto: float = 1.0
	for num: float in [3.0, 2.0, -1.0, 4.0]:
		suma += num
		producto *= num
	print(suma, " ", producto)  # 8.0 -24.0


# 44. Resta 15 a una vida de 100 con un bucle while hasta que sea 0 o menor, y
# cuenta las iteraciones en otra variable.
func ejercicio_44() -> void:
	print("— Ejercicio 44 —")
	# while repite mientras se cumpla la condición: con 10 de vida aún entra,
	# y la vida baja a -5.
	var vida: int = 100
	var veces: int = 0
	while vida > 0:
		vida -= 15
		veces += 1
	print(vida, " en ", veces, " iteraciones")  # -5 en 7 iteraciones


# 45. Recorre con un bucle for las claves del diccionario de Mubbit y muestra
# cada una con su valor: «vida: 30».
func ejercicio_45() -> void:
	print("— Ejercicio 45 —")
	# Un for sobre un diccionario recorre sus claves, y con cada una se lee su
	# valor.
	var mubbit: Dictionary = {"nombre": "Mubbit", "vida": 30, "nivel": 2}
	for clave in mubbit:
		print(clave, ": ", mubbit[clave])  # nombre: Mubbit, vida: 30, nivel: 2


# 46. Llena con un bucle y append() un Array[int] vacío con los cubos de los
# enteros del 1 al 5, y muéstralo al final.
func ejercicio_46() -> void:
	print("— Ejercicio 46 —")
	var cubos: Array[int] = []
	for k: int in range(1, 6):
		cubos.append(k ** 3)
	print(cubos)  # [1, 8, 27, 64, 125]


# 47. Cuenta con un bucle for cuántas veces aparece «elfo» en un array de
# nombres, sin usar count(), y muéstralo.
func ejercicio_47() -> void:
	print("— Ejercicio 47 —")
	var nombres: Array[String] = ["elfo", "orco", "elfo", "enano", "elfo"]
	var veces: int = 0
	for nombre: String in nombres:
		if nombre == "elfo":
			veces += 1
	print(veces)  # 3


# 48. Recorre un array hasta encontrar el primer número mayor que 100,
# muéstralo y sal del bucle con break.
func ejercicio_48() -> void:
	print("— Ejercicio 48 —")
	# break deja el bucle en cuanto encuentra uno: el 180 ya no se mira.
	for num: int in [40, 95, 130, 70, 180]:
		if num > 100:
			print(num)  # 130
			break


# 49. Recorre la matriz [[1, 2], [3, 4], [5, 6]] con dos bucles for anidados,
# fila a fila, y suma todos sus datos.
func ejercicio_49() -> void:
	print("— Ejercicio 49 —")
	# El bucle de fuera da cada fila, y el de dentro, cada dato de esa fila.
	var matriz: Array[Array] = [[1, 2], [3, 4], [5, 6]]
	var total: int = 0
	for fila: Array in matriz:
		for dato: int in fila:
			total += dato
	print(total)  # 21


# 50. Recorre un diccionario de usuarios, cada uno con su nombre y su edad en
# otro diccionario, y muéstralos.
func ejercicio_50() -> void:
	print("— Ejercicio 50 —")
	# usuarios[id] es el diccionario de cada usuario, y de él se leen su
	# nombre y su edad.
	var usuarios: Dictionary = {
		"u1": {"nombre": "Ana", "edad": 30},
		"u2": {"nombre": "Luis", "edad": 25},
	}
	for id: String in usuarios.keys():
		var usuario: Dictionary = usuarios[id]
		print(id, ": ", usuario["nombre"], ", ", usuario["edad"], " años")  # u1: Ana, 30 años
