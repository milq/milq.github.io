@tool
extends EditorScript
# Soluciones de «Bucles» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.


func _run() -> void:
	ejercicio_1()
	ejercicio_2()
	ejercicio_3()
	ejercicio_4()


# range(1, 11) da los números del 1 al 10, porque el final no se incluye.
func ejercicio_1() -> void:
	print("— Ejercicio 1 —")
	for nivel in range(1, 11):
		print("Nivel %d: %d" % [nivel, 7 * nivel])


# n % 10 es la última cifra, y dividir entre 10 sin decimales la quita. Se
# repite mientras queden cifras, así que es un bucle while. El bucle cambia
# el propio n: al terminar vale 0, así que, si necesitas la puntuación
# después, guarda antes una copia. Con un número negativo no daría ni una
# vuelta; para que funcione, empieza con n = absi(n), que quita el signo.
func ejercicio_2() -> void:
	print("— Ejercicio 2 —")
	var n := 2024
	var suma := 0
	while n > 0:
		suma += n % 10  # La última cifra
		n = int(n / 10.0)  # Quita la última cifra
	print(suma)  # 8


# Un número es primo si ningún número entre 2 y él mismo lo divide. En
# cuanto aparece un divisor, break termina el bucle, porque ya se sabe que no
# es primo. Bastaría con probar hasta la raíz cuadrada del número, pero así
# se entiende mejor.
func ejercicio_3() -> void:
	print("— Ejercicio 3 —")
	var cofre := 29
	var es_primo := cofre >= 2
	for divisor in range(2, cofre):
		if cofre % divisor == 0:
			es_primo = false
			break  # Ya no hace falta seguir
	print(cofre, " es primo: ", es_primo)  # true

	var limite := 30
	var con_premio := []
	for n in range(2, limite + 1):
		var primo := true
		for divisor in range(2, n):
			if n % divisor == 0:
				primo = false
				break
		if primo:
			con_premio.append(n)
	print(con_premio)  # [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]


# Un bucle recorre las filas y otro, dentro de él, suma las monedas de cada
# una. -INF, menos infinito, garantiza que la primera suma sea mayor. Si dos
# filas sumaran lo mismo, ganaría la primera, porque se usa > y no >=.
func ejercicio_4() -> void:
	print("— Ejercicio 4 —")
	var tablero := [[6, 8, 1], [3, 5, 6], [3, 2, 1]]
	var mejor_fila: Array = tablero[0]
	var mejor_suma := -INF
	for fila: Array in tablero:
		var suma := 0
		for monedas: int in fila:
			suma += monedas
		if suma > mejor_suma:
			mejor_suma = suma
			mejor_fila = fila
	print(mejor_suma, " ", mejor_fila)  # 15.0 [6, 8, 1], real por -INF
