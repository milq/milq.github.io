@tool
extends EditorScript
# Soluciones de «Bucles» (capítulo 2, apartado 2.10).
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en Output.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 4_bucles.gd, en
# https://milq.github.io/libros/pria/gdscript/


func _run() -> void:
	# EJERCICIO 1
	# range(1, 11) da los números del 1 al 10, porque el final no se incluye.
	print("— Ejercicio 1 —")
	for nivel: int in range(1, 11):
		print("Nivel %d: %d" % [nivel, 7 * nivel])

	# EJERCICIO 2
	# n % 10 es la última cifra, y la división entera entre 10 la quita. Se
	# repite mientras queden cifras, así que es un bucle while. El bucle
	# cambia n: al terminar vale 0, por eso se trabaja con una copia de la
	# puntuación. Con un número negativo no daría ni una vuelta.
	print("— Ejercicio 2 —")
	var puntuacion := 2024
	var n := puntuacion
	var suma_cifras := 0
	while n > 0:
		suma_cifras += n % 10  # La última cifra
		@warning_ignore("integer_division")
		n = n / 10  # Quita la última cifra
	print(puntuacion, ": ", suma_cifras)  # 8

	# EJERCICIO 3
	# Un número es primo si ningún número entre 2 y él mismo lo divide. En
	# cuanto aparece un divisor, break termina el bucle, porque ya se sabe que
	# no es primo. Bastaría con probar hasta la raíz cuadrada del número, pero
	# así se entiende mejor. Para los cofres, la misma comprobación va dentro
	# de otro bucle, que prueba cada número del 2 al 30.
	print("— Ejercicio 3 —")
	var cofre := 29
	var es_primo := cofre >= 2
	for divisor: int in range(2, cofre):
		if cofre % divisor == 0:
			es_primo = false
			break  # Ya no hace falta seguir
	print(cofre, " es primo: ", es_primo)  # true

	var limite := 30
	var con_premio: Array[int] = []
	for numero: int in range(2, limite + 1):
		var primo := true
		for divisor: int in range(2, numero):
			if numero % divisor == 0:
				primo = false
				break
		if primo:
			con_premio.append(numero)
	print(con_premio)  # [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]

	# EJERCICIO 4
	# Un bucle recorre las filas y otro, dentro de él, suma las monedas de
	# cada una. mejor_suma empieza en -1, menos que cualquier fila, porque las
	# monedas nunca son negativas: así la primera fila siempre la supera. Si
	# dos filas sumaran lo mismo, ganaría la primera, porque se usa > y no >=.
	print("— Ejercicio 4 —")
	var tablero: Array[Array] = [[6, 8, 1], [3, 5, 6], [3, 2, 1]]
	var mejor_fila: Array = []
	var mejor_suma := -1
	for fila: Array in tablero:
		var suma_fila := 0
		for monedas: int in fila:
			suma_fila += monedas
		if suma_fila > mejor_suma:
			mejor_suma = suma_fila
			mejor_fila = fila
	print(mejor_fila, ": ", mejor_suma)  # [6, 8, 1]: 15
