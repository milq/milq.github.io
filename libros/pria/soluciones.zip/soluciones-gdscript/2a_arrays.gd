@tool
extends EditorScript
# Soluciones de los ejercicios 11 a 20 del apéndice A, «Arrays». Ejecútalo con
# File → Run (Ctrl + Shift + X): el resultado sale en el panel Output. Solo usa
# lo que explica el apéndice hasta su apartado «Arrays», sin condicionales ni
# bucles. Cada ejercicio va en su propia función, para que sus variables no
# choquen; tú puedes escribirlos en _run(), uno tras otro.


func _run() -> void:
	ejercicio_11()
	ejercicio_12()
	ejercicio_13()
	ejercicio_14()
	ejercicio_15()
	ejercicio_16()
	ejercicio_17()
	ejercicio_18()
	ejercicio_19()
	ejercicio_20()


# 11. Declara un array sin tipo con un texto, un entero y un real, y un
# Array[String] vacío. Muestra sus tamaños.
func ejercicio_11() -> void:
	print("— Ejercicio 11 —")
	# Sin tipo, un array admite elementos de tipos distintos. Con
	# Array[String], solo textos.
	var mezcla: Array = ["texto", 7, 2.5]
	var nombres: Array[String] = []
	print(mezcla.size(), " ", nombres.size())  # 3 0


# 12. Declara el Array[String] ["kiwi", "pera", "lima"] y muestra su tamaño y
# su último elemento con -1.
func ejercicio_12() -> void:
	print("— Ejercicio 12 —")
	# El índice -1 cuenta desde el final: es el último.
	var frutas: Array[String] = ["kiwi", "pera", "lima"]
	print(frutas[-1], " ", frutas.size())  # lima 3


# 13. Cambia el elemento 1 de ese array por «uva», añade «fresa» con append()
# y «mora» con push_front().
func ejercicio_13() -> void:
	print("— Ejercicio 13 —")
	# El primer elemento es el 0, así que el 1 es «pera».
	var frutas: Array[String] = ["kiwi", "pera", "lima"]
	frutas[1] = "uva"
	frutas.append("fresa")     # Al final
	frutas.push_front("mora")  # Al principio
	print(frutas)  # ["mora", "kiwi", "uva", "lima", "fresa"]


# 14. Inserta «higo» en el índice 1 con insert(), quita «kiwi» con erase() y
# quita el elemento 0 con remove_at().
func ejercicio_14() -> void:
	print("— Ejercicio 14 —")
	# erase() busca el elemento por su valor, y remove_at(), por su índice.
	var frutas: Array[String] = ["mora", "kiwi", "uva", "lima", "fresa"]
	frutas.insert(1, "higo")  # ["mora", "higo", "kiwi", "uva", ...]
	frutas.erase("kiwi")      # ["mora", "higo", "uva", "lima", "fresa"]
	frutas.remove_at(0)       # Quita «mora»
	print(frutas)  # ["higo", "uva", "lima", "fresa"]


# 15. Saca elementos con pop_at(1), pop_front() y pop_back(), muéstralos y
# vacía el array con clear().
func ejercicio_15() -> void:
	print("— Ejercicio 15 —")
	# Los pop quitan el elemento y lo devuelven. Godot no sabe de antemano de
	# qué tipo será, así que la variable lleva el tipo escrito.
	var frutas: Array[String] = ["higo", "uva", "lima", "fresa"]
	var del_medio: String = frutas.pop_at(1)    # uva
	var primera: String = frutas.pop_front()   # higo
	var ultima: String = frutas.pop_back()     # fresa
	print(del_medio, " ", primera, " ", ultima, " ", frutas)  # uva higo fresa ["lima"]
	frutas.clear()
	print(frutas)  # []


# 16. En [3, 1, 4, 1, 9], comprueba con has() si está el 9, busca el 4 con
# find() y cuenta los 1 con count().
func ejercicio_16() -> void:
	print("— Ejercicio 16 —")
	var nums: Array[int] = [3, 1, 4, 1, 9]
	print(nums.has(9))    # true
	print(nums.find(4))   # 2: su índice (sería -1 si no estuviera)
	print(nums.count(1))  # 2


# 17. Muestra el mínimo y el máximo de [3, 1, 4, 1, 9] con min() y max(),
# ordénalo con sort() e inviértelo.
func ejercicio_17() -> void:
	print("— Ejercicio 17 —")
	var nums: Array[int] = [3, 1, 4, 1, 9]
	var minimo: int = nums.min()
	var maximo: int = nums.max()
	print(minimo, " ", maximo)  # 1 9
	nums.sort()
	print(nums)  # [1, 1, 3, 4, 9]
	nums.reverse()
	print(nums)  # [9, 4, 3, 1, 1]


# 18. Desordena [3, 1, 4] con shuffle(), concatena [7, 8] con +, recorta el
# resultado con resize(3) y compáralos.
func ejercicio_18() -> void:
	print("— Ejercicio 18 —")
	# + no cambia el array: devuelve uno nuevo con los dos seguidos. resize(3)
	# lo deja en sus 3 primeros elementos, que son los del desordenado, así que
	# == da true, desordene como desordene.
	var nums: Array[int] = [3, 1, 4]
	nums.shuffle()
	var junto := nums + [7, 8]
	print(junto)  # Por ejemplo, [4, 3, 1, 7, 8]
	junto.resize(3)
	print(junto == nums)  # true


# 19. De ["A", "B", "C", "D"], saca con slice() los índices del 1 al 3 y del 3
# al 1 hacia atrás, y únelos con join().
func ejercicio_19() -> void:
	print("— Ejercicio 19 —")
	# El fin de slice() no entra: para llegar al índice 3 hay que poner 4, y
	# hacia atrás, con paso -1, para llegar al 1 hay que poner 0.
	var letras: Array[String] = ["A", "B", "C", "D"]
	var ida := letras.slice(1, 4)
	var vuelta := letras.slice(3, 0, -1)
	print(", ".join(ida))     # B, C, D
	print(", ".join(vuelta))  # D, C, B


# 20. Copia una matriz m de 2 × 2 con duplicate() y con duplicate(true),
# cambia m[0][0] y mira cuál varía.
func ejercicio_20() -> void:
	print("— Ejercicio 20 —")
	# duplicate() copia la matriz, pero sus filas siguen siendo las mismas:
	# al cambiar un dato de una fila, cambia también en la copia. Con
	# duplicate(true), las filas se copian también, y la copia no cambia.
	var m: Array[Array] = [[1, 2], [3, 4]]
	var superficial: Array[Array] = m.duplicate()
	var profunda: Array[Array] = m.duplicate(true)
	m[0][0] = 99
	print(superficial)  # [[99, 2], [3, 4]]: varía
	print(profunda)     # [[1, 2], [3, 4]]: no varía
