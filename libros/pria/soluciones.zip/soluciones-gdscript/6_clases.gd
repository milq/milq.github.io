class_name Main extends Node2D
# Soluciones de «Clases» (capítulo 2, apartado 2.10).
# Es el script de la escena 6_clases.tscn: ábrela y ejecútala con F6 (Run
# Current Scene). Los ejercicios 1 a 5 escriben en Output; en el 6, Niblo se
# mueve con las flechas y la tecla R reinicia la escena.
# Hay muchas formas correctas de resolver cada ejercicio; esta es solo una.
# Solo usa lo que hay en los scripts de 0_hola_mundo.gd a 6_clases.gd, en
# https://milq.github.io/libros/pria/gdscript/ (la parte de la escena está al
# final de 6_clases.gd).
# Las clases de los ejercicios 1 a 4 van al final del archivo, después de
# los métodos de la escena, como pide la guía de estilo de Godot.


# 6. El script es también una clase, Main, que hereda de Node2D: por eso puede
# tener propiedades, como niblo, y sobrescribir métodos, como _process().
@export var velocidad := 200.0

var niblo: Sprite2D


func _ready() -> void:
	print("— Ejercicio 1 —")
	var heroe := Heroe.new("Niblo")
	heroe.recibir_daño(130)
	print(heroe.salud, " ", heroe.esta_vivo)  # 0 false
	heroe.curar(500)
	print(heroe.salud, " ", heroe.esta_vivo)  # 100 true

	print("— Ejercicio 2 —")
	var slime := Slime.new()
	print(slime.nombre, " ataca con ", slime.atacar())  # 1

	print("— Ejercicio 3 —")
	var esqueleto := Esqueleto.new()
	print(esqueleto.nombre, " ataca con ", esqueleto.atacar())  # 5

	print("— Ejercicio 4 —")
	var jefe := Jefe.new()
	print(jefe.nombre, " ataca con ", jefe.atacar())  # 10
	# Un objeto es de su clase y de todas las clases de las que hereda.
	print(jefe is Esqueleto, " ", jefe is Enemigo)  # true true

	# 5. El array es de tipo Enemigo, pero cada elemento responde con su
	# versión de atacar(): eso es el polimorfismo. Para añadir un murciélago
	# basta con crear su clase con su atacar(); el bucle no cambia.
	print("— Ejercicio 5 —")
	var enemigos: Array[Enemigo] = [slime, esqueleto, jefe]
	var total: int = 0
	for enemigo: Enemigo in enemigos:
		total += enemigo.atacar()
	print("Total: ", total)  # Total: 16

	# 6. Crear un nodo desde el código tiene tres pasos: new() lo crea en
	# memoria; después se configuran sus propiedades, y add_child() lo cuelga
	# de la escena. Solo entonces Godot lo dibuja y llama a sus métodos: si
	# olvidas add_child(), no hay ningún error, pero Niblo no aparece.
	niblo = Sprite2D.new()
	niblo.texture = load("res://niblo.png")
	niblo.position = get_viewport_rect().size / 2.0  # El centro
	add_child(niblo)


func _process(delta: float) -> void:
	var direccion := Input.get_vector(
			"ui_left", "ui_right", "ui_up", "ui_down")
	niblo.position += direccion * velocidad * delta


# Godot llama a _unhandled_input() con cada evento: una tecla, el ratón…
# Con is se comprueba que sea una tecla antes de mirar si es la R.
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_R:
		get_tree().reload_current_scene()


# 1. El setter se ejecuta cada vez que se asigna un valor a salud, también
# desde dentro de la clase, así que basta con limitarlo ahí. esta_vivo no
# guarda nada: su getter lo calcula cada vez que se lee.
class Heroe:
	var nombre: String
	var salud: int = 100:
		set(valor):
			salud = clampi(valor, 0, 100)
	var esta_vivo: bool:
		get:
			return salud > 0

	func _init(p_nombre: String) -> void:
		nombre = p_nombre

	func recibir_daño(cantidad: int) -> void:
		salud -= cantidad  # Pasa por el setter

	func curar(cantidad: int) -> void:
		salud += cantidad


# 2. Slime hereda las propiedades y los métodos de Enemigo, así que solo
# necesita su constructor, que llama al del padre con super() para darle
# nombre y salud. Slime no tiene atacar(): Godot lo busca en su clase y, si
# no lo encuentra, sube a la del padre. Lo común se escribe una sola vez.
class Enemigo:
	var nombre: String
	var salud: int

	func _init(p_nombre: String, p_salud: int) -> void:
		nombre = p_nombre
		salud = p_salud

	func atacar() -> int:
		return 1


class Slime extends Enemigo:
	func _init() -> void:
		super("Slime", 10)


# 3. Al escribir en Esqueleto un método con el mismo nombre, se usa el suyo
# en lugar del del padre: un esqueleto hace 5 de daño y un slime, 1.
class Esqueleto extends Enemigo:
	func _init() -> void:
		super("Esqueleto", 30)

	func atacar() -> int:
		return 5


# 4. super.atacar() llama al método del padre, Esqueleto, que devuelve 5, así
# que el jefe hace 10.
class Jefe extends Esqueleto:
	func _init() -> void:
		super()
		nombre = "Jefe"

	func atacar() -> int:
		return super.atacar() * 2
