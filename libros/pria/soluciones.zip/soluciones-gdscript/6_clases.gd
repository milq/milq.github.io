@tool
extends EditorScript
# Soluciones de los ejercicios 61 a 69 del apéndice A, «Clases y escenas».
# Ejecútalo con File → Run (Ctrl + Shift + X): el resultado sale en el panel
# Output. El ejercicio 70 es una escena: 6_escena.tscn, con su script,
# 6_escena.gd. Solo usa lo que explica el apéndice hasta su apartado «Clases y
# escenas», salvo @warning_ignore, que quita el aviso de la división entera.
# Las clases van fuera de _run(), a su lado, y en _run() se crean sus objetos.
# La clase Rival crece de un ejercicio a otro (62, 64, 65, 66 y 67): aquí va
# ya con todo, y cada parte dice de qué ejercicio es.


# 61. La clase Moneda, con la propiedad entera valor.
class Moneda:
	var valor: int

	func _init(v: int) -> void:  # El constructor: lo llama new()
		valor = v


# 62. La clase Rival, con las propiedades nombre y energia, el constructor
# _init() y el método gastar(n).
class Rival:
	# 66. Un enum con los estados, y una propiedad con el estado actual.
	enum Estado { NORMAL, CANSADO, AGOTADO }

	var nombre: String
	# 64. Un set que limita la energía entre 0 y 100: se ejecuta cada vez que
	# se le da valor, también con -= y +=.
	var energia: int = 100:
		set(valor):
			energia = clampi(valor, 0, 100)
	# 65. Una propiedad calculada: no guarda nada, y su get dice, cada vez que
	# se lee, si queda energía.
	var despierto: bool:
		get:
			return energia > 0
	var estado: Estado = Estado.NORMAL

	func _init(n: String, e: int = 100) -> void:
		nombre = n
		energia = e

	func gastar(n: int) -> void:
		energia -= n
		# El estado sigue a la energía (66).
		if energia == 0:
			estado = Estado.AGOTADO
		elif energia < 50:
			estado = Estado.CANSADO


# 67. La clase Jefe, hija de Rival: tiene sus propiedades y sus métodos, llama
# al _init() del padre con super() y sobrescribe gastar() para gastar la mitad.
class Jefe extends Rival:
	func _init(n: String) -> void:
		super(n, 100)  # El _init() de Rival

	func gastar(n: int) -> void:
		# n / 2 es una división entera, y @warning_ignore quita su aviso.
		@warning_ignore("integer_division")
		super.gastar(n / 2)  # El gastar() de Rival, con la mitad


# 63. La clase Punto, con x e y, y un método que recibe otro Punto y devuelve
# la distancia que los separa (la euclídea: la raíz de dx² + dy²).
class Punto:
	var x: int
	var y: int

	func _init(px: int, py: int) -> void:
		x = px
		y = py

	func distancia_a(otro: Punto) -> float:
		var dx: int = x - otro.x
		var dy: int = y - otro.y
		return sqrt(float(dx * dx + dy * dy))


func _run() -> void:
	ejercicio_61()
	ejercicio_62()
	ejercicio_63()
	ejercicio_64()
	ejercicio_65()
	ejercicio_66()
	ejercicio_67()
	ejercicio_68()
	ejercicio_69()


# 61. Crea tres instancias de Moneda con new() y suma el valor de todas.
func ejercicio_61() -> void:
	print("— Ejercicio 61 —")
	var monedas: Array[Moneda] = [Moneda.new(1), Moneda.new(2), Moneda.new(5)]
	var total: int = 0
	for moneda: Moneda in monedas:
		total += moneda.valor
	print(total)  # 8


# 62. Un Rival, creado con su constructor, que gasta energía.
func ejercicio_62() -> void:
	print("— Ejercicio 62 —")
	var mubbit := Rival.new("Mubbit", 60)
	mubbit.gastar(25)
	print(mubbit.nombre, ": ", mubbit.energia)  # Mubbit: 35


# 63. La distancia de (0, 0) a (3, 4).
func ejercicio_63() -> void:
	print("— Ejercicio 63 —")
	var a := Punto.new(0, 0)
	var b := Punto.new(3, 4)
	print(a.distancia_a(b))  # 5.0


# 64. El set de energia la deja en 100 aunque se le asigne 150, y en 0 si
# baja de cero.
func ejercicio_64() -> void:
	print("— Ejercicio 64 —")
	var rival := Rival.new("Mubbit")
	rival.energia = 150
	print(rival.energia)  # 100
	rival.energia -= 130
	print(rival.energia)  # 0


# 65. despierto se calcula al leerlo.
func ejercicio_65() -> void:
	print("— Ejercicio 65 —")
	var rival := Rival.new("Mubbit", 10)
	print(rival.despierto)  # true
	rival.gastar(10)
	print(rival.despierto)  # false: ya no queda energía


# 66. El estado empieza en NORMAL y cambia al gastar. Un enum se usa con el
# nombre de la clase y el del enum: Rival.Estado.CANSADO.
func ejercicio_66() -> void:
	print("— Ejercicio 66 —")
	var rival := Rival.new("Mubbit")
	print(rival.estado == Rival.Estado.NORMAL)   # true
	rival.gastar(70)
	print(rival.estado == Rival.Estado.CANSADO)  # true: le quedan 30
	print(rival.estado)                          # 1: CANSADO, el segundo del enum


# 67. El Jefe gasta la mitad que un Rival.
func ejercicio_67() -> void:
	print("— Ejercicio 67 —")
	var jefe := Jefe.new("Gran Mubbit")
	jefe.gastar(40)
	print(jefe.nombre, ": ", jefe.energia)  # Gran Mubbit: 80


# 68. Un Rival y un Jefe en un Array[Rival]: cada uno ejecuta su gastar(), e
# is busca cuál es el Jefe.
func ejercicio_68() -> void:
	print("— Ejercicio 68 —")
	# El array es de Rival, y admite un Jefe porque un Jefe también es un
	# Rival. Al llamar a gastar(), cada uno ejecuta su versión: eso es el
	# polimorfismo.
	var rivales: Array[Rival] = [Rival.new("Mubbit"), Jefe.new("Gran Mubbit")]
	for rival: Rival in rivales:
		rival.gastar(20)
		print(rival.nombre, ": ", rival.energia)  # Mubbit: 80 y Gran Mubbit: 90
	for rival: Rival in rivales:
		if rival is Jefe:
			print("El jefe es ", rival.nombre)  # El jefe es Gran Mubbit


# 69. Crea un Sprite2D con la textura res://icon.svg en (640, 360), hazlo hijo
# de un Node2D y libera el padre.
func ejercicio_69() -> void:
	print("— Ejercicio 69 —")
	# Un nodo creado con new() no está en el árbol de una escena: no se ve, y
	# hay que liberarlo a mano con free(). Al liberar el padre, free() se lleva
	# también a sus hijos.
	var escena := Node2D.new()
	var icono := Sprite2D.new()
	icono.texture = load("res://icon.svg")
	icono.position = Vector2(640, 360)
	escena.add_child(icono)
	print(escena.get_child_count())  # 1: el icono es su hijo
	escena.free()
