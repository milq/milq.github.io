------------------------------------------------------------
                    TOTAL VALIDATOR TEST
------------------------------------------------------------
INTRODUCTION

Total Validator allows you to perform many different
validations on your web pages in one go, rather than using
several tools to achieve the same thing. It can simultaneously
validate your HTML, check that pages are accessible,
run a spell check, and check for broken links. This test
version will tell you if you have any issues but you must
buy the Basic or Pro versions to see where the issues are in
order to fix them.

------------------------------------------------------------
INSTALLING/UNINSTALLING

Windows: To install, run the .exe or .msi file you downloaded,
overwriting any previous installation. Uninstall from the Windows
control panel just like any other Windows program.

macOS: To install, drag the TotalValidatorTest icon into your
Applications folder, overwriting any existing installation.
To uninstall, drag this into the Trash. If any messages appear
when you first try to run Total Validator, please read the FAQ
for solutions: https://www.totalvalidator.com/help/faq.html#osx

Linux: To install, copy the .tar.gz file you downloaded into
the directory of your choice and run the following command
to create the 'TotalValidatorTest' directory that contains the
application:

  # tar xvfz TotalValidatorTest.tar.gz

To display the results in your browser you may have to amend
'app/default_browser.sh'. To uninstall, delete the
TotalValidatorTest directory.

------------------------------------------------------------
COPYRIGHT

Copyright 2019, Total Validator. All rights reserved.
Use is subject to the terms of the licence.

------------------------------------------------------------
