/*
  Copyright (c) Total Validator.
  All Rights Reserved.
*/
(function () {
  //Talk to TV app to get the starting page and options
  var req = new XMLHttpRequest(),
      port = "9889",
      index,
      index2;

  index = location.href.lastIndexOf("-");
  index2 = location.href.lastIndexOf(".");
  if (index != -1 && index2 != -1) port = location.href.substring(index+1, index2);

  req.open("GET", "http://127.0.0.1:" + port + "?url=url", true);
  req.onreadystatechange = function() {
    if (req.readyState != 4) { return; }
    try {
      if (req.status === 200) {
        if (req.responseText) {
          window.postMessage({options: req.responseText, port: port}, '*' /* targetOrigin: any */);
        }
        else {
          alert("No response from the Total Validator application");
        }
      }
      else if (req.status === 0) {
        alert("Could not contact the Total Validator application");
      }
      else {
        alert("Could not contact the Total Validator application: " + req.status);
      }
    } catch (e) {
      console.error(e);
      alert("Could not contact the Total Validator application (see console for more information)");
    }
  };
  req.send();
})();
