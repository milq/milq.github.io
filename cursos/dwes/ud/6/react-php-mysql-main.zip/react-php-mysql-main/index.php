<html>
  <head>
    <script src="https://unpkg.com/react@16/umd/react.development.js" crossorigin></script>
    <script src="https://unpkg.com/react-dom@16/umd/react-dom.development.js" crossorigin></script>

    <script src="https://unpkg.com/babel-standalone@6/babel.min.js"></script>
    <!-- Cargamos nuestro componente de React. -->
    <script src="components.js" type="text/babel"></script>
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
