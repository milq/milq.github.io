<?php
$mensaje = '';

require_once('connect_db.php');

if (isset($_POST['asunto']) && isset($_POST['cuerpo']) && !empty($_POST['fecha']) && !empty($_POST['id_usuario'])) {
    // Nota: Aquí sería necesario realizar todo tipo de validaciones para garantizar la seguridad
    $subject = $_POST['asunto'];
    $body = $_POST['cuerpo'];
    $date_message = $_POST['fecha'];
    $user_id = $_POST['id_usuario'];

    $sth = $dbh->prepare('INSERT INTO mensajes(asunto, cuerpo, fecha, id_usuario) VALUES (?, ?, ?, ?)');

    try {
        $sth->execute([$subject, $body, $date_message, $user_id]);
        $mensaje = 'El mensaje se ha insertado con éxito.';
    } catch (PDOException $e) {
        $error = $e->getMessage();
        $mensaje = 'La inserción ha fallado. Error: ' . $error;
    }
} else {
    $mensaje = 'La fecha o el identificador del usuario está vacío.';
}
?>

<!DOCTYPE html>
<html xmlns='http://www.w3.org/1999/xhtml' lang='es'>
  <head>
    <meta charset='utf-8' />
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=2.0' />
    <link rel='stylesheet' type='text/css' href='estilo.css' />
    <title>Mensajes</title>
  </head>

  <body>
    <h1>Mensajes</h1>

    <nav>
        <a href='index.php'>Inicio</a> |
        <a href='ver.php'>Ver</a> |
        Añadir
    </nav>

    <h2>Insertar</h2>

    <p><?php echo $mensaje; ?></p>

    <footer>
        <p>Ejemplo de clase creado por Manuel Ignacio López Quintero.</p>
    </footer>
  </body>
</html>
