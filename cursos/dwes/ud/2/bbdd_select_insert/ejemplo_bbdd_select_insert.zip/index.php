<!DOCTYPE html>
<html xmlns='http://www.w3.org/1999/xhtml' lang='es'>
  <head>
    <meta charset='utf-8' />
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=2.0' />
    <link rel='stylesheet' type='text/css' href='estilo.css' />
    <title>Mensajes</title>
  </head>

  <body>
    <h1>Mensajes</h1>

    <nav>
        Inicio |
        <a href='ver.php'>Ver</a> |
        <a href='insertar_1.php'>Añadir</a>
    </nav>

    <h2>Inicio</h2>

    <p>¡Bienvenido a la página de Mensajes! ¡Aquí podrás ver y añadir tus propios mensajes!</p>

    <footer><p>Ejemplo de clase creado por Manuel Ignacio López Quintero.</p></footer>

  </body>
</html>
