<?php ob_start(); ?>

<html xmlns='http://www.w3.org/1999/xhtml' lang='en'>
  <head>
    <meta charset='utf-8' />
    <title>Dompdf example</title>
    <link href='style.css' rel='stylesheet' />
  </head>

  <body>
    <h1>Dompdf</h1>

    <?php
      $name = $_GET['name'];
      $age = $_GET['age'];
    ?>

    <p>Your name is <?php echo $name; ?>.</p>

    <p>Your age is <?php echo $age; ?>.</p>

  </body>
</html>

<?php

require __DIR__ . '/vendor/autoload.php';

use Dompdf\Dompdf;

$dompdf = new Dompdf();
$dompdf->loadHtml(ob_get_clean());
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$dompdf->stream('cv.pdf', array('Attachment'=>0));

?>
