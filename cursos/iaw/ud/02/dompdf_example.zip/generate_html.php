<html xmlns='http://www.w3.org/1999/xhtml' lang='en'>
  <head>
    <meta charset='utf-8' />
    <title>Dompdf example</title>
    <link href='style.css' rel='stylesheet' />
  </head>

  <body>
    <h1>Dompdf</h1>

    <?php
      $name = $_GET['name'];
      $age = $_GET['age'];
    ?>

    <p>Your name is <?php echo $name; ?>.</p>

    <p>Your age is <?php echo $age; ?>.</p>

    <p><a href='generate_pdf.php?name=<?php echo $name; ?>&age=<?php echo $age; ?>'>Generate PDF</a>.</p>

  </body>
</html>
