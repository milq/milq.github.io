﻿using System;

class Programa
{
    static void Main(string[] args)
    {
        // Instancias u objetos de las clases para cada tipo de ejercicios
        Variable variable = new Variable();
        Lista lista = new Lista();
        Condicional condicional = new Condicional();
        Bucle bucle = new Bucle();
        Funcion funcion = new Funcion();
        Clase clase = new Clase();


        // Arrays de argumentos, prueba con valores y nº de elementos diferentes
        // No cambies el tipo de dato 'string[]'
        string[] argumentosVariable11 = { "3", "2", "5" };
        string[] argumentosVariable12 = { "-145.6" };

        string[] argumentosBucle11 = { "9", "5", "2", "7", "4" };


        // Aquí llamaremos a los métodos que correspondan a los ejercicios
        variable.Ejercicio01();
        variable.Ejercicio02();
        variable.Ejercicio11(argumentosVariable11);
        variable.Ejercicio12(argumentosVariable12);

        lista.Ejercicio07();

        bucle.Ejercicio11(argumentosBucle11);

        funcion.Ejercicio02(4, 5);
        funcion.Ejercicio02(6, 3);
        funcion.Ejercicio02(7, 7);

        clase.Ejercicio01();
    }
}
