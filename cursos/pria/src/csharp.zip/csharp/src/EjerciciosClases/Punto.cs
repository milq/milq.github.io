using System;

public class Punto
{
    private int _x;
    private int _y;

    public Punto(int x, int y)
    {
        _x = x;
        _y = y;
    }

    public int getX()
    {
        return _x;
    }

    public void setX(int x)
    {
        _x = x;
    }

    public int getY()
    {
        return _y;
    }

    public void setY(int y)
    {
        _y = y;
    }

    // Alternativa más moderna en C#, pero es menos didáctico
    // public int x
    // { get; set; }

    // Alternativa más moderna en C#, pero es menos didáctico
    // public int y
    // { get; set; }
}
