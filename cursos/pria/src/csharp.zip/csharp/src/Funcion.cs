using System;

public class Funcion
{
    // 2. Crea una función que reciba dos parámetros de entrada de tipo númerico
    // y que devuelva el máximo. Ejecuta 3 llamadas de ejemplo de la función creada.
    public void Ejercicio02(float a, float b)
    {
        float maximo;

        if (a > b)
        {
            maximo = a;
        }
        else
        {
            maximo = b;
        }

        if (a == b)
        {
            Console.WriteLine("Los números son iguales.");
        }
        else
        {
            Console.WriteLine("El " + maximo + " es el máximo.");
        }
    }
}
