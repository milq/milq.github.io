using System;

public class Variable
{
    // 1. Crea un programa que imprima la cadena de caracteres (o string) ¡Hola, mundo! en pantalla.
    public void Ejercicio01()
    {
        Console.WriteLine("¡Hola, mundo!");
    }

    // 2. Inicializa una variable de tipo número real e imprime dicha variable en pantalla.
    public void Ejercicio02()
    {
        float a = 7.5f;
        Console.WriteLine("La variable iniciada tiene como identificador 'a' y su valor es " + a + ".");
    }

    // 11. Dado tres enteros, súmalos e imprime el resultado.
    public void Ejercicio11(string[] argumentos)
    {
        string stringA = argumentos[0];
        string stringB = argumentos[1];
        string stringC = argumentos[2];

        int a = int.Parse(stringA);
        int b = int.Parse(stringB);
        int c = int.Parse(stringC);

        int suma = a + b + c;

        Console.WriteLine("La suma de los tres enteros es " + suma + ".");
    }

    // 12. Realiza un conversor de Fahrenheit a Celsius.
    public void Ejercicio12(string[] argumentos)
    {
        string fahrenheitString = argumentos[0];

        float fahrenheit = float.Parse(fahrenheitString);

        float celsius = (fahrenheit - 32f) / 1.8f;

        Console.WriteLine(fahrenheit + " grados Fahrenheit son " + celsius + " grados centígrados.");
    }
}