using System;

public class Clase
{
    // 1. Crea una clase llamada Punto con dos propiedades/atributos denominados
    // x e y, con constructor y con cuatro métodos (getter y setter), uno para
    // obtener x, otro para obtener y, otro para modificar x y otro método para
    // modificar y. Crea 3 instancias/objetos de la clase Punto y ejecuta en ellos
    // los cuatro métodos creados.
    public void Ejercicio01()
    {
        Punto a = new Punto(2, 5);
        Punto b = new Punto(-4, 7);
        Punto c = new Punto(0, 0);

        Console.WriteLine("El punto A tiene las siguientes coordenadas (x, y): (" + a.getX() + ", " + a.getY() + ").");

        b.setX(3);
        b.setY(-5);
        Console.WriteLine("El punto B tiene las siguientes coordenadas (x, y): (" + b.getX() + ", " + b.getY() + ").");

        c.setX(a.getX() + b.getX());
        c.setY(a.getY() + b.getY());
        Console.WriteLine("La suma de las coordenadas (x, y) de los puntos A y B es: (" + c.getX() + ", " + c.getY() + ").");
    }
}
