using System;

public class Lista
{
    // 7. Crea un array/lista e imprime en pantalla el número de elementos.
    public void Ejercicio07()
    {
        List<int> listaEnteros = new List<int>() { 1, 2, 7, 5 };
        int numElementos = listaEnteros.Count;
        Console.WriteLine("La lista tiene " + numElementos + " elementos.");
    }
}
