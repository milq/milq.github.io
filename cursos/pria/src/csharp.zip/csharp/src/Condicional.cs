using System;

public class Condicional
{

}