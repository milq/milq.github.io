using System;

public class Bucle
{
    // 11. Dada una serie de enteros, súmalos e imprime el resultado.
    public void Ejercicio11(string[] argumentos)
    {
        int suma = 0;
        List<int> listaEnteros = new List<int>();

        for (int i = 0; i < argumentos.Length; i++)
        {
            int numEntero = int.Parse(argumentos[i]);
            suma = suma + numEntero;
        }

        Console.WriteLine("La suma de la serie de enteros es " + suma + ".");
    }
}
