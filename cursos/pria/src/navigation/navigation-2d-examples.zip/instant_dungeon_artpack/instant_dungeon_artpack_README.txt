Instant Dungeon! Art Pack
11/28/2014

Sprites, tiles, and other art used in Instant Dungeon!
plus some misc. unused pieces.

By
Scott Matott
Voytek Falendysz
and
Jos� Luis Peir� Lima


This art is released under the terms of the OGA-BY 3.0 license.
You are free to use it any purpose (including commercial use) or create derivative works, etc.
provided you follow the terms of the license.
See the included license doc (OGA-BY-3.0.txt) for complete details, summary and more info available at:
http://opengameart.org/content/oga-by-30-faq

The short summary is do as you please, but you must credit original artists in some form.

Attribution instructions:
For art in the 'By Scott Matott' subfolder, credit Scott Matott
For art in the 'By Voytek Falendysz' subfolder, credit Voytek Falendysz
For art in the 'By Jos� Luis Peir� Lima' subfolder, credit Jos� Luis Peir� Lima
If you want to be super cool, include a link back to the official Instant Dungeon! home page:
http://www.indiedb.com/games/instant-dungeon

Would be delighted to hear of any use folks find for this stuff, so if you
use it, feel free to drop me a line at:
scott.matott@gmail.com


Finally, just want to give a shout out the whole Open Game Art community.
Most of what you see here was accomplished by studying works/comments/tutorials/etc. posted 
by members of Open Game Art community, so special thanks to all those fine lads and ladies for
being so generous with their time, knowledge and art.






