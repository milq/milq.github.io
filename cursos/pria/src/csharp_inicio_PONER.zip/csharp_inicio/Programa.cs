﻿///////////////////////////////
// ACTIVIDADES DE INICIACIÓN //
///////////////////////////////

// Aquí solamente se realizarán las actividades de iniciación ya
// que en las actividades de desarrollo hay que pasar y recibir
// argumentos con diferentes valores y nº de elementos.


///////////////
// VARIABLES //
///////////////

// 1. Crea un programa que imprima la cadena de caracteres (o string) ¡Hola, mundo! en pantalla.
Console.WriteLine("¡Hola, mundo!");


// 2. Inicializa una variable de tipo número real e imprime dicha variable en pantalla.
float a = 7.5f;
Console.WriteLine("La variable iniciada tiene como identificador 'a' y su valor es " + a + ".");


// 3. Inicializa dos variables, con identificadores edad y altura, e imprímelas junto en el mensaje: Tengo edad años y mido altura cm (se tienen que ver los dos valores dados).
int edad = 25;
float altura = 1.82f;

Console.WriteLine("La edad es " + edad + " años y la altura es de " + altura + " m^2.");


// 4. Inicializa dos variables de tipo número entero, súma las variables e imprime el resultado por pantalla.
int enteroA = 3;
int enteroB = 4;

int suma = enteroA + enteroB;

Console.WriteLine("La suma es " + suma + ".");



///////////////
// LISTAS    //
///////////////

// 7. Crea un array/lista e imprime en pantalla el número de elementos.

List<int> listaEnteros = new List<int>() { 1, 2, 7, 5 };
int numElementos = listaEnteros.Count;
Console.WriteLine("La lista tiene " + numElementos + " elementos.");
