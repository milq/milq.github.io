# SpelunkyLikeGeneration
Spelunky like procedural Generation in Godot 3.4

You can change the amount of rows and colums, as well as the room size as you want and adding new rooms, is as simple as duplicating an already existing one and changing the TileMap. Implementing rooms like shops or snakepits is also pretty easy (see source code).

It's probably not the best or compact solution but it works really reliable and it's easy to add a player or anything else you want.

I know the player script is pretty rough around the edges, but it's more about the generation then the player!


Use it as your heart's content!

Footage:

https://preview.redd.it/egobzykcpre71.gif?format=mp4&s=79abf4e4472b4d3642ccbe39217cd0fea572cf08

https://preview.redd.it/nf6dq1lctre71.gif?format=mp4&s=bc7dd86843dc9ffe81f7c895b7010d43a6da435d
